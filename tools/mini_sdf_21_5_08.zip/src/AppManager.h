#ifndef __APP_MANAGER_H_
#define __APP_MANAGER_H_

#include "stdafx.h"

#include "CalculateSDF.h"

#include "AppObject.h"

class FacetPainter;
class DebugPainter;
class OverlayPainter;
class SdfOverlayPainter;

class AppParams;
class WorldObject;
class QTextStream;


struct ApplicationParameters 
{
	NormalizeTypes sdf_normalize;
	int sdf_numcones;
	int sdf_coneSeperation;
	int sdf_raysInCone;
	bool sdf_gaussianWeights;
	bool sdf_smoothing;
	bool sdf_smoothing_anisotropic;
	int  sdf_smoothing_iterations;

	bool multithreaded;

	bool normalsReversed;

	ApplicationParameters() : 
		sdf_normalize(MinMax), 
		sdf_numcones(3),
		sdf_coneSeperation(20),
		sdf_raysInCone(4),
		sdf_gaussianWeights(true),
		sdf_smoothing(false),
		sdf_smoothing_iterations(3),
		sdf_smoothing_anisotropic(true),
		multithreaded(false),

		normalsReversed(true)

	{}
};

typedef QHash<QString, AppObject*> appObjectsMap_t;


#define FEATURES_FILE_SDF_VERTICES	0x001
#define FEATURES_FILE_SDF_FACETS	0x002

class WorldManager;
class MainWindow;
class PartsSnapViewer;



class FaceColorizer
{
public:
	virtual QColor getColor(Mesh::Facet_handle f) = 0;
};


struct IndexRecord
{
	IndexRecord(int _start = -1, int _count = 0) :start(_start), count(_count) {}
	int start, count;
};
typedef QHash<QString, IndexRecord> TModelIndex;




/**
 *	This is the application manager, it keeps a list of the open meshes
 */
class AppManager : public QObject 
{
	Q_OBJECT
public:
	AppManager(MainWindow* parent = NULL, const char* name = NULL);
	~AppManager();
	/** after all objects are constructed and connections are made call this function to initialize everything */
	void Init(WorldManager* worldManager);

	/// currently loaded objects
	appObjectsMap_t m_objects;
	
//	TFilesAppParams m_filesAppParams;

	/** current selected object id */
	QString m_selectedObject;

	/** dialog for editing application parameters */
	AppParams* m_appParamsDialog;

	/** application parameters */
	ApplicationParameters m_appParameters;



public:	

	/// link to world manager
	WorldManager* m_worldManager;

	/** generate a unique id for an object from the filename */
	QString createObjectId(const QString& fileName);

	AppObject* getObject(const QString& id);

	/** load a mesh from a file */
	bool loadMesh(const QString& fileName, AppObject* mesh, float err);

	/** calculate initial features on mesh */
	void doMeshPrecalc(Mesh* mesh);

	/** load features from file for this app object */
	bool loadMeshFeatures(const QString& featuresFileName, AppObject* appObject);

	bool saveSDFVertices(const QString& featuresFileName, AppObject* appObject);
	bool saveSDFFacets(const QString& featuresFileName, AppObject* appObject);
	/// For debug purposes (matlab shit), save as text file
	bool saveSDFFacetsText(const QString& featuresFileName, AppObject* appObject); 
	/// For debug purposes (matlab shit), save as text file
	bool saveSDFDiffFacetsText(const QString& featuresFileName, AppObject* appObject); 

	bool saveObjWithFaceSDF(const QString& filename, AppObject* appObject);

	bool saveObjWithFaceColor(const QString& filename, AppObject* appObject, FaceColorizer& cizr, bool group); 

	bool loadSDFVertices(const QString& featuresFileName, AppObject* appObject);
	bool loadSDFFacets(const QString& featuresFileName, AppObject* appObject);

	/** load an sdf information file and store the diff in values between current and new file
	 * in the volume field */
	bool diffSDFFacets(const QString& featuresFileName, AppObject* appObject);

	bool calculateShapeDiameterFunction(AppObject* appObject, const bool onVertices, const bool showDialog = true);

	/** set object with given ID as selected */
	void selectObject(const QString& id);

	void reverseObjectNormals(AppObject* appObject);

	const ApplicationParameters *getAppParams() { return &m_appParameters; }
	void saveApplicationParameters();
	void loadApplicationParameters();

	QStringList getObjectNames(int& selectedIndex);

	void createProjectionMesh(AppObject* appObject);
	void createProjectionPart(AppObject* appObject, const int partIndex);

public:

	/** loads a mesh from a given filename */
	/// err - error tolerance. 1.0 - tolerate anything. 0.3 tolerate less.
	bool loadObject(const QString& fileName, float err, TStubData* part = NULL, DrawMethod dm = DRAW_PART);
	void copyObject(AppObject *from, TStubData* newPart, DrawMethod dm);

	/** prompts the user to load a specified mesh */
	bool loadObject();


	void removeAllObjects();

	AppObject* getSelectedObject();


signals:

	void showParts();

	/** one or more of the objects have changed and probably require redraw */
	void ObjectsChanged();

	/** a new object was loaded into the application */
	void ObjectAdded(AppObject *ao, TStubData* onlyPart, DrawMethod dm);
	/** an object was removed from the application */
	void ObjectRemoved(const QString& id);

	/** an object was changed and rendering needs to be redone */
	void ObjectChanged(const QString& id, bool geometryChanged);


	/** send message to status bar */
	void message(const QString& message);
	/** send message to status bar for several seconds */
	void message(const QString& message, int ms);

public slots:

	void openFile(QString filename);

	void saveSnapshot(const QString &fileName);

	void appParamsOk();
	void appParamsApply();
	void OnArrowKeyPressed(int key, Qt::ButtonState s);

	void removeObject(QString id);

	/** load an object */
	void OnLoadObject();
	/** load a file with object features */
	void OnLoadObjectFeatures();
	void OnDiffObjectFeatures();
	/** save a file with features */
	void OnSaveObjectFeatures();

	/** calculate shape diameter function on selected mesh's vertices */
	void OnCalculateSDFVertices();
	/** calculate shape diameter function on selected mesh's facets */
	void OnCalculateSDFFacets();
	/** calculates SDF on all loaded mesh's facets */
	void OnCalculateSDFFacetsForAll();

	/** remove all loaded objects */
	void OnRemoveObjects();
	/** remove selected object */
	void OnRemoveSelectedObject();

	/** reverse normals for selected object */
	void OnReverseNormals();

	///	open application parameters window
	void OnAppParams();
	/// show information about current object
	void OnSelectedObjectInfo();


	/** user selected a new object */
	void OnObjectSelected(const QString& id);
	/** user selected a specific facet in a specific object */
	void OnFacetSelected(const QString& id, const int facetIndex);
	/// user approves part structure (from SDF projection) for current part and model
	/// Find correspondence between two objects
	/// Show color table for correspondence results


};

#endif