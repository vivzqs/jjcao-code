/********************************************************************************
** Form generated from reading ui file 'BasicRenderingParams.ui'
**
** Created: Wed May 21 01:35:48 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_BASICRENDERINGPARAMS_H
#define UI_BASICRENDERINGPARAMS_H

#include <Qt3Support/Q3GroupBox>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QSpinBox>
#include <QtGui/QTabWidget>
#include <QtGui/QWidget>
#include "RenderingParams.h"

class Ui_RenderingParamsDialog
{
public:
    QTabWidget *tabWidget;
    QWidget *basicRenderingParams;
    Q3GroupBox *groupBox2;
    QComboBox *polygonMode;
    QComboBox *colorSchemes;
    QPushButton *colorSchemesEditor;
    QLabel *meshColorLabel;
    QPushButton *colorMeshB;
    QPushButton *colorEdgeB;
    QLabel *vertexColorLabel;
    QPushButton *colorVertexB;
    QLabel *textLabel1_3;
    QLabel *textLabel1_2;
    QLabel *textLabel1;
    QLabel *textLabel1_5;
    QLabel *edgeColorLabel;
    QLabel *textLabel2_5;
    Q3GroupBox *groupBox3;
    QLabel *textLabel1_6;
    QLabel *textLabel1_4_3;
    QLabel *textLabel1_4_2;
    QLabel *textLabel1_4;
    QComboBox *vertexPainters;
    QComboBox *debugPainters;
    QComboBox *edgePainters;
    QComboBox *facetPainters;
    Q3GroupBox *groupBox1;
    QCheckBox *cbSmoothShading;
    QCheckBox *cbCulling;
    QCheckBox *cbImposeVertices;
    QCheckBox *cbImposeEdges;
    QCheckBox *cbLighting;
    QCheckBox *cbAntialiasing;
    QCheckBox *cbUseNormals;
    QCheckBox *cbSmoothNormals;
    QCheckBox *cbOverlay;
    QSpinBox *edgeThickness;
    QSlider *alphaLevel;
    QLabel *textLabel2_2;
    QLabel *textLabel2;
    QPushButton *buttonOk;
    QPushButton *buttonApply;
    QPushButton *buttonCancel;

    void setupUi(QDialog *RenderingParamsDialog)
    {
    if (RenderingParamsDialog->objectName().isEmpty())
        RenderingParamsDialog->setObjectName(QString::fromUtf8("RenderingParamsDialog"));
    QSize size(342, 417);
    size = size.expandedTo(RenderingParamsDialog->minimumSizeHint());
    RenderingParamsDialog->resize(size);
    RenderingParamsDialog->setWindowIcon(QIcon());
    RenderingParamsDialog->setSizeGripEnabled(true);
    tabWidget = new QTabWidget(RenderingParamsDialog);
    tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
    tabWidget->setGeometry(QRect(11, 11, 320, 362));
    basicRenderingParams = new QWidget();
    basicRenderingParams->setObjectName(QString::fromUtf8("basicRenderingParams"));
    groupBox2 = new Q3GroupBox(basicRenderingParams);
    groupBox2->setObjectName(QString::fromUtf8("groupBox2"));
    groupBox2->setGeometry(QRect(147, 0, 171, 171));
    polygonMode = new QComboBox(groupBox2);
    polygonMode->setObjectName(QString::fromUtf8("polygonMode"));
    polygonMode->setGeometry(QRect(87, 147, 79, 20));
    colorSchemes = new QComboBox(groupBox2);
    colorSchemes->setObjectName(QString::fromUtf8("colorSchemes"));
    colorSchemes->setGeometry(QRect(71, 116, 69, 20));
    colorSchemesEditor = new QPushButton(groupBox2);
    colorSchemesEditor->setObjectName(QString::fromUtf8("colorSchemesEditor"));
    colorSchemesEditor->setGeometry(QRect(146, 114, 20, 25));
    colorSchemesEditor->setMaximumSize(QSize(20, 32767));
    meshColorLabel = new QLabel(groupBox2);
    meshColorLabel->setObjectName(QString::fromUtf8("meshColorLabel"));
    meshColorLabel->setGeometry(QRect(77, 15, 63, 25));
    meshColorLabel->setMinimumSize(QSize(24, 24));
    meshColorLabel->setScaledContents(true);
    meshColorLabel->setWordWrap(false);
    colorMeshB = new QPushButton(groupBox2);
    colorMeshB->setObjectName(QString::fromUtf8("colorMeshB"));
    colorMeshB->setGeometry(QRect(146, 15, 20, 25));
    QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);
    sizePolicy.setHeightForWidth(colorMeshB->sizePolicy().hasHeightForWidth());
    colorMeshB->setSizePolicy(sizePolicy);
    colorMeshB->setMaximumSize(QSize(20, 32767));
    colorEdgeB = new QPushButton(groupBox2);
    colorEdgeB->setObjectName(QString::fromUtf8("colorEdgeB"));
    colorEdgeB->setGeometry(QRect(146, 81, 20, 25));
    sizePolicy.setHeightForWidth(colorEdgeB->sizePolicy().hasHeightForWidth());
    colorEdgeB->setSizePolicy(sizePolicy);
    colorEdgeB->setMaximumSize(QSize(20, 32767));
    vertexColorLabel = new QLabel(groupBox2);
    vertexColorLabel->setObjectName(QString::fromUtf8("vertexColorLabel"));
    vertexColorLabel->setGeometry(QRect(77, 48, 63, 25));
    vertexColorLabel->setMinimumSize(QSize(24, 24));
    vertexColorLabel->setScaledContents(true);
    vertexColorLabel->setWordWrap(false);
    colorVertexB = new QPushButton(groupBox2);
    colorVertexB->setObjectName(QString::fromUtf8("colorVertexB"));
    colorVertexB->setGeometry(QRect(146, 48, 20, 25));
    sizePolicy.setHeightForWidth(colorVertexB->sizePolicy().hasHeightForWidth());
    colorVertexB->setSizePolicy(sizePolicy);
    colorVertexB->setMaximumSize(QSize(20, 32767));
    textLabel1_3 = new QLabel(groupBox2);
    textLabel1_3->setObjectName(QString::fromUtf8("textLabel1_3"));
    textLabel1_3->setGeometry(QRect(5, 81, 70, 25));
    textLabel1_3->setMinimumSize(QSize(70, 0));
    textLabel1_3->setWordWrap(false);
    textLabel1_2 = new QLabel(groupBox2);
    textLabel1_2->setObjectName(QString::fromUtf8("textLabel1_2"));
    textLabel1_2->setGeometry(QRect(5, 48, 70, 25));
    textLabel1_2->setMinimumSize(QSize(70, 0));
    textLabel1_2->setWordWrap(false);
    textLabel1 = new QLabel(groupBox2);
    textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
    textLabel1->setGeometry(QRect(5, 15, 70, 25));
    textLabel1->setMinimumSize(QSize(70, 0));
    textLabel1->setWordWrap(false);
    textLabel1_5 = new QLabel(groupBox2);
    textLabel1_5->setObjectName(QString::fromUtf8("textLabel1_5"));
    textLabel1_5->setGeometry(QRect(5, 114, 64, 25));
    textLabel1_5->setWordWrap(false);
    edgeColorLabel = new QLabel(groupBox2);
    edgeColorLabel->setObjectName(QString::fromUtf8("edgeColorLabel"));
    edgeColorLabel->setGeometry(QRect(77, 81, 63, 25));
    edgeColorLabel->setMinimumSize(QSize(24, 24));
    edgeColorLabel->setScaledContents(true);
    edgeColorLabel->setWordWrap(false);
    textLabel2_5 = new QLabel(groupBox2);
    textLabel2_5->setObjectName(QString::fromUtf8("textLabel2_5"));
    textLabel2_5->setGeometry(QRect(5, 147, 80, 20));
    textLabel2_5->setWordWrap(false);
    groupBox3 = new Q3GroupBox(basicRenderingParams);
    groupBox3->setObjectName(QString::fromUtf8("groupBox3"));
    groupBox3->setGeometry(QRect(147, 174, 167, 161));
    textLabel1_6 = new QLabel(groupBox3);
    textLabel1_6->setObjectName(QString::fromUtf8("textLabel1_6"));
    textLabel1_6->setGeometry(QRect(8, 99, 80, 20));
    textLabel1_6->setWordWrap(false);
    textLabel1_4_3 = new QLabel(groupBox3);
    textLabel1_4_3->setObjectName(QString::fromUtf8("textLabel1_4_3"));
    textLabel1_4_3->setGeometry(QRect(8, 71, 80, 20));
    textLabel1_4_3->setWordWrap(false);
    textLabel1_4_2 = new QLabel(groupBox3);
    textLabel1_4_2->setObjectName(QString::fromUtf8("textLabel1_4_2"));
    textLabel1_4_2->setGeometry(QRect(8, 43, 80, 20));
    textLabel1_4_2->setWordWrap(false);
    textLabel1_4 = new QLabel(groupBox3);
    textLabel1_4->setObjectName(QString::fromUtf8("textLabel1_4"));
    textLabel1_4->setGeometry(QRect(8, 15, 80, 20));
    textLabel1_4->setWordWrap(false);
    vertexPainters = new QComboBox(groupBox3);
    vertexPainters->setObjectName(QString::fromUtf8("vertexPainters"));
    vertexPainters->setGeometry(QRect(51, 71, 111, 20));
    debugPainters = new QComboBox(groupBox3);
    debugPainters->setObjectName(QString::fromUtf8("debugPainters"));
    debugPainters->setGeometry(QRect(51, 99, 111, 20));
    edgePainters = new QComboBox(groupBox3);
    edgePainters->setObjectName(QString::fromUtf8("edgePainters"));
    edgePainters->setGeometry(QRect(51, 43, 111, 20));
    facetPainters = new QComboBox(groupBox3);
    facetPainters->setObjectName(QString::fromUtf8("facetPainters"));
    facetPainters->setGeometry(QRect(51, 15, 111, 20));
    facetPainters->setMinimumSize(QSize(0, 0));
    groupBox1 = new Q3GroupBox(basicRenderingParams);
    groupBox1->setObjectName(QString::fromUtf8("groupBox1"));
    groupBox1->setGeometry(QRect(0, 0, 141, 335));
    cbSmoothShading = new QCheckBox(groupBox1);
    cbSmoothShading->setObjectName(QString::fromUtf8("cbSmoothShading"));
    cbSmoothShading->setGeometry(QRect(7, 22, 141, 18));
    cbCulling = new QCheckBox(groupBox1);
    cbCulling->setObjectName(QString::fromUtf8("cbCulling"));
    cbCulling->setGeometry(QRect(7, 46, 141, 18));
    cbImposeVertices = new QCheckBox(groupBox1);
    cbImposeVertices->setObjectName(QString::fromUtf8("cbImposeVertices"));
    cbImposeVertices->setGeometry(QRect(7, 70, 141, 18));
    cbImposeEdges = new QCheckBox(groupBox1);
    cbImposeEdges->setObjectName(QString::fromUtf8("cbImposeEdges"));
    cbImposeEdges->setGeometry(QRect(7, 94, 141, 18));
    cbLighting = new QCheckBox(groupBox1);
    cbLighting->setObjectName(QString::fromUtf8("cbLighting"));
    cbLighting->setGeometry(QRect(7, 118, 141, 18));
    cbAntialiasing = new QCheckBox(groupBox1);
    cbAntialiasing->setObjectName(QString::fromUtf8("cbAntialiasing"));
    cbAntialiasing->setGeometry(QRect(7, 142, 141, 18));
    cbUseNormals = new QCheckBox(groupBox1);
    cbUseNormals->setObjectName(QString::fromUtf8("cbUseNormals"));
    cbUseNormals->setGeometry(QRect(7, 166, 141, 18));
    cbSmoothNormals = new QCheckBox(groupBox1);
    cbSmoothNormals->setObjectName(QString::fromUtf8("cbSmoothNormals"));
    cbSmoothNormals->setGeometry(QRect(7, 190, 141, 18));
    cbOverlay = new QCheckBox(groupBox1);
    cbOverlay->setObjectName(QString::fromUtf8("cbOverlay"));
    cbOverlay->setGeometry(QRect(7, 230, 141, 18));
    edgeThickness = new QSpinBox(groupBox1);
    edgeThickness->setObjectName(QString::fromUtf8("edgeThickness"));
    edgeThickness->setGeometry(QRect(80, 255, 60, 20));
    edgeThickness->setMinimum(1);
    edgeThickness->setMaximum(10);
    alphaLevel = new QSlider(groupBox1);
    alphaLevel->setObjectName(QString::fromUtf8("alphaLevel"));
    alphaLevel->setGeometry(QRect(34, 283, 106, 21));
    alphaLevel->setMaximum(255);
    alphaLevel->setValue(100);
    alphaLevel->setOrientation(Qt::Horizontal);
    textLabel2_2 = new QLabel(groupBox1);
    textLabel2_2->setObjectName(QString::fromUtf8("textLabel2_2"));
    textLabel2_2->setGeometry(QRect(3, 283, 27, 21));
    textLabel2_2->setWordWrap(false);
    textLabel2 = new QLabel(groupBox1);
    textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
    textLabel2->setGeometry(QRect(3, 255, 73, 20));
    textLabel2->setWordWrap(false);
    tabWidget->addTab(basicRenderingParams, QString());
    buttonOk = new QPushButton(RenderingParamsDialog);
    buttonOk->setObjectName(QString::fromUtf8("buttonOk"));
    buttonOk->setGeometry(QRect(12, 380, 102, 25));
    QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
    sizePolicy1.setHorizontalStretch(0);
    sizePolicy1.setVerticalStretch(0);
    sizePolicy1.setHeightForWidth(buttonOk->sizePolicy().hasHeightForWidth());
    buttonOk->setSizePolicy(sizePolicy1);
    buttonOk->setMaximumSize(QSize(32767, 32767));
    buttonOk->setAutoDefault(true);
    buttonOk->setDefault(true);
    buttonApply = new QPushButton(RenderingParamsDialog);
    buttonApply->setObjectName(QString::fromUtf8("buttonApply"));
    buttonApply->setGeometry(QRect(120, 380, 102, 25));
    sizePolicy1.setHeightForWidth(buttonApply->sizePolicy().hasHeightForWidth());
    buttonApply->setSizePolicy(sizePolicy1);
    buttonApply->setMaximumSize(QSize(32767, 32767));
    buttonApply->setAutoDefault(false);
    buttonApply->setDefault(false);
    buttonCancel = new QPushButton(RenderingParamsDialog);
    buttonCancel->setObjectName(QString::fromUtf8("buttonCancel"));
    buttonCancel->setGeometry(QRect(228, 380, 102, 25));
    sizePolicy1.setHeightForWidth(buttonCancel->sizePolicy().hasHeightForWidth());
    buttonCancel->setSizePolicy(sizePolicy1);
    buttonCancel->setMaximumSize(QSize(32767, 32767));
    buttonCancel->setAutoDefault(true);

    retranslateUi(RenderingParamsDialog);
    QObject::connect(buttonOk, SIGNAL(clicked()), RenderingParamsDialog, SLOT(accept()));
    QObject::connect(buttonCancel, SIGNAL(clicked()), RenderingParamsDialog, SLOT(reject()));
    QObject::connect(colorMeshB, SIGNAL(clicked()), RenderingParamsDialog, SLOT(changeMeshColor()));
    QObject::connect(colorEdgeB, SIGNAL(clicked()), RenderingParamsDialog, SLOT(changeEdgeColor()));
    QObject::connect(colorVertexB, SIGNAL(clicked()), RenderingParamsDialog, SLOT(changeVertexColor()));
    QObject::connect(alphaLevel, SIGNAL(valueChanged(int)), RenderingParamsDialog, SLOT(OnAlphaLevelChanged(int)));
    QObject::connect(buttonOk, SIGNAL(clicked()), RenderingParamsDialog, SLOT(OnApply()));
    QObject::connect(buttonApply, SIGNAL(clicked()), RenderingParamsDialog, SLOT(OnApply()));
    QObject::connect(colorSchemesEditor, SIGNAL(clicked()), RenderingParamsDialog, SLOT(OnEditColorSchemes()));

    QMetaObject::connectSlotsByName(RenderingParamsDialog);
    } // setupUi

    void retranslateUi(QDialog *RenderingParamsDialog)
    {
    RenderingParamsDialog->setWindowTitle(QApplication::translate("RenderingParamsDialog", "Rendering Params", 0, QApplication::UnicodeUTF8));
    groupBox2->setTitle(QApplication::translate("RenderingParamsDialog", "Colors", 0, QApplication::UnicodeUTF8));
    colorSchemesEditor->setToolTip(QApplication::translate("RenderingParamsDialog", "Open color schemes editor", 0, QApplication::UnicodeUTF8));
    colorSchemesEditor->setText(QApplication::translate("RenderingParamsDialog", "...", 0, QApplication::UnicodeUTF8));
    colorMeshB->setText(QApplication::translate("RenderingParamsDialog", "...", 0, QApplication::UnicodeUTF8));
    colorEdgeB->setText(QApplication::translate("RenderingParamsDialog", "...", 0, QApplication::UnicodeUTF8));
    colorVertexB->setText(QApplication::translate("RenderingParamsDialog", "...", 0, QApplication::UnicodeUTF8));
    textLabel1_3->setText(QApplication::translate("RenderingParamsDialog", "Edge Color", 0, QApplication::UnicodeUTF8));
    textLabel1_2->setText(QApplication::translate("RenderingParamsDialog", "Vertex Color", 0, QApplication::UnicodeUTF8));
    textLabel1->setText(QApplication::translate("RenderingParamsDialog", "Mesh Color", 0, QApplication::UnicodeUTF8));
    textLabel1_5->setText(QApplication::translate("RenderingParamsDialog", "Color scheme", 0, QApplication::UnicodeUTF8));
    textLabel2_5->setText(QApplication::translate("RenderingParamsDialog", "Polygon Mode", 0, QApplication::UnicodeUTF8));
    groupBox3->setTitle(QApplication::translate("RenderingParamsDialog", "Feature Display", 0, QApplication::UnicodeUTF8));
    textLabel1_6->setText(QApplication::translate("RenderingParamsDialog", "Debug", 0, QApplication::UnicodeUTF8));
    textLabel1_4_3->setText(QApplication::translate("RenderingParamsDialog", "Vertices", 0, QApplication::UnicodeUTF8));
    textLabel1_4_2->setText(QApplication::translate("RenderingParamsDialog", "Edges", 0, QApplication::UnicodeUTF8));
    textLabel1_4->setText(QApplication::translate("RenderingParamsDialog", "Facets", 0, QApplication::UnicodeUTF8));
    groupBox1->setTitle(QApplication::translate("RenderingParamsDialog", "Display Modes", 0, QApplication::UnicodeUTF8));
    cbSmoothShading->setText(QApplication::translate("RenderingParamsDialog", "Smooth Shading", 0, QApplication::UnicodeUTF8));
    cbCulling->setText(QApplication::translate("RenderingParamsDialog", "Culling", 0, QApplication::UnicodeUTF8));
    cbImposeVertices->setText(QApplication::translate("RenderingParamsDialog", "Superimpose Vertices", 0, QApplication::UnicodeUTF8));
    cbImposeEdges->setText(QApplication::translate("RenderingParamsDialog", "Superimpose Edges", 0, QApplication::UnicodeUTF8));
    cbLighting->setText(QApplication::translate("RenderingParamsDialog", "Lighting", 0, QApplication::UnicodeUTF8));
    cbAntialiasing->setText(QApplication::translate("RenderingParamsDialog", "Antialiasing", 0, QApplication::UnicodeUTF8));
    cbUseNormals->setText(QApplication::translate("RenderingParamsDialog", "Use Normals", 0, QApplication::UnicodeUTF8));
    cbSmoothNormals->setToolTip(QApplication::translate("RenderingParamsDialog", "Should use see facets", 0, QApplication::UnicodeUTF8));
    cbSmoothNormals->setText(QApplication::translate("RenderingParamsDialog", "Smooth Normals", 0, QApplication::UnicodeUTF8));
    cbOverlay->setText(QApplication::translate("RenderingParamsDialog", "Show Overlay", 0, QApplication::UnicodeUTF8));
    textLabel2_2->setText(QApplication::translate("RenderingParamsDialog", "Alpha", 0, QApplication::UnicodeUTF8));
    textLabel2->setText(QApplication::translate("RenderingParamsDialog", "Edge Thickness", 0, QApplication::UnicodeUTF8));
    tabWidget->setTabText(tabWidget->indexOf(basicRenderingParams), QApplication::translate("RenderingParamsDialog", "Rendering Params", 0, QApplication::UnicodeUTF8));
    buttonOk->setText(QApplication::translate("RenderingParamsDialog", "&OK", 0, QApplication::UnicodeUTF8));
    buttonOk->setShortcut(QString());
    buttonApply->setText(QApplication::translate("RenderingParamsDialog", "&Apply", 0, QApplication::UnicodeUTF8));
    buttonApply->setShortcut(QApplication::translate("RenderingParamsDialog", "Alt+A", 0, QApplication::UnicodeUTF8));
    buttonCancel->setText(QApplication::translate("RenderingParamsDialog", "&Cancel", 0, QApplication::UnicodeUTF8));
    buttonCancel->setShortcut(QString());
    Q_UNUSED(RenderingParamsDialog);
    } // retranslateUi

};

namespace Ui {
    class RenderingParamsDialog: public Ui_RenderingParamsDialog {};
} // namespace Ui

#endif // UI_BASICRENDERINGPARAMS_H
