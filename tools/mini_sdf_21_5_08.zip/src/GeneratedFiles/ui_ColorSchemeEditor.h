/********************************************************************************
** Form generated from reading ui file 'ColorSchemeEditor.ui'
**
** Created: Wed May 21 01:35:48 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_COLORSCHEMEEDITOR_H
#define UI_COLORSCHEMEEDITOR_H

#include <Qt3Support/Q3ListBox>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTabWidget>
#include <QtGui/QWidget>
#include <hash_map>
#include <QtGui/QCheckBox>
#include <string>
#include "ColorButton.h"
#include "RenderingParams.h"

class Ui_ColorSchemeEditor
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *hboxLayout;
    QPushButton *buttonHelp;
    QSpacerItem *spacerItem;
    QPushButton *buttonOk;
    QPushButton *buttonCancel;
    QHBoxLayout *hboxLayout1;
    QPushButton *newButton;
    QPushButton *deleteButton;
    QPushButton *renameButton;
    QSpacerItem *spacerItem1;
    QTabWidget *csProperties;
    QWidget *csDetails;
    Q3ListBox *csNames;

    void setupUi(QDialog *ColorSchemeEditor)
    {
    if (ColorSchemeEditor->objectName().isEmpty())
        ColorSchemeEditor->setObjectName(QString::fromUtf8("ColorSchemeEditor"));
    QSize size(396, 359);
    size = size.expandedTo(ColorSchemeEditor->minimumSizeHint());
    ColorSchemeEditor->resize(size);
    ColorSchemeEditor->setSizeGripEnabled(true);
    gridLayout = new QGridLayout(ColorSchemeEditor);
    gridLayout->setSpacing(6);
    gridLayout->setMargin(11);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
    gridLayout->setResizeMode(QGridLayout::Fixed);
    hboxLayout = new QHBoxLayout();
    hboxLayout->setSpacing(6);
    hboxLayout->setMargin(0);
    hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
    buttonHelp = new QPushButton(ColorSchemeEditor);
    buttonHelp->setObjectName(QString::fromUtf8("buttonHelp"));
    buttonHelp->setAutoDefault(true);

    hboxLayout->addWidget(buttonHelp);

    spacerItem = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    hboxLayout->addItem(spacerItem);

    buttonOk = new QPushButton(ColorSchemeEditor);
    buttonOk->setObjectName(QString::fromUtf8("buttonOk"));
    buttonOk->setAutoDefault(true);
    buttonOk->setDefault(true);

    hboxLayout->addWidget(buttonOk);

    buttonCancel = new QPushButton(ColorSchemeEditor);
    buttonCancel->setObjectName(QString::fromUtf8("buttonCancel"));
    buttonCancel->setAutoDefault(true);

    hboxLayout->addWidget(buttonCancel);


    gridLayout->addLayout(hboxLayout, 2, 0, 1, 2);

    hboxLayout1 = new QHBoxLayout();
    hboxLayout1->setSpacing(6);
    hboxLayout1->setMargin(0);
    hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
    newButton = new QPushButton(ColorSchemeEditor);
    newButton->setObjectName(QString::fromUtf8("newButton"));

    hboxLayout1->addWidget(newButton);

    deleteButton = new QPushButton(ColorSchemeEditor);
    deleteButton->setObjectName(QString::fromUtf8("deleteButton"));

    hboxLayout1->addWidget(deleteButton);

    renameButton = new QPushButton(ColorSchemeEditor);
    renameButton->setObjectName(QString::fromUtf8("renameButton"));

    hboxLayout1->addWidget(renameButton);

    spacerItem1 = new QSpacerItem(121, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    hboxLayout1->addItem(spacerItem1);


    gridLayout->addLayout(hboxLayout1, 1, 1, 1, 1);

    csProperties = new QTabWidget(ColorSchemeEditor);
    csProperties->setObjectName(QString::fromUtf8("csProperties"));
    csDetails = new QWidget();
    csDetails->setObjectName(QString::fromUtf8("csDetails"));
    csProperties->addTab(csDetails, QString());

    gridLayout->addWidget(csProperties, 0, 1, 1, 1);

    csNames = new Q3ListBox(ColorSchemeEditor);
    csNames->setObjectName(QString::fromUtf8("csNames"));
    QSizePolicy sizePolicy(static_cast<QSizePolicy::Policy>(0), static_cast<QSizePolicy::Policy>(7));
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);
    sizePolicy.setHeightForWidth(csNames->sizePolicy().hasHeightForWidth());
    csNames->setSizePolicy(sizePolicy);

    gridLayout->addWidget(csNames, 0, 0, 2, 1);


    retranslateUi(ColorSchemeEditor);
    QObject::connect(buttonOk, SIGNAL(clicked()), ColorSchemeEditor, SLOT(accept()));
    QObject::connect(buttonCancel, SIGNAL(clicked()), ColorSchemeEditor, SLOT(reject()));
    QObject::connect(newButton, SIGNAL(clicked()), ColorSchemeEditor, SLOT(OnNewScheme()));
    QObject::connect(deleteButton, SIGNAL(clicked()), ColorSchemeEditor, SLOT(OnDeleteScheme()));
    QObject::connect(renameButton, SIGNAL(clicked()), ColorSchemeEditor, SLOT(OnRenameScheme()));
    QObject::connect(csNames, SIGNAL(selected(QString)), ColorSchemeEditor, SLOT(OnSelectScheme(QString)));
    QObject::connect(csNames, SIGNAL(selectionChanged()), ColorSchemeEditor, SLOT(OnSchemeSelectionChanged()));

    QMetaObject::connectSlotsByName(ColorSchemeEditor);
    } // setupUi

    void retranslateUi(QDialog *ColorSchemeEditor)
    {
    ColorSchemeEditor->setWindowTitle(QApplication::translate("ColorSchemeEditor", "Color Scheme Editor", 0, QApplication::UnicodeUTF8));
    buttonHelp->setText(QApplication::translate("ColorSchemeEditor", "&Help", 0, QApplication::UnicodeUTF8));
    buttonHelp->setShortcut(QApplication::translate("ColorSchemeEditor", "F1", 0, QApplication::UnicodeUTF8));
    buttonOk->setText(QApplication::translate("ColorSchemeEditor", "&OK", 0, QApplication::UnicodeUTF8));
    buttonOk->setShortcut(QString());
    buttonCancel->setText(QApplication::translate("ColorSchemeEditor", "&Cancel", 0, QApplication::UnicodeUTF8));
    buttonCancel->setShortcut(QString());
    newButton->setText(QApplication::translate("ColorSchemeEditor", "New", 0, QApplication::UnicodeUTF8));
    deleteButton->setText(QApplication::translate("ColorSchemeEditor", "Delete", 0, QApplication::UnicodeUTF8));
    renameButton->setText(QApplication::translate("ColorSchemeEditor", "Rename", 0, QApplication::UnicodeUTF8));
    csProperties->setTabText(csProperties->indexOf(csDetails), QApplication::translate("ColorSchemeEditor", "Properties", 0, QApplication::UnicodeUTF8));
    csNames->clear();
    csNames->insertItem(QApplication::translate("ColorSchemeEditor", "New Item", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(ColorSchemeEditor);
    } // retranslateUi

};

namespace Ui {
    class ColorSchemeEditor: public Ui_ColorSchemeEditor {};
} // namespace Ui

#endif // UI_COLORSCHEMEEDITOR_H
