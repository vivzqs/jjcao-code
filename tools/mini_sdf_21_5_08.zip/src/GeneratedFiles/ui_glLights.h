/********************************************************************************
** Form generated from reading ui file 'glLights.ui'
**
** Created: Wed May 21 01:35:48 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_GLLIGHTS_H
#define UI_GLLIGHTS_H

#include <Qt3Support/Q3Frame>
#include <Qt3Support/Q3GroupBox>
#include <Qt3Support/Q3ListBox>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>

class Ui_ConfigureGlLights
{
public:
    Q3GroupBox *groupBox1;
    QPushButton *ambient_color;
    QLabel *ambient_color_label;
    QPushButton *apply_button;
    QLabel *textLabel3_2;
    QLineEdit *posx;
    QLabel *textLabel3;
    QLineEdit *posy;
    QLabel *textLabel3_3;
    QLabel *diffuse_color_label;
    QPushButton *diffuse_color;
    QLabel *specular_color_label;
    QPushButton *specular_color;
    QLineEdit *posz;
    Q3Frame *frame3;
    Q3ListBox *saved_configs;
    QPushButton *load_config;
    QPushButton *save_config;
    QCheckBox *light_enabled;
    QLabel *textLabel1;
    QComboBox *selected_light;
    QLabel *textLabel2;
    QRadioButton *type_point;
    QRadioButton *type_parallel;
    QPushButton *ok_button;

    void setupUi(QDialog *ConfigureGlLights)
    {
    if (ConfigureGlLights->objectName().isEmpty())
        ConfigureGlLights->setObjectName(QString::fromUtf8("ConfigureGlLights"));
    QSize size(290, 456);
    size = size.expandedTo(ConfigureGlLights->minimumSizeHint());
    ConfigureGlLights->resize(size);
    ConfigureGlLights->setWindowIcon(QIcon());
    groupBox1 = new Q3GroupBox(ConfigureGlLights);
    groupBox1->setObjectName(QString::fromUtf8("groupBox1"));
    groupBox1->setGeometry(QRect(10, 87, 271, 181));
    ambient_color = new QPushButton(groupBox1);
    ambient_color->setObjectName(QString::fromUtf8("ambient_color"));
    ambient_color->setGeometry(QRect(140, 90, 79, 25));
    ambient_color->setFlat(false);
    ambient_color_label = new QLabel(groupBox1);
    ambient_color_label->setObjectName(QString::fromUtf8("ambient_color_label"));
    ambient_color_label->setGeometry(QRect(225, 90, 25, 25));
    ambient_color_label->setMinimumSize(QSize(25, 0));
    ambient_color_label->setFrameShape(QFrame::Box);
    ambient_color_label->setFrameShadow(QFrame::Sunken);
    ambient_color_label->setScaledContents(true);
    ambient_color_label->setWordWrap(false);
    apply_button = new QPushButton(groupBox1);
    apply_button->setObjectName(QString::fromUtf8("apply_button"));
    apply_button->setGeometry(QRect(193, 152, 77, 25));
    textLabel3_2 = new QLabel(groupBox1);
    textLabel3_2->setObjectName(QString::fromUtf8("textLabel3_2"));
    textLabel3_2->setGeometry(QRect(18, 33, 46, 20));
    textLabel3_2->setWordWrap(false);
    posx = new QLineEdit(groupBox1);
    posx->setObjectName(QString::fromUtf8("posx"));
    posx->setGeometry(QRect(70, 5, 120, 20));
    posx->setMinimumSize(QSize(120, 0));
    textLabel3 = new QLabel(groupBox1);
    textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
    textLabel3->setGeometry(QRect(18, 5, 46, 20));
    textLabel3->setWordWrap(false);
    posy = new QLineEdit(groupBox1);
    posy->setObjectName(QString::fromUtf8("posy"));
    posy->setGeometry(QRect(70, 33, 120, 20));
    posy->setMinimumSize(QSize(120, 0));
    textLabel3_3 = new QLabel(groupBox1);
    textLabel3_3->setObjectName(QString::fromUtf8("textLabel3_3"));
    textLabel3_3->setGeometry(QRect(18, 61, 46, 20));
    textLabel3_3->setWordWrap(false);
    diffuse_color_label = new QLabel(groupBox1);
    diffuse_color_label->setObjectName(QString::fromUtf8("diffuse_color_label"));
    diffuse_color_label->setGeometry(QRect(100, 86, 25, 25));
    diffuse_color_label->setMinimumSize(QSize(25, 0));
    diffuse_color_label->setFrameShape(QFrame::Box);
    diffuse_color_label->setFrameShadow(QFrame::Sunken);
    diffuse_color_label->setScaledContents(true);
    diffuse_color_label->setWordWrap(false);
    diffuse_color = new QPushButton(groupBox1);
    diffuse_color->setObjectName(QString::fromUtf8("diffuse_color"));
    diffuse_color->setGeometry(QRect(17, 86, 77, 25));
    diffuse_color->setFlat(false);
    specular_color_label = new QLabel(groupBox1);
    specular_color_label->setObjectName(QString::fromUtf8("specular_color_label"));
    specular_color_label->setGeometry(QRect(102, 119, 25, 25));
    specular_color_label->setMinimumSize(QSize(25, 0));
    specular_color_label->setFrameShape(QFrame::Box);
    specular_color_label->setFrameShadow(QFrame::Sunken);
    specular_color_label->setScaledContents(true);
    specular_color_label->setWordWrap(false);
    specular_color = new QPushButton(groupBox1);
    specular_color->setObjectName(QString::fromUtf8("specular_color"));
    specular_color->setGeometry(QRect(17, 119, 79, 25));
    specular_color->setFlat(false);
    posz = new QLineEdit(groupBox1);
    posz->setObjectName(QString::fromUtf8("posz"));
    posz->setGeometry(QRect(70, 61, 120, 20));
    posz->setMinimumSize(QSize(120, 0));
    frame3 = new Q3Frame(ConfigureGlLights);
    frame3->setObjectName(QString::fromUtf8("frame3"));
    frame3->setGeometry(QRect(9, 274, 272, 133));
    frame3->setFrameShape(QFrame::NoFrame);
    frame3->setFrameShadow(QFrame::Plain);
    saved_configs = new Q3ListBox(frame3);
    saved_configs->setObjectName(QString::fromUtf8("saved_configs"));
    saved_configs->setGeometry(QRect(119, 9, 144, 115));
    load_config = new QPushButton(frame3);
    load_config->setObjectName(QString::fromUtf8("load_config"));
    load_config->setGeometry(QRect(10, 10, 102, 25));
    save_config = new QPushButton(frame3);
    save_config->setObjectName(QString::fromUtf8("save_config"));
    save_config->setGeometry(QRect(10, 41, 102, 25));
    light_enabled = new QCheckBox(ConfigureGlLights);
    light_enabled->setObjectName(QString::fromUtf8("light_enabled"));
    light_enabled->setGeometry(QRect(145, 17, 62, 18));
    textLabel1 = new QLabel(ConfigureGlLights);
    textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
    textLabel1->setGeometry(QRect(10, 10, 64, 32));
    textLabel1->setWordWrap(false);
    selected_light = new QComboBox(ConfigureGlLights);
    selected_light->setObjectName(QString::fromUtf8("selected_light"));
    selected_light->setGeometry(QRect(80, 16, 59, 20));
    textLabel2 = new QLabel(ConfigureGlLights);
    textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
    textLabel2->setGeometry(QRect(10, 50, 48, 32));
    textLabel2->setWordWrap(false);
    type_point = new QRadioButton(ConfigureGlLights);
    type_point->setObjectName(QString::fromUtf8("type_point"));
    type_point->setEnabled(false);
    type_point->setGeometry(QRect(64, 57, 48, 18));
    type_parallel = new QRadioButton(ConfigureGlLights);
    type_parallel->setObjectName(QString::fromUtf8("type_parallel"));
    type_parallel->setEnabled(false);
    type_parallel->setGeometry(QRect(118, 57, 58, 18));
    ok_button = new QPushButton(ConfigureGlLights);
    ok_button->setObjectName(QString::fromUtf8("ok_button"));
    ok_button->setGeometry(QRect(10, 417, 132, 25));

    retranslateUi(ConfigureGlLights);
    QObject::connect(selected_light, SIGNAL(activated(int)), ConfigureGlLights, SLOT(OnSelectLight(int)));
    QObject::connect(ok_button, SIGNAL(clicked()), ConfigureGlLights, SLOT(close()));
    QObject::connect(diffuse_color, SIGNAL(clicked()), ConfigureGlLights, SLOT(OnSelectDiffuse()));
    QObject::connect(specular_color, SIGNAL(clicked()), ConfigureGlLights, SLOT(OnSelectSpecular()));
    QObject::connect(apply_button, SIGNAL(clicked()), ConfigureGlLights, SLOT(OnApplyLightSettings()));
    QObject::connect(load_config, SIGNAL(clicked()), ConfigureGlLights, SLOT(LoadConfiguration()));
    QObject::connect(save_config, SIGNAL(clicked()), ConfigureGlLights, SLOT(SaveConfiguration()));
    QObject::connect(saved_configs, SIGNAL(selected(int)), ConfigureGlLights, SLOT(SaveConfiguration(int)));

    QMetaObject::connectSlotsByName(ConfigureGlLights);
    } // setupUi

    void retranslateUi(QDialog *ConfigureGlLights)
    {
    ConfigureGlLights->setWindowTitle(QApplication::translate("ConfigureGlLights", "Configure GL Lights", 0, QApplication::UnicodeUTF8));
    groupBox1->setTitle(QString());
    ambient_color->setText(QApplication::translate("ConfigureGlLights", "Ambient Color", 0, QApplication::UnicodeUTF8));
    apply_button->setText(QApplication::translate("ConfigureGlLights", "Apply", 0, QApplication::UnicodeUTF8));
    textLabel3_2->setText(QApplication::translate("ConfigureGlLights", "Position Y", 0, QApplication::UnicodeUTF8));
    textLabel3->setText(QApplication::translate("ConfigureGlLights", "Position X", 0, QApplication::UnicodeUTF8));
    textLabel3_3->setText(QApplication::translate("ConfigureGlLights", "Position Z", 0, QApplication::UnicodeUTF8));
    diffuse_color->setText(QApplication::translate("ConfigureGlLights", "Diffuse Color", 0, QApplication::UnicodeUTF8));
    specular_color->setText(QApplication::translate("ConfigureGlLights", "Specular Color", 0, QApplication::UnicodeUTF8));
    load_config->setText(QApplication::translate("ConfigureGlLights", "Load Configuration", 0, QApplication::UnicodeUTF8));
    save_config->setText(QApplication::translate("ConfigureGlLights", "Save Configuration", 0, QApplication::UnicodeUTF8));
    light_enabled->setText(QApplication::translate("ConfigureGlLights", "Enabled", 0, QApplication::UnicodeUTF8));
    textLabel1->setText(QApplication::translate("ConfigureGlLights", "Selected light", 0, QApplication::UnicodeUTF8));
    selected_light->clear();
    selected_light->insertItems(0, QStringList()
     << QApplication::translate("ConfigureGlLights", "Light 0", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ConfigureGlLights", "Light 1", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ConfigureGlLights", "Light 2", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ConfigureGlLights", "Light 3", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ConfigureGlLights", "Light 4", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ConfigureGlLights", "Light 5", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ConfigureGlLights", "Light 6", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("ConfigureGlLights", "Light 7", 0, QApplication::UnicodeUTF8)
    );
    textLabel2->setText(QApplication::translate("ConfigureGlLights", "Light type", 0, QApplication::UnicodeUTF8));
    type_point->setText(QApplication::translate("ConfigureGlLights", "Point", 0, QApplication::UnicodeUTF8));
    type_parallel->setText(QApplication::translate("ConfigureGlLights", "Parallel", 0, QApplication::UnicodeUTF8));
    ok_button->setText(QApplication::translate("ConfigureGlLights", "Close", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(ConfigureGlLights);
    } // retranslateUi

};

namespace Ui {
    class ConfigureGlLights: public Ui_ConfigureGlLights {};
} // namespace Ui

#endif // UI_GLLIGHTS_H
