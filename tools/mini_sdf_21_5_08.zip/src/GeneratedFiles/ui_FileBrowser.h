/********************************************************************************
** Form generated from reading ui file 'FileBrowser.ui'
**
** Created: Wed May 21 01:35:48 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_FILEBROWSER_H
#define UI_FILEBROWSER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QSplitter>
#include <QtGui/QTableView>
#include <QtGui/QWidget>
#include "FileBrowser.h"

class Ui_FileBrowserClass
{
public:
    QHBoxLayout *hboxLayout;
    QSplitter *splitter;
    MyTreeView *dirView;
    QTableView *dirFiles;

    void setupUi(QWidget *FileBrowserClass)
    {
    if (FileBrowserClass->objectName().isEmpty())
        FileBrowserClass->setObjectName(QString::fromUtf8("FileBrowserClass"));
    QSize size(274, 471);
    size = size.expandedTo(FileBrowserClass->minimumSizeHint());
    FileBrowserClass->resize(size);
    hboxLayout = new QHBoxLayout(FileBrowserClass);
    hboxLayout->setSpacing(4);
    hboxLayout->setMargin(11);
    hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
    hboxLayout->setContentsMargins(0, 0, 0, 0);
    splitter = new QSplitter(FileBrowserClass);
    splitter->setObjectName(QString::fromUtf8("splitter"));
    splitter->setOrientation(Qt::Vertical);
    dirView = new MyTreeView(splitter);
    dirView->setObjectName(QString::fromUtf8("dirView"));
    splitter->addWidget(dirView);
    dirFiles = new QTableView(splitter);
    dirFiles->setObjectName(QString::fromUtf8("dirFiles"));
    dirFiles->setShowGrid(false);
    dirFiles->setWordWrap(false);
    dirFiles->setCornerButtonEnabled(false);
    splitter->addWidget(dirFiles);

    hboxLayout->addWidget(splitter);


    retranslateUi(FileBrowserClass);

    QMetaObject::connectSlotsByName(FileBrowserClass);
    } // setupUi

    void retranslateUi(QWidget *FileBrowserClass)
    {
    FileBrowserClass->setWindowTitle(QApplication::translate("FileBrowserClass", "FileBrowser", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(FileBrowserClass);
    } // retranslateUi

};

namespace Ui {
    class FileBrowserClass: public Ui_FileBrowserClass {};
} // namespace Ui

#endif // UI_FILEBROWSER_H
