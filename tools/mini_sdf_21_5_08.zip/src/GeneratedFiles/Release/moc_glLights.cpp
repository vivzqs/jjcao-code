/****************************************************************************
** Meta object code from reading C++ file 'glLights.h'
**
** Created: Wed May 21 01:35:49 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../glLights.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'glLights.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_ConfigureGlLights[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      19,   18,   18,   18, 0x05,

 // slots: signature, parameters, type, tag, flags
      43,   34,   18,   18, 0x0a,
      62,   18,   18,   18, 0x0a,
      81,   18,   18,   18, 0x0a,
      99,   18,   18,   18, 0x0a,
     122,   18,   18,   18, 0x0a,
     146,  142,   18,   18, 0x0a,
     169,  142,   18,   18, 0x0a,
     192,   18,   18,   18, 0x0a,
     212,   18,   18,   18, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_ConfigureGlLights[] = {
    "ConfigureGlLights\0\0lightChanged()\0"
    "lightNum\0OnSelectLight(int)\0"
    "OnSelectSpecular()\0OnSelectDiffuse()\0"
    "OnApplyLightSettings()\0LoadConfiguration()\0"
    "num\0LoadConfiguration(int)\0"
    "SaveConfiguration(int)\0SaveConfiguration()\0"
    "on_ambient_color_clicked()\0"
};

const QMetaObject ConfigureGlLights::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_ConfigureGlLights,
      qt_meta_data_ConfigureGlLights, 0 }
};

const QMetaObject *ConfigureGlLights::metaObject() const
{
    return &staticMetaObject;
}

void *ConfigureGlLights::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ConfigureGlLights))
	return static_cast<void*>(const_cast< ConfigureGlLights*>(this));
    return QDialog::qt_metacast(_clname);
}

int ConfigureGlLights::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: lightChanged(); break;
        case 1: OnSelectLight((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: OnSelectSpecular(); break;
        case 3: OnSelectDiffuse(); break;
        case 4: OnApplyLightSettings(); break;
        case 5: LoadConfiguration(); break;
        case 6: LoadConfiguration((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: SaveConfiguration((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: SaveConfiguration(); break;
        case 9: on_ambient_color_clicked(); break;
        }
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void ConfigureGlLights::lightChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
