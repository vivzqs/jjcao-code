/****************************************************************************
** Meta object code from reading C++ file 'CalculateSDF.h'
**
** Created: Wed May 21 01:35:49 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../CalculateSDF.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CalculateSDF.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_CalculateSDFThread[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      33,   20,   19,   19, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_CalculateSDFThread[] = {
    "CalculateSDFThread\0\0numOfOrigins\0"
    "advancedIn(int)\0"
};

const QMetaObject CalculateSDFThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_CalculateSDFThread,
      qt_meta_data_CalculateSDFThread, 0 }
};

const QMetaObject *CalculateSDFThread::metaObject() const
{
    return &staticMetaObject;
}

void *CalculateSDFThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CalculateSDFThread))
	return static_cast<void*>(const_cast< CalculateSDFThread*>(this));
    return QThread::qt_metacast(_clname);
}

int CalculateSDFThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: advancedIn((*reinterpret_cast< int(*)>(_a[1]))); break;
        }
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void CalculateSDFThread::advancedIn(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_CalculateSDF[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      20,   14,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_CalculateSDF[] = {
    "CalculateSDF\0\0delta\0addToProgress(int)\0"
};

const QMetaObject CalculateSDF::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_CalculateSDF,
      qt_meta_data_CalculateSDF, 0 }
};

const QMetaObject *CalculateSDF::metaObject() const
{
    return &staticMetaObject;
}

void *CalculateSDF::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CalculateSDF))
	return static_cast<void*>(const_cast< CalculateSDF*>(this));
    return QObject::qt_metacast(_clname);
}

int CalculateSDF::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: addToProgress((*reinterpret_cast< int(*)>(_a[1]))); break;
        }
        _id -= 1;
    }
    return _id;
}
