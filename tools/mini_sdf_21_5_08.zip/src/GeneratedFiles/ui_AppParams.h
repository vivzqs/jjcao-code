/********************************************************************************
** Form generated from reading ui file 'AppParams.ui'
**
** Created: Wed May 21 01:35:48 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_APPPARAMS_H
#define UI_APPPARAMS_H

#include <Qt3Support/Q3Frame>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>

class Ui_AppParams
{
public:
    QGroupBox *groupBox;
    Q3Frame *frame3;
    QSpinBox *numberOfCones;
    QLabel *textLabel2;
    QSpinBox *coneSeperation;
    QLabel *textLabel3;
    QSpinBox *raysInCone;
    QCheckBox *gaussianWeights;
    QCheckBox *sdf_smoothing;
    QCheckBox *sdf_smoothingAnisotropic;
    QLabel *textLabel1_4;
    QSpinBox *sdf_smoothingIterations;
    QLabel *textLabel1;
    QComboBox *normalizeSDF;
    QLabel *textLabel1_2;
    QPushButton *applyBot;
    QCheckBox *multithreaded;
    QPushButton *buttonOk;
    QPushButton *buttonCancel;
    QPushButton *buttonHelp;
    QCheckBox *normsRev;

    void setupUi(QDialog *AppParams)
    {
    if (AppParams->objectName().isEmpty())
        AppParams->setObjectName(QString::fromUtf8("AppParams"));
    QSize size(254, 383);
    size = size.expandedTo(AppParams->minimumSizeHint());
    AppParams->resize(size);
    AppParams->setSizeGripEnabled(true);
    groupBox = new QGroupBox(AppParams);
    groupBox->setObjectName(QString::fromUtf8("groupBox"));
    groupBox->setGeometry(QRect(10, 30, 231, 251));
    frame3 = new Q3Frame(groupBox);
    frame3->setObjectName(QString::fromUtf8("frame3"));
    frame3->setGeometry(QRect(10, 10, 221, 238));
    frame3->setFrameShape(QFrame::NoFrame);
    frame3->setFrameShadow(QFrame::Plain);
    numberOfCones = new QSpinBox(frame3);
    numberOfCones->setObjectName(QString::fromUtf8("numberOfCones"));
    numberOfCones->setGeometry(QRect(116, 38, 99, 20));
    textLabel2 = new QLabel(frame3);
    textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
    textLabel2->setGeometry(QRect(10, 67, 100, 20));
    textLabel2->setMinimumSize(QSize(100, 0));
    textLabel2->setWordWrap(false);
    coneSeperation = new QSpinBox(frame3);
    coneSeperation->setObjectName(QString::fromUtf8("coneSeperation"));
    coneSeperation->setGeometry(QRect(116, 67, 99, 20));
    textLabel3 = new QLabel(frame3);
    textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
    textLabel3->setGeometry(QRect(10, 95, 100, 20));
    textLabel3->setMinimumSize(QSize(100, 0));
    textLabel3->setWordWrap(false);
    raysInCone = new QSpinBox(frame3);
    raysInCone->setObjectName(QString::fromUtf8("raysInCone"));
    raysInCone->setGeometry(QRect(116, 95, 99, 20));
    gaussianWeights = new QCheckBox(frame3);
    gaussianWeights->setObjectName(QString::fromUtf8("gaussianWeights"));
    gaussianWeights->setGeometry(QRect(10, 124, 152, 18));
    sdf_smoothing = new QCheckBox(frame3);
    sdf_smoothing->setObjectName(QString::fromUtf8("sdf_smoothing"));
    sdf_smoothing->setGeometry(QRect(10, 152, 152, 18));
    sdf_smoothingAnisotropic = new QCheckBox(frame3);
    sdf_smoothingAnisotropic->setObjectName(QString::fromUtf8("sdf_smoothingAnisotropic"));
    sdf_smoothingAnisotropic->setGeometry(QRect(10, 181, 142, 18));
    textLabel1_4 = new QLabel(frame3);
    textLabel1_4->setObjectName(QString::fromUtf8("textLabel1_4"));
    textLabel1_4->setGeometry(QRect(10, 208, 99, 20));
    textLabel1_4->setWordWrap(false);
    sdf_smoothingIterations = new QSpinBox(frame3);
    sdf_smoothingIterations->setObjectName(QString::fromUtf8("sdf_smoothingIterations"));
    sdf_smoothingIterations->setGeometry(QRect(115, 208, 99, 20));
    sdf_smoothingIterations->setMinimum(1);
    sdf_smoothingIterations->setMaximum(10);
    textLabel1 = new QLabel(frame3);
    textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
    textLabel1->setGeometry(QRect(10, 10, 114, 20));
    textLabel1->setWordWrap(false);
    normalizeSDF = new QComboBox(frame3);
    normalizeSDF->setObjectName(QString::fromUtf8("normalizeSDF"));
    normalizeSDF->setGeometry(QRect(130, 10, 69, 20));
    textLabel1_2 = new QLabel(frame3);
    textLabel1_2->setObjectName(QString::fromUtf8("textLabel1_2"));
    textLabel1_2->setGeometry(QRect(10, 38, 100, 21));
    textLabel1_2->setMinimumSize(QSize(100, 0));
    textLabel1_2->setWordWrap(false);
    applyBot = new QPushButton(AppParams);
    applyBot->setObjectName(QString::fromUtf8("applyBot"));
    applyBot->setGeometry(QRect(10, 320, 75, 23));
    multithreaded = new QCheckBox(AppParams);
    multithreaded->setObjectName(QString::fromUtf8("multithreaded"));
    multithreaded->setGeometry(QRect(11, 12, 161, 18));
    buttonOk = new QPushButton(AppParams);
    buttonOk->setObjectName(QString::fromUtf8("buttonOk"));
    buttonOk->setGeometry(QRect(90, 320, 77, 25));
    buttonOk->setAutoDefault(true);
    buttonOk->setDefault(true);
    buttonCancel = new QPushButton(AppParams);
    buttonCancel->setObjectName(QString::fromUtf8("buttonCancel"));
    buttonCancel->setGeometry(QRect(170, 320, 77, 25));
    buttonCancel->setAutoDefault(true);
    buttonHelp = new QPushButton(AppParams);
    buttonHelp->setObjectName(QString::fromUtf8("buttonHelp"));
    buttonHelp->setGeometry(QRect(10, 350, 77, 25));
    buttonHelp->setAutoDefault(true);
    normsRev = new QCheckBox(AppParams);
    normsRev->setObjectName(QString::fromUtf8("normsRev"));
    normsRev->setGeometry(QRect(20, 290, 111, 18));

    retranslateUi(AppParams);
    QObject::connect(buttonOk, SIGNAL(clicked()), AppParams, SLOT(accept()));
    QObject::connect(buttonCancel, SIGNAL(clicked()), AppParams, SLOT(reject()));

    QMetaObject::connectSlotsByName(AppParams);
    } // setupUi

    void retranslateUi(QDialog *AppParams)
    {
    AppParams->setWindowTitle(QApplication::translate("AppParams", "Application Parameters", 0, QApplication::UnicodeUTF8));
    groupBox->setTitle(QApplication::translate("AppParams", "SDF", 0, QApplication::UnicodeUTF8));
    frame3->setToolTip(QApplication::translate("AppParams", "Shape Diameter Function", 0, QApplication::UnicodeUTF8));
    textLabel2->setText(QApplication::translate("AppParams", "Cone seperation", 0, QApplication::UnicodeUTF8));
    textLabel3->setText(QApplication::translate("AppParams", "Rays in cone", 0, QApplication::UnicodeUTF8));
    gaussianWeights->setText(QApplication::translate("AppParams", "Use gaussian weights", 0, QApplication::UnicodeUTF8));
    sdf_smoothing->setText(QApplication::translate("AppParams", "Apply smoothing", 0, QApplication::UnicodeUTF8));
    sdf_smoothingAnisotropic->setText(QApplication::translate("AppParams", "Anisotropic smoothing", 0, QApplication::UnicodeUTF8));
    textLabel1_4->setText(QApplication::translate("AppParams", "Smoothing iterations", 0, QApplication::UnicodeUTF8));
    textLabel1->setText(QApplication::translate("AppParams", "Normalize SDF calculation", 0, QApplication::UnicodeUTF8));
    textLabel1_2->setText(QApplication::translate("AppParams", "Number of cones", 0, QApplication::UnicodeUTF8));
    applyBot->setText(QApplication::translate("AppParams", "Apply!", 0, QApplication::UnicodeUTF8));
    multithreaded->setText(QApplication::translate("AppParams", "Work multi-threaded", 0, QApplication::UnicodeUTF8));
    buttonOk->setText(QApplication::translate("AppParams", "&OK", 0, QApplication::UnicodeUTF8));
    buttonOk->setShortcut(QString());
    buttonCancel->setText(QApplication::translate("AppParams", "&Cancel", 0, QApplication::UnicodeUTF8));
    buttonCancel->setShortcut(QString());
    buttonHelp->setText(QApplication::translate("AppParams", "&Help", 0, QApplication::UnicodeUTF8));
    buttonHelp->setShortcut(QApplication::translate("AppParams", "F1", 0, QApplication::UnicodeUTF8));
    normsRev->setText(QApplication::translate("AppParams", "Normals Reversed", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(AppParams);
    } // retranslateUi

};

namespace Ui {
    class AppParams: public Ui_AppParams {};
} // namespace Ui

#endif // UI_APPPARAMS_H
