/****************************************************************************
** Meta object code from reading C++ file 'ColorButton.h'
**
** Created: Tue May 20 02:41:06 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../ColorButton.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ColorButton.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_ColorButton[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      19,   13,   12,   12, 0x05,
      41,   12,   12,   12, 0x05,

 // slots: signature, parameters, type, tag, flags
      51,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ColorButton[] = {
    "ColorButton\0\0Color\0colorSelected(QColor)\0"
    "changed()\0OnClicked()\0"
};

const QMetaObject ColorButton::staticMetaObject = {
    { &QPushButton::staticMetaObject, qt_meta_stringdata_ColorButton,
      qt_meta_data_ColorButton, 0 }
};

const QMetaObject *ColorButton::metaObject() const
{
    return &staticMetaObject;
}

void *ColorButton::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ColorButton))
	return static_cast<void*>(const_cast< ColorButton*>(this));
    return QPushButton::qt_metacast(_clname);
}

int ColorButton::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QPushButton::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: colorSelected((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 1: changed(); break;
        case 2: OnClicked(); break;
        }
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void ColorButton::colorSelected(const QColor & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ColorButton::changed()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}
static const uint qt_meta_data_ColorLabel[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      18,   12,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ColorLabel[] = {
    "ColorLabel\0\0color\0OnSetColor(QColor)\0"
};

const QMetaObject ColorLabel::staticMetaObject = {
    { &QLabel::staticMetaObject, qt_meta_stringdata_ColorLabel,
      qt_meta_data_ColorLabel, 0 }
};

const QMetaObject *ColorLabel::metaObject() const
{
    return &staticMetaObject;
}

void *ColorLabel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ColorLabel))
	return static_cast<void*>(const_cast< ColorLabel*>(this));
    return QLabel::qt_metacast(_clname);
}

int ColorLabel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QLabel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: OnSetColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        }
        _id -= 1;
    }
    return _id;
}
