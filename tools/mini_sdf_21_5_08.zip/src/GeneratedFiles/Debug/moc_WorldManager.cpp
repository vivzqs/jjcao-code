/****************************************************************************
** Meta object code from reading C++ file 'WorldManager.h'
**
** Created: Tue May 20 02:41:06 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../WorldManager.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'WorldManager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_WorldManager[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x05,
      33,   30,   13,   13, 0x05,
      71,   57,   13,   13, 0x05,
      98,   13,   13,   13, 0x05,
     127,   13,   13,   13, 0x05,
     182,  142,   13,   13, 0x05,
     247,  234,   13,   13, 0x05,
     296,  283,   13,   13, 0x05,
     340,  332,   13,   13, 0x05,
     368,  357,   13,   13, 0x05,
     395,  389,   13,   13, 0x05,
     419,   30,   13,   13, 0x05,

 // slots: signature, parameters, type, tag, flags
     443,   13,   13,   13, 0x0a,
     459,   13,   13,   13, 0x0a,
     472,   13,   13,   13, 0x0a,
     481,   13,   13,   13, 0x0a,
     511,  496,   13,   13, 0x0a,
     557,   30,   13,   13, 0x0a,
     600,  581,   13,   13, 0x0a,
     629,   13,   13,   13, 0x0a,
     651,   13,   13,   13, 0x0a,
     695,  679,   13,   13, 0x0a,
     741,   13,   13,   13, 0x0a,
     774,  758,   13,   13, 0x0a,
     831,  823,   13,   13, 0x2a,
     890,  876,   13,   13, 0x0a,
     924,  911,   13,   13, 0x0a,
     952,  234,   13,   13, 0x0a,
     988,  978,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_WorldManager[] = {
    "WorldManager\0\0finishedPaint()\0id\0"
    "ObjectSelected(QString)\0id,facetIndex\0"
    "FacetSelected(QString,int)\0"
    "RenderingParametersChanged()\0"
    "RedrawNeeded()\0tabIndex,centerx,centery,centerz,radius\0"
    "SceneParametersChanged(int,float,float,float,float)\0"
    "facetPainter\0FacetPainterSelected(FacetPainter*)\0"
    "debugPainter\0DebugPainterSelected(DebugPainter*)\0"
    "message\0message(QString)\0message,ms\0"
    "message(QString,int)\0index\0"
    "changeFacetPainter(int)\0doRemoveObject(QString)\0"
    "redoAllColors()\0invalidate()\0OnDraw()\0"
    "OnSelectDraw()\0ao,onlyPart,dm\0"
    "OnAddObject(AppObject*,TStubData*,DrawMethod)\0"
    "OnRemoveObject(QString)\0id,geometryChanged\0"
    "OnChangeObject(QString,bool)\0"
    "OnViewerInitialized()\0OnEditRenderingParameters()\0"
    "renderingParams\0"
    "OnRenderingPrametersChanged(RenderingParams*)\0"
    "OnEditGLLights()\0i,modif,extPart\0"
    "OnObjectSelected(uint,Qt::KeyboardModifiers,int)\0"
    "i,modif\0OnObjectSelected(uint,Qt::KeyboardModifiers)\0"
    "selectionMode\0OnSelectionMode(int)\0"
    "width,height\0OnWorldSizeChanged(int,int)\0"
    "OnSelectFacetPainter(int)\0key,state\0"
    "OnFunctionKeyPressed(int,Qt::ButtonState)\0"
};

const QMetaObject WorldManager::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_WorldManager,
      qt_meta_data_WorldManager, 0 }
};

const QMetaObject *WorldManager::metaObject() const
{
    return &staticMetaObject;
}

void *WorldManager::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_WorldManager))
	return static_cast<void*>(const_cast< WorldManager*>(this));
    return QObject::qt_metacast(_clname);
}

int WorldManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: finishedPaint(); break;
        case 1: ObjectSelected((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: FacetSelected((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 3: RenderingParametersChanged(); break;
        case 4: RedrawNeeded(); break;
        case 5: SceneParametersChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4])),(*reinterpret_cast< float(*)>(_a[5]))); break;
        case 6: FacetPainterSelected((*reinterpret_cast< FacetPainter*(*)>(_a[1]))); break;
        case 7: DebugPainterSelected((*reinterpret_cast< DebugPainter*(*)>(_a[1]))); break;
        case 8: message((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: message((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 10: changeFacetPainter((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 11: doRemoveObject((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: redoAllColors(); break;
        case 13: invalidate(); break;
        case 14: OnDraw(); break;
        case 15: OnSelectDraw(); break;
        case 16: OnAddObject((*reinterpret_cast< AppObject*(*)>(_a[1])),(*reinterpret_cast< TStubData*(*)>(_a[2])),(*reinterpret_cast< DrawMethod(*)>(_a[3]))); break;
        case 17: OnRemoveObject((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 18: OnChangeObject((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 19: OnViewerInitialized(); break;
        case 20: OnEditRenderingParameters(); break;
        case 21: OnRenderingPrametersChanged((*reinterpret_cast< RenderingParams*(*)>(_a[1]))); break;
        case 22: OnEditGLLights(); break;
        case 23: OnObjectSelected((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< Qt::KeyboardModifiers(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 24: OnObjectSelected((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< Qt::KeyboardModifiers(*)>(_a[2]))); break;
        case 25: OnSelectionMode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: OnWorldSizeChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 27: OnSelectFacetPainter((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: OnFunctionKeyPressed((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< Qt::ButtonState(*)>(_a[2]))); break;
        }
        _id -= 29;
    }
    return _id;
}

// SIGNAL 0
void WorldManager::finishedPaint()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void WorldManager::ObjectSelected(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void WorldManager::FacetSelected(const QString & _t1, const int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void WorldManager::RenderingParametersChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void WorldManager::RedrawNeeded()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void WorldManager::SceneParametersChanged(int _t1, float _t2, float _t3, float _t4, float _t5)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void WorldManager::FacetPainterSelected(FacetPainter * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void WorldManager::DebugPainterSelected(DebugPainter * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void WorldManager::message(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void WorldManager::message(const QString & _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void WorldManager::changeFacetPainter(const int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void WorldManager::doRemoveObject(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}
