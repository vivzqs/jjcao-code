/****************************************************************************
** Meta object code from reading C++ file 'ColorSchemeEditor.h'
**
** Created: Tue May 20 02:41:06 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../ColorSchemeEditor.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ColorSchemeEditor.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_ColorSchemeEditor[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      19,   18,   18,   18, 0x0a,
      36,   18,   18,   18, 0x0a,
      53,   18,   18,   18, 0x0a,
      74,   67,   18,   18, 0x0a,
      98,   18,   18,   18, 0x0a,
     107,   18,   18,   18, 0x0a,
     125,   18,   18,   18, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ColorSchemeEditor[] = {
    "ColorSchemeEditor\0\0OnDeleteScheme()\0"
    "OnRenameScheme()\0OnNewScheme()\0csName\0"
    "OnSelectScheme(QString)\0accept()\0"
    "OnSchemeChanged()\0OnSchemeSelectionChanged()\0"
};

const QMetaObject ColorSchemeEditor::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_ColorSchemeEditor,
      qt_meta_data_ColorSchemeEditor, 0 }
};

const QMetaObject *ColorSchemeEditor::metaObject() const
{
    return &staticMetaObject;
}

void *ColorSchemeEditor::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ColorSchemeEditor))
	return static_cast<void*>(const_cast< ColorSchemeEditor*>(this));
    return QDialog::qt_metacast(_clname);
}

int ColorSchemeEditor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: OnDeleteScheme(); break;
        case 1: OnRenameScheme(); break;
        case 2: OnNewScheme(); break;
        case 3: OnSelectScheme((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: accept(); break;
        case 5: OnSchemeChanged(); break;
        case 6: OnSchemeSelectionChanged(); break;
        }
        _id -= 7;
    }
    return _id;
}
