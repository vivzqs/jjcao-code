/****************************************************************************
** Meta object code from reading C++ file 'FileBrowser.h'
**
** Created: Tue May 20 02:41:06 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../FileBrowser.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'FileBrowser.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_MyTreeView[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_MyTreeView[] = {
    "MyTreeView\0\0itemSelectionChanged()\0"
};

const QMetaObject MyTreeView::staticMetaObject = {
    { &QTreeView::staticMetaObject, qt_meta_stringdata_MyTreeView,
      qt_meta_data_MyTreeView, 0 }
};

const QMetaObject *MyTreeView::metaObject() const
{
    return &staticMetaObject;
}

void *MyTreeView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyTreeView))
	return static_cast<void*>(const_cast< MyTreeView*>(this));
    return QTreeView::qt_metacast(_clname);
}

int MyTreeView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTreeView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: itemSelectionChanged(); break;
        }
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void MyTreeView::itemSelectionChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
static const uint qt_meta_data_FileBrowser[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      18,   13,   12,   12, 0x05,

 // slots: signature, parameters, type, tag, flags
      36,   12,   12,   12, 0x08,
      55,   49,   12,   12, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_FileBrowser[] = {
    "FileBrowser\0\0name\0openFile(QString)\0"
    "changedDir()\0index\0selectFile(QModelIndex)\0"
};

const QMetaObject FileBrowser::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_FileBrowser,
      qt_meta_data_FileBrowser, 0 }
};

const QMetaObject *FileBrowser::metaObject() const
{
    return &staticMetaObject;
}

void *FileBrowser::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FileBrowser))
	return static_cast<void*>(const_cast< FileBrowser*>(this));
    return QWidget::qt_metacast(_clname);
}

int FileBrowser::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: openFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: changedDir(); break;
        case 2: selectFile((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        }
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void FileBrowser::openFile(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
