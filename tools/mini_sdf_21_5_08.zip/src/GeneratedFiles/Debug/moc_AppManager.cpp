/****************************************************************************
** Meta object code from reading C++ file 'AppManager.h'
**
** Created: Wed May 21 01:33:31 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../AppManager.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'AppManager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_AppManager[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,
      24,   11,   11,   11, 0x05,
      56,   41,   11,   11, 0x05,
     105,  102,   11,   11, 0x05,
     147,  128,   11,   11, 0x05,
     183,  175,   11,   11, 0x05,
     211,  200,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
     241,  232,   11,   11, 0x0a,
     268,  259,   11,   11, 0x0a,
     290,   11,   11,   11, 0x0a,
     304,   11,   11,   11, 0x0a,
     327,  321,   11,   11, 0x0a,
     366,  102,   11,   11, 0x0a,
     388,   11,   11,   11, 0x0a,
     403,   11,   11,   11, 0x0a,
     426,   11,   11,   11, 0x0a,
     449,   11,   11,   11, 0x0a,
     472,   11,   11,   11, 0x0a,
     497,   11,   11,   11, 0x0a,
     520,   11,   11,   11, 0x0a,
     549,   11,   11,   11, 0x0a,
     567,   11,   11,   11, 0x0a,
     592,   11,   11,   11, 0x0a,
     611,   11,   11,   11, 0x0a,
     625,   11,   11,   11, 0x0a,
     648,  102,   11,   11, 0x0a,
     688,  674,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_AppManager[] = {
    "AppManager\0\0showParts()\0ObjectsChanged()\0"
    "ao,onlyPart,dm\0"
    "ObjectAdded(AppObject*,TStubData*,DrawMethod)\0"
    "id\0ObjectRemoved(QString)\0id,geometryChanged\0"
    "ObjectChanged(QString,bool)\0message\0"
    "message(QString)\0message,ms\0"
    "message(QString,int)\0filename\0"
    "openFile(QString)\0fileName\0"
    "saveSnapshot(QString)\0appParamsOk()\0"
    "appParamsApply()\0key,s\0"
    "OnArrowKeyPressed(int,Qt::ButtonState)\0"
    "removeObject(QString)\0OnLoadObject()\0"
    "OnLoadObjectFeatures()\0OnDiffObjectFeatures()\0"
    "OnSaveObjectFeatures()\0OnCalculateSDFVertices()\0"
    "OnCalculateSDFFacets()\0"
    "OnCalculateSDFFacetsForAll()\0"
    "OnRemoveObjects()\0OnRemoveSelectedObject()\0"
    "OnReverseNormals()\0OnAppParams()\0"
    "OnSelectedObjectInfo()\0OnObjectSelected(QString)\0"
    "id,facetIndex\0OnFacetSelected(QString,int)\0"
};

const QMetaObject AppManager::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_AppManager,
      qt_meta_data_AppManager, 0 }
};

const QMetaObject *AppManager::metaObject() const
{
    return &staticMetaObject;
}

void *AppManager::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AppManager))
	return static_cast<void*>(const_cast< AppManager*>(this));
    return QObject::qt_metacast(_clname);
}

int AppManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: showParts(); break;
        case 1: ObjectsChanged(); break;
        case 2: ObjectAdded((*reinterpret_cast< AppObject*(*)>(_a[1])),(*reinterpret_cast< TStubData*(*)>(_a[2])),(*reinterpret_cast< DrawMethod(*)>(_a[3]))); break;
        case 3: ObjectRemoved((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: ObjectChanged((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 5: message((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: message((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 7: openFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: saveSnapshot((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: appParamsOk(); break;
        case 10: appParamsApply(); break;
        case 11: OnArrowKeyPressed((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< Qt::ButtonState(*)>(_a[2]))); break;
        case 12: removeObject((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: OnLoadObject(); break;
        case 14: OnLoadObjectFeatures(); break;
        case 15: OnDiffObjectFeatures(); break;
        case 16: OnSaveObjectFeatures(); break;
        case 17: OnCalculateSDFVertices(); break;
        case 18: OnCalculateSDFFacets(); break;
        case 19: OnCalculateSDFFacetsForAll(); break;
        case 20: OnRemoveObjects(); break;
        case 21: OnRemoveSelectedObject(); break;
        case 22: OnReverseNormals(); break;
        case 23: OnAppParams(); break;
        case 24: OnSelectedObjectInfo(); break;
        case 25: OnObjectSelected((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 26: OnFacetSelected((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        }
        _id -= 27;
    }
    return _id;
}

// SIGNAL 0
void AppManager::showParts()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void AppManager::ObjectsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void AppManager::ObjectAdded(AppObject * _t1, TStubData * _t2, DrawMethod _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void AppManager::ObjectRemoved(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void AppManager::ObjectChanged(const QString & _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void AppManager::message(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void AppManager::message(const QString & _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
