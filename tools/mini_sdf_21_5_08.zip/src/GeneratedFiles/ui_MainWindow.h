/********************************************************************************
** Form generated from reading ui file 'MainWindow.ui'
**
** Created: Wed May 21 01:35:48 2008
**      by: Qt User Interface Compiler version 4.3.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "SdfViewer.h"

class Ui_MainWindowClass
{
public:
    QAction *fileOpenAction;
    QAction *clearModelsAction;
    QAction *removeSelectedModelAction;
    QAction *appParametersAction;
    QAction *loadMeshFeaturesAction;
    QAction *saveMeshFeaturesAction;
    QAction *calculateSDFFacetsAction;
    QAction *calculateSDFVerticesAction;
    QAction *reverseNormalsAction;
    QAction *renderingParametersAction;
    QAction *fileExitAction;
    QAction *selectFacetAction;
    QAction *glLightsAction;
    QAction *snapAction;
    QAction *selectObjectAction;
    QWidget *centralWidget;
    QVBoxLayout *vboxLayout;
    QVBoxLayout *vboxLayout1;
    SdfViewer *world;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuTools;
    QMenu *menuView;

    void setupUi(QMainWindow *MainWindowClass)
    {
    if (MainWindowClass->objectName().isEmpty())
        MainWindowClass->setObjectName(QString::fromUtf8("MainWindowClass"));
    QSize size(899, 594);
    size = size.expandedTo(MainWindowClass->minimumSizeHint());
    MainWindowClass->resize(size);
    fileOpenAction = new QAction(MainWindowClass);
    fileOpenAction->setObjectName(QString::fromUtf8("fileOpenAction"));
    fileOpenAction->setIcon(QIcon(QString::fromUtf8(":/images/load.png")));
    clearModelsAction = new QAction(MainWindowClass);
    clearModelsAction->setObjectName(QString::fromUtf8("clearModelsAction"));
    clearModelsAction->setIcon(QIcon(QString::fromUtf8(":/images/removeall.png")));
    removeSelectedModelAction = new QAction(MainWindowClass);
    removeSelectedModelAction->setObjectName(QString::fromUtf8("removeSelectedModelAction"));
    removeSelectedModelAction->setIcon(QIcon(QString::fromUtf8(":/images/removeone.png")));
    appParametersAction = new QAction(MainWindowClass);
    appParametersAction->setObjectName(QString::fromUtf8("appParametersAction"));
    appParametersAction->setIcon(QIcon(QString::fromUtf8(":/images/app_params.PNG")));
    loadMeshFeaturesAction = new QAction(MainWindowClass);
    loadMeshFeaturesAction->setObjectName(QString::fromUtf8("loadMeshFeaturesAction"));
    loadMeshFeaturesAction->setIcon(QIcon(QString::fromUtf8(":/images/load_features.png")));
    saveMeshFeaturesAction = new QAction(MainWindowClass);
    saveMeshFeaturesAction->setObjectName(QString::fromUtf8("saveMeshFeaturesAction"));
    saveMeshFeaturesAction->setIcon(QIcon(QString::fromUtf8(":/images/save_features.png")));
    calculateSDFFacetsAction = new QAction(MainWindowClass);
    calculateSDFFacetsAction->setObjectName(QString::fromUtf8("calculateSDFFacetsAction"));
    calculateSDFFacetsAction->setIcon(QIcon(QString::fromUtf8(":/images/sdf_facets.PNG")));
    calculateSDFVerticesAction = new QAction(MainWindowClass);
    calculateSDFVerticesAction->setObjectName(QString::fromUtf8("calculateSDFVerticesAction"));
    calculateSDFVerticesAction->setIcon(QIcon(QString::fromUtf8(":/images/sdf_vertices.PNG")));
    reverseNormalsAction = new QAction(MainWindowClass);
    reverseNormalsAction->setObjectName(QString::fromUtf8("reverseNormalsAction"));
    reverseNormalsAction->setIcon(QIcon(QString::fromUtf8(":/images/reverse_normals.PNG")));
    renderingParametersAction = new QAction(MainWindowClass);
    renderingParametersAction->setObjectName(QString::fromUtf8("renderingParametersAction"));
    renderingParametersAction->setIcon(QIcon(QString::fromUtf8(":/images/world_params.png")));
    fileExitAction = new QAction(MainWindowClass);
    fileExitAction->setObjectName(QString::fromUtf8("fileExitAction"));
    selectFacetAction = new QAction(MainWindowClass);
    selectFacetAction->setObjectName(QString::fromUtf8("selectFacetAction"));
    selectFacetAction->setCheckable(true);
    selectFacetAction->setIcon(QIcon(QString::fromUtf8(":/images/select_facet.png")));
    glLightsAction = new QAction(MainWindowClass);
    glLightsAction->setObjectName(QString::fromUtf8("glLightsAction"));
    glLightsAction->setIcon(QIcon(QString::fromUtf8(":/images/gllights.png")));
    snapAction = new QAction(MainWindowClass);
    snapAction->setObjectName(QString::fromUtf8("snapAction"));
    snapAction->setIcon(QIcon(QString::fromUtf8(":/images/digital_camera_icon.png")));
    selectObjectAction = new QAction(MainWindowClass);
    selectObjectAction->setObjectName(QString::fromUtf8("selectObjectAction"));
    selectObjectAction->setCheckable(true);
    selectObjectAction->setIcon(QIcon(QString::fromUtf8(":/images/select_object.PNG")));
    centralWidget = new QWidget(MainWindowClass);
    centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
    vboxLayout = new QVBoxLayout(centralWidget);
    vboxLayout->setSpacing(1);
    vboxLayout->setMargin(11);
    vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
    vboxLayout->setContentsMargins(1, 1, 1, 1);
    vboxLayout1 = new QVBoxLayout();
    vboxLayout1->setSpacing(1);
    vboxLayout1->setObjectName(QString::fromUtf8("vboxLayout1"));
    vboxLayout1->setContentsMargins(1, 1, 1, 1);
    world = new SdfViewer(centralWidget);
    world->setObjectName(QString::fromUtf8("world"));

    vboxLayout1->addWidget(world);


    vboxLayout->addLayout(vboxLayout1);

    MainWindowClass->setCentralWidget(centralWidget);
    mainToolBar = new QToolBar(MainWindowClass);
    mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
    MainWindowClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
    statusBar = new QStatusBar(MainWindowClass);
    statusBar->setObjectName(QString::fromUtf8("statusBar"));
    MainWindowClass->setStatusBar(statusBar);
    menuBar = new QMenuBar(MainWindowClass);
    menuBar->setObjectName(QString::fromUtf8("menuBar"));
    menuBar->setGeometry(QRect(0, 0, 899, 21));
    menuFile = new QMenu(menuBar);
    menuFile->setObjectName(QString::fromUtf8("menuFile"));
    menuTools = new QMenu(menuBar);
    menuTools->setObjectName(QString::fromUtf8("menuTools"));
    menuView = new QMenu(menuBar);
    menuView->setObjectName(QString::fromUtf8("menuView"));
    MainWindowClass->setMenuBar(menuBar);

    mainToolBar->addAction(fileOpenAction);
    mainToolBar->addAction(loadMeshFeaturesAction);
    mainToolBar->addAction(saveMeshFeaturesAction);
    mainToolBar->addAction(snapAction);
    mainToolBar->addSeparator();
    mainToolBar->addAction(clearModelsAction);
    mainToolBar->addAction(removeSelectedModelAction);
    mainToolBar->addSeparator();
    mainToolBar->addAction(appParametersAction);
    mainToolBar->addAction(renderingParametersAction);
    mainToolBar->addAction(glLightsAction);
    mainToolBar->addSeparator();
    mainToolBar->addAction(selectObjectAction);
    mainToolBar->addAction(selectFacetAction);
    mainToolBar->addSeparator();
    mainToolBar->addSeparator();
    menuBar->addAction(menuFile->menuAction());
    menuBar->addAction(menuView->menuAction());
    menuBar->addAction(menuTools->menuAction());
    menuFile->addAction(fileOpenAction);
    menuFile->addAction(saveMeshFeaturesAction);
    menuFile->addAction(loadMeshFeaturesAction);
    menuFile->addSeparator();
    menuTools->addAction(calculateSDFFacetsAction);
    menuTools->addAction(calculateSDFVerticesAction);
    menuTools->addAction(reverseNormalsAction);
    menuTools->addSeparator();
    menuTools->addSeparator();

    retranslateUi(MainWindowClass);

    QMetaObject::connectSlotsByName(MainWindowClass);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindowClass)
    {
    MainWindowClass->setWindowTitle(QApplication::translate("MainWindowClass", "SDF", 0, QApplication::UnicodeUTF8));
    fileOpenAction->setText(QApplication::translate("MainWindowClass", "&Open", 0, QApplication::UnicodeUTF8));
    clearModelsAction->setText(QApplication::translate("MainWindowClass", "Clear Models", 0, QApplication::UnicodeUTF8));
    removeSelectedModelAction->setText(QApplication::translate("MainWindowClass", "Remove Selected", 0, QApplication::UnicodeUTF8));
    appParametersAction->setText(QApplication::translate("MainWindowClass", "App Params", 0, QApplication::UnicodeUTF8));
    loadMeshFeaturesAction->setText(QApplication::translate("MainWindowClass", "Load Mesh Features", 0, QApplication::UnicodeUTF8));
    saveMeshFeaturesAction->setText(QApplication::translate("MainWindowClass", "Save Mesh Features", 0, QApplication::UnicodeUTF8));
    calculateSDFFacetsAction->setText(QApplication::translate("MainWindowClass", "Calculate SDF Facets", 0, QApplication::UnicodeUTF8));
    calculateSDFVerticesAction->setText(QApplication::translate("MainWindowClass", "Calculate SDF Vertices", 0, QApplication::UnicodeUTF8));
    reverseNormalsAction->setText(QApplication::translate("MainWindowClass", "Reverse Normals", 0, QApplication::UnicodeUTF8));
    renderingParametersAction->setText(QApplication::translate("MainWindowClass", "Rendering Params", 0, QApplication::UnicodeUTF8));
    fileExitAction->setText(QApplication::translate("MainWindowClass", "E&xit", 0, QApplication::UnicodeUTF8));
    selectFacetAction->setText(QApplication::translate("MainWindowClass", "Select Facet", 0, QApplication::UnicodeUTF8));
    glLightsAction->setText(QApplication::translate("MainWindowClass", "Edit Lights", 0, QApplication::UnicodeUTF8));
    snapAction->setText(QApplication::translate("MainWindowClass", "Snapshot", 0, QApplication::UnicodeUTF8));
    selectObjectAction->setText(QApplication::translate("MainWindowClass", "Select Object", 0, QApplication::UnicodeUTF8));
    mainToolBar->setWindowTitle(QApplication::translate("MainWindowClass", "Tool Box", 0, QApplication::UnicodeUTF8));
    menuFile->setTitle(QApplication::translate("MainWindowClass", "File", 0, QApplication::UnicodeUTF8));
    menuTools->setTitle(QApplication::translate("MainWindowClass", "Tools", 0, QApplication::UnicodeUTF8));
    menuView->setTitle(QApplication::translate("MainWindowClass", "View", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindowClass: public Ui_MainWindowClass {};
} // namespace Ui

#endif // UI_MAINWINDOW_H
