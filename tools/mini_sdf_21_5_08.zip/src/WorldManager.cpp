#include "stdafx.h"

#define min min
#define max max
#define _XUTILITY_

#include <qwidget>
#include <Q3DockWindow>

#include "SdfViewer.h"

#include "WorldManager.h"
#include "FileBrowser.h"
#include "AppManager.h"
#include "MainWindow.h"

#include "FeaturePainters.h"



static GLfloat light0_ambient[] =  {0.1f, 0.1f, 0.1f, 1.0f};
static GLfloat light0_diffuse[] =  {1.0f, 1.0f, 1.0f, 1.0f};
static GLfloat light0_position[] = {.5f, .5f, 1.0f, 0.0f};
static GLfloat light0_specular[] =  {1.0f, 1.0f, 1.0f, 1.0f};
static GLfloat specref[]        = { 0.4f, 0.4f, 0.4f, 1.0f };

WorldManager::WorldManager(SdfViewer* viewer, MainWindow* parent, const char* name) :
QObject(parent, name), m_viewer(viewer), m_selectionMode(SELECTION_MODE_OBJECT), m_width(0), m_height(0)
{
	m_defaultRenderingParams = new RenderingParams;
	loadDefaultRenderingParams();
	
	addDebugPainter(new NoneDebugPainter);
	addDebugPainter(new SdfDebugPainter);	
	addDebugPainter(new DihedralDebugPainter("Dihedral 1", 0));

	//create default facet painter
	addFacetPainter(new SolidFacetPainter);
	addFacetPainter(new SdfFacetsPainter("SDF Facets", true));
	addFacetPainter(new SdfVerticesPainter);	
	addFacetPainter(new SdfDifferencesFacetsPainter);


	m_rdp = new RenderingParamsDialog((QWidget*)parent, "rdp");
	//give the dialog the default rendering params
	m_rdp->OnRenderingParams(m_defaultRenderingParams);
	//when dialog updates setting, be notified
	connect(m_rdp, SIGNAL(renderingParamsChanged(RenderingParams*)), SLOT(OnRenderingPrametersChanged(RenderingParams*)));

	m_cgl = new ConfigureGlLights(parent);
	connect(m_cgl, SIGNAL(lightChanged()), this, SLOT(invalidate()));


}


WorldManager::~WorldManager()
{
	saveDefaultRenderingParams();

	delete m_defaultRenderingParams;

	//removeAllObjects();

	// responsible for killing painters too
	for (int i=0; i<m_facetPainters.size(); i++)
	{
		delete m_facetPainters[i];
	}
	m_facetPainters.clear();

	for (int i=0; i<m_debugPainters.size(); i++)
	{
		delete m_debugPainters[i];
	}
	m_debugPainters.clear();

}

void WorldManager::OnRenderingPrametersChanged(RenderingParams* renderingParams)
{
	if (renderingParams == m_defaultRenderingParams) {
		saveDefaultRenderingParams();
		//let all listeners know default parameters have changed
		selectFacetPainter(renderingParams->m_renderModeFacets);
		emit RenderingParametersChanged();
	}
}

void WorldManager::addObject(AppObject* ao, TStubData* onlyPart, DrawMethod dm)
{
	WorldObject* wo = new WorldObject(this);
	wo->id = ao->id;
	wo->description = ao->description;
	wo->mesh = ao->mesh;
	wo->mesh->centerOfMass();
	wo->selection = ao->selection;
	wo->renderingParams = m_defaultRenderingParams;
	wo->myAo = ao;

	QString rendererName = "meshRenderer_" + ao->id;
	wo->renderer = new MeshRenderer(this, rendererName.toAscii());	

	wo->renderer->setRenderingParams(m_defaultRenderingParams);
	wo->renderer->OnFacetPainterChanged(getSelectedFacetPainter());	

	wo->renderer->setMesh(ao->mesh, NULL, ao->selection);
	//renderer is notified when rendering params change
	wo->renderer->connect(this, SIGNAL(RenderingParametersChanged()), SLOT(OnObjectChanged()));
	//renderer is notified when painter is changed
	bool success = wo->renderer->connect(this, SIGNAL(FacetPainterSelected(FacetPainter*)), SLOT(OnFacetPainterChanged(FacetPainter*)));	
	
	// scale by this object
	/*if (m_objects.size() == 0) {
		m_globalScale = mesh->diagonalLength();
		wo->renderer->scale(1.0);
	} else {
		wo->renderer->scale(m_globalScale / mesh->diagonalLength());
	}*/

	m_objects.insert(wo->id, wo);
	
	int iindex = 0;


	Point_3 centerMass = wo->mesh->centerOfMass();
	float diagonalLength = wo->mesh->diagonalLength();

	//find index of added object in objects
	int ind=0;
	for (worldObjectsMap_t::iterator it = m_objects.begin();it != m_objects.end();it++) 
	{
		if (it.value() == wo)
			break;
		ind++;
	}
	int selMode = m_selectionMode;
	m_selectionMode = SELECTION_MODE_OBJECT; // need to be in object mode to select the object
	OnObjectSelected(ind, false);
	m_selectionMode = selMode;

	//emit SceneParametersChanged(centerMass.x(), centerMass.y(), centerMass.z(), diagonalLength/2);		
	// important: should set scale before object is loaded
	calculateNewScene(iindex);

	ao->setWorldObject(wo);

	emit finishedPaint();
	return;
}

void WorldManager::invalidate() 
{ 
	m_viewer->updateGL(); 
}


void WorldManager::calculateNewScene(int tabIndex)
{
	int rows;
	int cols;
	switch (m_objects.size()) {
	case 1: rows = 1; cols = 1; break;
	case 2: rows = 1; cols = 2; break;
	case 3: rows = 2; cols = 2; break;	
	case 4: rows = 2; cols = 2; break;
	case 5: rows = 2; cols = 3; break;
	case 6: rows = 2; cols = 3; break;
	case 7: rows = 2; cols = 4; break;
	case 8: rows = 2; cols = 4; break;
	case 9: rows = 3; cols = 3; break;
	case 10: rows = 3; cols = 4; break;
	case 11: rows = 3; cols = 4; break;
	case 12: rows = 3; cols = 4; break;
	case 13: rows = 4; cols = 4; break;
	case 14: rows = 4; cols = 4; break;
	case 15: rows = 4; cols = 4; break;
	case 16: rows = 4; cols = 4; break;
	default: rows = 1; cols = 1; break;
	}

	float centerx = 0.0;
	float centery = 0.0;
	float centerz = 0.0;

	int currentRow = 0;
	int currentCol = 0;
	float cmod = (cols%2==0? 0.5 : 0.0);
	float rmod = (rows%2==0? 0.5 : 0.0);

	for (worldObjectsMap_t::iterator it = m_objects.begin(); it!= m_objects.end(); ++it) 
	{
		WorldObject* wo = *it;

		Point_3 pmin = Point_3(wo->mesh->xmin(), wo->mesh->ymin(), wo->mesh->zmin());
		Point_3	pmax = Point_3(wo->mesh->xmax(), wo->mesh->ymax(), wo->mesh->zmax());

		float longest = qMax(pmax.z() - pmin.z(), qMax(pmax.x() - pmin.x(), pmax.y() - pmin.y()));
		float scale = 1.0 / longest;
		wo->renderer->scale(scale);

		float x = (currentCol - cols / 2 + cmod);
		float y = (currentRow - rows / 2 + rmod);
		float z = 0.0;		
		wo->renderer->frame()->setPosition(x,y,z);		

		//qglviewer::Quaternion q(qglviewer::Vec(1,0,0), -0.77);
		//qglviewer::Quaternion q2(qglviewer::Vec(0,1,0), 0.34);
		//wo->renderer->frame()->setOrientation(q2*q);

		QString temp;
		temp.sprintf("calculateNewScene: <%s> scale=%f, translation=[%f,%f,%f]", wo->id.toAscii(), wo->renderer->scale(), x, y, z);
		SDFLOG6(temp);
		const GLdouble* m = wo->renderer->frame()->matrix();
		temp.sprintf("calculateNewScene: Matrix=[%.2f %.2f %.2f %.2f ; %.2f %.2f %.2f %.2f ; %.2f %.2f %.2f %.2f ; %.2f %.2f %.2f %.2f]", 
			m[0],m[1],m[2],m[3], m[4],m[5],m[6],m[7],m[8],m[9],m[10],m[11],m[12],m[13],m[14],m[15]);
		SDFLOG6(temp);

		currentCol++;
		if (currentCol == cols) {
			currentRow++;
			currentCol = 0;
		}			
	}

	emit SceneParametersChanged(tabIndex, centerx, centery, centerz, (float) qMax(rows,cols) / 2);
}


void WorldManager::removeObject(const QString& id)
{
	worldObjectsMap_t::iterator it = m_objects.find(id.ascii());

	if (it == m_objects.end()) 
		return;

	WorldObject* wo = it.value();

	invalidateDebugPainters(wo->mesh);

	if (m_viewer->manipulatedFrame() == wo->renderer->frame())
		m_viewer->setManipulatedFrame(NULL);

	delete wo;

	m_objects.erase(it);

	calculateNewScene(0);
}

void WorldManager::removeAllObjects()
{
	//delete all objects from world
	for (worldObjectsMap_t::iterator it = m_objects.begin(); it != m_objects.end(); it++)
	{
		WorldObject* wo = it.value();
		delete wo;
	}

	invalidateDebugPainters();

	calculateNewScene(0);
}

const GLdouble* WorldManager::getObjectMatrix(const QString& id)
{
	WorldObject* wo = findObject(id);

	if (wo) {
		return wo->renderer->frame()->matrix();
	} else {
		return NULL;
	}	
}

WorldObject* WorldManager::findObject(const QString& id)
{
	worldObjectsMap_t::iterator it = m_objects.find(id.ascii());
	if (it != m_objects.end()) {
		return it.value();
	} else {
		return NULL;
	}
}


void WorldObject::drawObject(int name, int selectionMode)
{
	glPushMatrix();
	glMultMatrixd(renderer->frame()->matrix());
	float localScale = renderer->scale();
	glScalef(localScale, localScale, localScale);

	//translate to [0,0,0]

	Point_3 center = mesh->computedCenterOfMass();

	glTranslatef(-center.x(), -center.y(), -center.z());

	//QGLViewer::drawAxis();

	if (selectionMode == SELECTION_MODE_OBJECT) {
		//render all objects
		glPushName(name);
		renderer->render(selectionMode);
		glPopName();

	} else if (selectionMode == SELECTION_MODE_FACET)  {
		if (selection->isSelected()) {
			//if selectin facet work only with selected object
			renderer->render(selectionMode);
		} else {
			glPushName(INT_MAX-name);
			renderer->render(SELECTION_MODE_OBJECT);
			glPopName();
		}
	} 
	else if (selectionMode == SELECTION_MODE_NONE) 
	{
		DebugPainter *dbgp = mgr->getSelectedDebugPainter();
		//if no selection enabled render everyone
		if ((dbgp != NULL) && selectionMode == SELECTION_MODE_NONE) 
		{
			mgr->getSelectedDebugPainter()->paint(mesh, selection, NULL, this);
		}

		bool hasAlpha = (mgr->defaultRenderParams()->m_alpha<255);
		if (hasAlpha) 
		{
			//glDepthMask(GL_FALSE);
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		}

		renderer->render(selectionMode);

		//if no selection enabled render everyone
		if ((dbgp != NULL) && selectionMode == SELECTION_MODE_NONE) 
		{
			mgr->getSelectedDebugPainter()->postPaint(mesh, selection, NULL);
		}

		if (hasAlpha) 
		{
			//glDepthMask(GL_TRUE);
			glDisable(GL_BLEND);
		}
	}

	glPopMatrix();

}



void WorldManager::drawWorld(int selectionMode)
{
	int i=0;
	for (worldObjectsMap_t::iterator it = m_objects.begin(); it != m_objects.end(); it++)
	{
		WorldObject* wo = it.value();
		wo->drawObject(i, selectionMode);
		i++;
	}

	//if not drawing for selection and overlay enabled, draw overlay
	if (selectionMode == SELECTION_MODE_NONE && m_defaultRenderingParams->m_overlay) {
		drawOverlay();
	}
	glFlush();
	

}

void WorldManager::drawOverlay()
{
	//setup GL for 2d overlay
	glPushMatrix();
	glLoadIdentity();
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0,1,0,1);
	GLint viewport[4];
	glGetIntegerv(GL_VIEWPORT, &viewport[0]);
	glViewport(0,0,m_width >> 3, m_height >> 3);	
	for (int i=0; i<m_overlayPainters.size(); i++) {
		m_overlayPainters[i]->render();
	}	
	glViewport(0.0,0.0, viewport[2], viewport[3]);
	glPopMatrix();	
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}

//////////////////////////////////////////////////////////////////////////
// Slots
//////////////////////////////////////////////////////////////////////////

void WorldManager::OnDraw()
{
	drawWorld(SELECTION_MODE_NONE);

	//emit RedrawNeeded(); does nothing
}


void WorldManager::OnSelectDraw()
{
	drawWorld(m_selectionMode);
}

/** add a new object */
void WorldManager::OnAddObject(AppObject* ao, TStubData* onlyPart, DrawMethod dm)
{
	addObject(ao, onlyPart, dm); 

	emit RedrawNeeded();
}

/** remove an object */
void WorldManager::OnRemoveObject(const QString& id)
{
	removeObject(id);

	emit RedrawNeeded();
}

void WorldManager::OnChangeObject(const QString& id, bool geometryChanged)
{
	worldObjectsMap_t::iterator it = m_objects.find(id.ascii());

	if (it != m_objects.end()) {
		WorldObject* wo = it.value();
		invalidateDebugPainters(wo->mesh);
		wo->renderer->OnObjectChanged(geometryChanged);
	}

	emit RedrawNeeded();
}

void WorldManager::OnViewerInitialized()
{
	//init glew
	GLenum err = glewInit();	
	if (GLEW_OK == err) {
		m_defaultRenderingParams->m_vboSupported = GLEW_ARB_vertex_buffer_object;
	} else {
		m_defaultRenderingParams->m_vboSupported = false;
	}

	glEnable(GL_COLOR_MATERIAL);
	//glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

	glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
	glMateriali(GL_FRONT,GL_SHININESS, 60);

	glLightfv(GL_LIGHT0, GL_POSITION, light0_position);

	//glFrontFace(GL_CW);

	//Load default configuration from lights dialog
	m_cgl->LoadConfiguration(0);
	m_cgl->applyLight();

	//TODO: temporary
	glEnable(GL_NORMALIZE);
}

void WorldManager::OnEditRenderingParameters()
{
	m_rdp->onFillFacetPainters(getFacetPainterNames());
	m_rdp->OnFillDebugPainters(getDebugPainterNames());
	m_rdp->OnRenderingParams(m_defaultRenderingParams);
	m_rdp->show();
}

void WorldManager::saveRenderingParams(const QString& prefix, RenderingParams* renderingParams)
{
	ProgSettings ps;

	ps.beginGroup(prefix);

	ps.writeEntry("smoothShading", renderingParams->m_smoothShading);
	ps.writeEntry("culling",renderingParams->m_culling);
	ps.writeEntry("polygonMode",renderingParams->m_polygonMode);		
	ps.writeEntry("antialiasing",renderingParams->m_antialiasing);
	ps.writeEntry("superimposeEdges",renderingParams->m_superimposeEdges);
	ps.writeEntry("superimposeVertices",renderingParams->m_superimposeVertices);
	ps.writeEntry("useNormals",renderingParams->m_useNormals);
	ps.writeEntry("smoothNormals", renderingParams->m_smoothNormals);
	ps.writeEntry("lighting",renderingParams->m_lighting);	

	ps.writeEntry("facetColor", (int)renderingParams->m_facetColor.rgb());
	ps.writeEntry("edgeColor", (int)renderingParams->m_edgeColor.rgb());
	ps.writeEntry("vertexColor", (int)renderingParams->m_vertexColor.rgb());
	
	ps.writeEntry("renderModeFacets", renderingParams->m_renderModeFacets);	
	ps.writeEntry("renderModeEdges", renderingParams->m_renderModeEdges);

	ps.writeEntry("debugPainter", renderingParams->m_debugPainter);

	ps.writeEntry("overlay", renderingParams->m_overlay);
	
	ps.writeEntry("edgeThickness", renderingParams->m_edgeThickness);

	ps.writeEntry("colorSchemeName", renderingParams->m_colorSchemeName);

	ps.writeEntry("alpha", renderingParams->m_alpha);

	ps.endGroup();
}

void WorldManager::loadRenderingParams(const QString& prefix, RenderingParams* renderingParams)
{
	ProgSettings ps;

	ps.beginGroup(prefix);

	renderingParams->m_smoothShading = ps.readBoolEntry("smoothShading", true);
	renderingParams->m_culling = ps.readBoolEntry("culling", true);
	
	renderingParams->m_antialiasing = ps.readBoolEntry("antialiasing", true);
	renderingParams->m_superimposeEdges = ps.readBoolEntry("superimposeEdges", false);
	renderingParams->m_superimposeVertices = ps.readBoolEntry("superimposeVertices", false);
	renderingParams->m_useNormals = ps.readBoolEntry("useNormals", true);
	renderingParams->m_smoothNormals = ps.readBoolEntry("smoothNormals", true);
	renderingParams->m_lighting = ps.readBoolEntry("lighting", true);	

	renderingParams->m_polygonMode = ps.readNumEntry("polygonMode", 0x1b02);		

	renderingParams->m_facetColor = QColor((QRgb)ps.readNumEntry("facetColor", 0xffffffff));
	renderingParams->m_edgeColor = QColor((QRgb)ps.readNumEntry("edgeColor", 0xfff0d400));
	renderingParams->m_vertexColor = QColor((QRgb)ps.readNumEntry("vertexColor", 0xfff06d6d));
	
	renderingParams->m_overlay = ps.readBoolEntry("overlay", false);

	renderingParams->m_renderModeFacets = ps.readNumEntry("renderModeFacets", 1);	// SDF
	renderingParams->m_renderModeEdges = ps.readNumEntry("renderModeEdges", 0);

	renderingParams->m_debugPainter = ps.readNumEntry("debugPainter", 0);

	renderingParams->m_edgeThickness = ps.readNumEntry("edgeThickness", 1);
	renderingParams->m_colorSchemeName = ps.readEntry("colorSchemeName", "default");

	renderingParams->m_alpha = ps.readNumEntry("alpha", 255);

	ps.endGroup();
}

void WorldManager::saveDefaultRenderingParams()
{
	saveRenderingParams("default", m_defaultRenderingParams);
}

void WorldManager::loadDefaultRenderingParams()
{
	loadRenderingParams("default", m_defaultRenderingParams);
}

void WorldManager::OnEditGLLights()
{
	m_cgl->show();
}

int WorldManager::addFacetPainter(FacetPainter* facetPainter)
{
	m_facetPainters.push_back(facetPainter);
	return m_facetPainters.size();
}

QStringList WorldManager::getFacetPainterNames()
{
	QStringList fpnames;
	for (int i=0;i<m_facetPainters.size();i++)
	{
		if (m_facetPainters[i] != NULL) {
			fpnames.append(m_facetPainters[i]->name());
		}
	}

	return fpnames;
}

int WorldManager::selectFacetPainter(const int facetPainterIndex)
{	
	//int oldFacetPainterIndex = m_defaultRenderingParams->m_renderModeFacets;	

	m_defaultRenderingParams->m_renderModeFacets = facetPainterIndex;

	//recalculate colors
	//if (facetPainterIndex != oldFacetPainterIndex)
	emit FacetPainterSelected(m_facetPainters[m_defaultRenderingParams->m_renderModeFacets]);

	//redreaw needed
	m_viewer->updateGL();

	return m_defaultRenderingParams->m_renderModeFacets;
}

int WorldManager::selectFacetPainter(const QString& facetPainterName)
{
	int oldFacetPainterIndex = m_defaultRenderingParams->m_renderModeFacets;	

	for (int i=0;i<m_facetPainters.size();i++)
	{
		if (m_facetPainters[i] != NULL && m_facetPainters[i]->name() == facetPainterName) {			
			m_defaultRenderingParams->m_renderModeFacets = i;

			//recalculate colors
			if (i != oldFacetPainterIndex)
				emit FacetPainterSelected(m_facetPainters[m_defaultRenderingParams->m_renderModeFacets]);

			return m_defaultRenderingParams->m_renderModeFacets;
		}
	}

	return -1;
}


FacetPainter* WorldManager::getSelectedFacetPainter()
{
	if (!(m_defaultRenderingParams && 
		m_defaultRenderingParams->m_renderModeFacets >=0 && 
		m_defaultRenderingParams->m_renderModeFacets < m_facetPainters.size()))
		return NULL;

	return m_facetPainters[m_defaultRenderingParams->m_renderModeFacets];
}

//////////////////////////////////////////////////////////////////////////
int WorldManager::addDebugPainter(DebugPainter* debugPainter)
{
	m_debugPainters.push_back(debugPainter);
	return m_debugPainters.size();
}

QStringList WorldManager::getDebugPainterNames()
{
	QStringList fpnames;
	for (int i=0;i<m_debugPainters.size();i++)
	{
		if (m_debugPainters[i] != NULL) {
			fpnames.append(m_debugPainters[i]->name());
		}
	}

	return fpnames;
}

int WorldManager::selectDebugPainter(const int debugPainterIndex)
{		
	m_defaultRenderingParams->m_debugPainter = debugPainterIndex;

	//recalculate colors	
	emit DebugPainterSelected(m_debugPainters[m_defaultRenderingParams->m_debugPainter]);

	return m_defaultRenderingParams->m_debugPainter;
}

int WorldManager::selectDebugPainter(const QString& debugPainterName)
{
	int oldDebugPainterIndex = m_defaultRenderingParams->m_debugPainter;	

	for (int i=0;i<m_debugPainters.size();i++)
	{
		if (m_debugPainters[i] != NULL && m_debugPainters[i]->name() == debugPainterName) {			
			m_defaultRenderingParams->m_debugPainter = i;

			//recalculate colors
			if (i != oldDebugPainterIndex)
				emit DebugPainterSelected(m_debugPainters[m_defaultRenderingParams->m_debugPainter]);

			return m_defaultRenderingParams->m_debugPainter;
		}
	}

	return -1;
}


int WorldManager::addOverlayPainter(OverlayPainter* overlayPainter)
{
	m_overlayPainters.push_back(overlayPainter);

	return m_overlayPainters.size();
}


DebugPainter* WorldManager::getSelectedDebugPainter()
{
	if (!(m_defaultRenderingParams && 
		m_defaultRenderingParams->m_debugPainter >=0 && 
		m_defaultRenderingParams->m_debugPainter < m_debugPainters.size()))
		return NULL;

	return m_debugPainters[m_defaultRenderingParams->m_debugPainter];
}

WorldObject* WorldManager::getSelectedObject()
{
	worldObjectsMap_t::iterator it = m_objects.begin();
	worldObjectsMap_t::iterator it_end = m_objects.end();
	for (; it != it_end; it++) {
		if (it.value()->selection->isSelected()) {
			return it.value();
		}
	}

	return NULL;
}

// select by either index or id
void WorldManager::objectSelected(int i, QString id)
{
	WorldObject* selwo = NULL;
	int ind = 0;
	for (worldObjectsMap_t::iterator it = m_objects.begin(); it != m_objects.end(); ++it)
	{
		WorldObject* wo = it.value();
		if ( ((i != -1) && (ind == i)) ||
			((!id.isEmpty()) && (wo->id == id)) )
		{				
			selwo = wo;
		} else {
			wo->selection->setSelected(false);
		}
		ind++;
	}

	if (selwo == NULL)
	{
		return;
	}
	m_viewer->setManipulatedFrame(selwo->renderer->frame());
	selwo->selection->setSelected(true);

	invalidateDebugPainters(selwo->mesh);

	emit message("Selected object <" + selwo->id + ">");
	emit ObjectSelected(selwo->id);
}


// entry point
void WorldManager::OnObjectSelected(unsigned int i, Qt::KeyboardModifiers modif, int extPart /* =-1 */)
{
	bool multi = false; //(modif == Qt::ShiftModifier);
	bool rotsel = (modif == Qt::ShiftModifier);
	if (m_selectionMode == SELECTION_MODE_OBJECT) 
	{
		objectSelected(i);
	} 
	else if (m_selectionMode == SELECTION_MODE_FACET)
	{
		WorldObject* wo = getSelectedObject();
		if (!wo) return;

		if (UINT_MAX == i)
		{
			wo->selection->clear();
		}
		else if ((i == UINT_MAX - 1) || (i < wo->mesh->size_of_facets())) 
		{
			if (i == UINT_MAX - 1) 
				i = wo->selection->selectedFacet();

			invalidateDebugPainters(wo->mesh);

			if (multi)
				wo->selection->selectFacetAdd(i);
			else
				wo->selection->selectFacet(i);

			//OnChangeObject(wo->id, false);
			emit FacetSelected(wo->id, i);

			Mesh::Facet_const_handle f = wo->mesh->find_facet(i);
			if (f != NULL) 
			{
				if (multi)
					wo->selection->selectPartAdd(f->part());
				else
					wo->selection->selectPart(f->part()); 

				QString temp;
				temp.sprintf("Selected facet <%d> in %s. [SDF=%.3f(%.3f) Cluster=%d]", i, wo->description.ascii(), f->volume(), f->nvolume(), f->cluster());

				emit message(temp);
			} 
			else 
			{
				emit message("Selected facet <" + QString::number(i) + "> in object " + wo->description);
			}
		} 
		else 
		{
			objectSelected(INT_MAX - i);
		}		
	}
}




void WorldManager::OnSelectionMode(int selectionMode)
{
	m_selectionMode = selectionMode;
}

void WorldManager::OnWorldSizeChanged(int width, int height)
{
	m_height = height;
	m_width = width;
}

void WorldManager::OnSelectFacetPainter(int facetPainter)
{
	if (facetPainter<0 || facetPainter>=m_facetPainters.size() || facetPainter == m_defaultRenderingParams->m_renderModeFacets)
		return;

	selectFacetPainter(facetPainter);
	emit RenderingParametersChanged();

	QString temp;
	temp.sprintf("Selected painter %s", m_facetPainters[facetPainter]->name().ascii());
	emit message(temp);

	glDisable(GL_LIGHTING);
	m_viewer->displayMessage(temp);
}

void WorldManager::invalidateDebugPainters(Mesh* mesh)
{
	for (int i=0;i<m_debugPainters.size();i++) {
		m_debugPainters[i]->invalidate(mesh);
	}
}

void WorldManager::OnFunctionKeyPressed(int key, Qt::ButtonState state)
{
	if (state == Qt::NoButton) {
		OnSelectFacetPainter(key);
	} else if (state == Qt::ControlButton) {
		//notify debug painter
		DebugPainter* dp = getSelectedDebugPainter();
		if (dp != NULL) {
			QString answer = dp->command(key);
			if (answer != QString::null) {
				glDisable(GL_LIGHTING);
				m_viewer->displayMessage(answer);
			}
		}
	} else if (state == Qt::AltButton) {
		FacetPainter* fp = getSelectedFacetPainter();
		if (fp != NULL) {
			QString answer = fp->command(key);
			if (answer != QString::null) {
				QString s = QString("Facet Painter %1 command %2\n").arg(fp->name()).arg(answer);
				printf(s.toAscii());
				for (worldObjectsMap_t::iterator it = m_objects.begin(); it != m_objects.end();it++)
					it.value()->renderer->OnObjectChanged(false);
				glDisable(GL_LIGHTING);
				m_viewer->displayMessage(answer);
			}
		}
	}
}


void WorldManager::redoAllColors()
{
	for (worldObjectsMap_t::iterator it = m_objects.begin(); it != m_objects.end();it++)
		it.value()->renderer->OnObjectChanged(false);
	invalidate();
}


