#include "stdafx.h"

#include "Mesh.h"
//#include "curvature_estimator.h"

#include <list>

#include <QFile>
#include <QString>
#include <q3cstring.h>
#include <QTextStream>
#include <QBuffer>

const float Mesh::cm_colorWhite[3] = {0.95,0.95,0.95};
const float Mesh::cm_colorGray[3] = {0.5,0.5,0.5};
const float Mesh::cm_colorBlack[3] = {0.0,0.0,0.0};

Mesh::Mesh() :
	//m_2dSearchStructure(NULL),
	m_totalSurface(FLT_MAX)/*,
	m_triangleSearch(NULL)*/
{	
	
}

Mesh::~Mesh()
{

}

int Mesh::translatePart(int from, int to)
{
	int count = 0;
	for (Mesh::Facet_iterator it = facets_begin(); it!= facets_end(); ++it) 
	{
		if (it->part() == from)
		{
			++count;
			it->part(to);
		}
	}
	return count;
}


number_type Mesh::compute_triangle_surfaces()
{
	m_totalSurface = 0.0;
	for (Mesh::Facet_iterator it = facets_begin(); it!= facets_end(); it++) {
		it->surface(sqrt(create_triangle(it->facet_begin()).squared_area()));
		m_totalSurface += it->surface();
	}

	return m_totalSurface;
}

number_type Mesh::compute_surface_total()
{
	m_totalSurface = 0.0;
	for (Mesh::Facet_iterator it = facets_begin(); it!= facets_end(); it++) {
		m_totalSurface += it->surface();
	}

	return m_totalSurface;
}

number_type Mesh::get_surface_total()
{
	return m_totalSurface;
}


void Mesh::compute_2d_search_structure()
{
	//if (m_2dSearchStructure) return;

	std::vector<Point_2_With_Vertex> points;
	points.reserve(size_of_vertices());

	NT_d p[2];
	for(Mesh::Vertex_iterator it = vertices_begin();
		it != vertices_end();
		it++)
	{		
		if (it->vertex_begin() != NULL) {
			p[0] = it->point().x();
			p[1] = it->point().y();
			Point_2_With_Vertex pwv(2, p, p+2);
			pwv.handle = it;
			points.push_back(pwv);
		}		
	}

	//m_2dSearchStructure = new KDTree(points.begin(),points.end());
}

/*void Mesh::compute_2d_search_structure()
{
	m_2dSearchStructure = new Enriched_point_set_2;

	std::ofstream f("c:/temp/compute2d.txt");

	f << "Computing 2d search structure on mesh with " << size_of_vertices() << std::endl << std::endl;

	//fill search structure
	int i=0;
	for (Vertex_iterator it = vertices_begin(); it != vertices_end(); it++) {
		Enriched_kernel::Point_2 p(it->point().x(), it->point().y());

		f << "[" << i << "] Adding " <<
			it->index() << " at point " <<
			p[0] << "," << p[1];

		Enriched_point_set_2::Vertex_handle p_vertex = m_2dSearchStructure->insert(p);
		assert(p_vertex != NULL);

		f << ", Is vertex handle null? " << (p_vertex == NULL) << std::endl;

		if (p_vertex != NULL && it->index() >= 0) p_vertex->info() = it;

		i++;
	}

	f << "=============================================" << std::endl;

	f.close();
}*/

bool Mesh::find_closest_on_mesh(
	Enriched_kernel::Point_2 p,
	Enriched_Mesh::Vertex_handle& closestVertex,
	Enriched_Mesh::Facet_handle& containingFacet)
{
	/*assert(m_2dSearchStructure != NULL);

	NT_d p2[2];	p2[0] = p[0];	p2[1] = p[1];
	Point_2_With_Vertex queryPoint(2,p2,p2+2);

	std::vector<KDNeighborSearch::Point_with_distance> nearestNeighbors;

	KDNeighborSearch searcher(
		*m_2dSearchStructure, //kd-tree
		queryPoint, //point to look for
		KDEuclideanDistance(), //search type
		6 );//number of query points
		 
	searcher.the_k_neighbors(std::back_inserter(nearestNeighbors));

	bool foundContainingFacet = false;
	for (int i=0; i<nearestNeighbors.size(); i++)
	{	
		Vertex_handle v = nearestNeighbors[i].first->handle;

		//for debug reasons
		if (i==0) closestVertex = v;

		Halfedge_around_vertex_circulator c = v->vertex_begin();
		if (c != NULL ) do {
			Enriched_kernel::Triangle_2 t = create_triangle2(c);

			//if (t.orientation() == CGAL::RIGHT_TURN) t = t.opposite();
			if (t.has_on_bounded_side(p) || t.has_on_boundary(p)) {				
				foundContainingFacet = true;
				containingFacet = c->facet();
				break;
			} 
		} while (++c != v->vertex_begin());

		if (foundContainingFacet) break;
	}

	if (foundContainingFacet) {
		Point_3 p3(p[0],p[1],0.0);
		float vdistance = FLT_MAX;
		Halfedge_around_facet_circulator c = containingFacet->facet_begin();
		do {
			Enriched_kernel::Segment_3 s(p3, c->vertex()->point());
			if (s.squared_length() < vdistance) {
				vdistance = s.squared_length();
				closestVertex = c->vertex();
			}
		} while (++c != containingFacet->facet_begin());
		
		return true;

	} else {
		return false;
	}	*/

	return false;
}

/*bool Mesh::find_closest_on_mesh(
																Enriched_kernel::Point_3 p,
																Enriched_Mesh::Vertex_handle& closestVertex,
																Enriched_Mesh::Facet_handle& containingFacet)
{
	assert(m_2dSearchStructure != NULL);

	Enriched_kernel::Point_2 p2(p.x(),p.y());

	std::list<Enriched_point_set_2::Vertex_handle> closest;
	m_2dSearchStructure->nearest_neighbors(p2, 3, std::back_inserter(closest));
	bool foundContainingFacet = false;
	do {
		Vertex_handle v = closest.front()->info();
		closest.pop_front();

		Halfedge_around_vertex_circulator c = v->vertex_begin();
		do {
			Enriched_kernel::Triangle_3 t = create_triangle(c);
			if (t.has_on(p)) {
				foundContainingFacet = true;
				containingFacet = c->facet();
				break;
			} 
		} while (++c != v->vertex_begin());
	} while (closest.size() > 0 && !foundContainingFacet);

	if (foundContainingFacet) {
		float vdistance = FLT_MAX;
		Halfedge_around_facet_circulator c = containingFacet->facet_begin();
		do {
			Enriched_kernel::Segment_3 s(p, c->vertex()->point());
			if (s.squared_length() < vdistance) {
				vdistance = s.squared_length();
				closestVertex = c->vertex();
			}
		} while (++c != containingFacet->facet_begin());
		return true;

	} else {
		return false;
	}
}*/

Enriched_kernel::Triangle_3 Mesh::create_triangle(const Mesh::Halfedge_handle& h)
{
	if (h == NULL) {
		return Enriched_kernel::Triangle_3();
	}

	Enriched_kernel::Triangle_3 t(
		h->vertex()->point(),
		h->next()->vertex()->point(),
		h->next()->next()->vertex()->point());

	return t;
}

Enriched_kernel::Triangle_2 Mesh::create_triangle2(const Mesh::Halfedge_handle& h)
{
	Enriched_kernel::Point_2 p1(h->vertex()->point().x(),h->vertex()->point().y());
	Enriched_kernel::Point_2 p2(h->next()->vertex()->point().x(),
		h->next()->vertex()->point().y());
	Enriched_kernel::Point_2 p3(h->next()->next()->vertex()->point().x(),
		h->next()->next()->vertex()->point().y());

	Enriched_kernel::Triangle_2 t(p1,p2,p3);

	return t;
}

void Mesh::compute_vertex_fastindex()
{
	if (m_fastIndexMap.size()) m_fastIndexMap.clear();
	m_fastIndexMap.reserve(size_of_vertices());

	for (Vertex_iterator it = vertices_begin(); it != vertices_end(); it++) {
		m_fastIndexMap.push_back(it);
	}
}

void Mesh::compute_facet_fastindex()
{
	//if (m_fastFacetMap) return;

	if (m_fastFacetMap.size()) m_fastFacetMap.clear();	

	int facetTag = 0;
	m_fastFacetMap.reserve(size_of_facets());
	for (Facet_iterator it = facets_begin(); it != facets_end(); it++) {
		it->index(facetTag);
		m_fastFacetMap.push_back(it);		
		facetTag++;
	}
}

Enriched_Mesh::Vertex_handle Mesh::find_vertex(const int index)
{
	assert(m_fastIndexMap);

	if (!m_fastIndexMap.size()) compute_vertex_fastindex();

	if (index<0 || index>=m_fastIndexMap.size()) return Enriched_Mesh::Vertex_handle();	

	return m_fastIndexMap[index];
}

Enriched_Mesh::Facet_handle Mesh::find_facet(const int index)
{
	assert(m_fastFacetMap);
	if (!m_fastFacetMap.size()) compute_facet_fastindex();

	if (index<0 || index>=m_fastFacetMap.size()) return Enriched_Mesh::Facet_handle();	

	return m_fastFacetMap[index];
}

void Mesh::compute_bounding_box()
{
	Enriched_kernel::FT xmin,xmax,ymin,ymax,zmin,zmax;
	Enriched_Mesh::compute_bounding_box(xmin,xmax,ymin,ymax,zmin,zmax);
}

number_type Mesh::diagonalLength()
{
	Enriched_kernel::FT xmin,xmax,ymin,ymax,zmin,zmax;
	Enriched_Mesh::compute_bounding_box(xmin,xmax,ymin,ymax,zmin,zmax);

	Point_3 m(xmin, ymin, zmin);
	Point_3 M(xmax, ymax, zmax);

	Vector_3 diag(m,M);
	return sqrt(diag*diag);
}

Point_3 Mesh::centerOfMass()
{
	Point_3 centerOfMass(0,0,0);
	for (Mesh::Vertex_iterator v = this->vertices_begin();
		 v != this->vertices_end();
		 v++)
	{
		centerOfMass = centerOfMass + (v->point() - CGAL::ORIGIN);
	}

	unsigned int size = this->size_of_vertices();

	m_computedCenterOfMass = Point_3(centerOfMass.x()/size, centerOfMass.y()/size, centerOfMass.z()/size);

	return m_computedCenterOfMass;
}

Point_3 Mesh::polyCenterOfMass()
{
	number_type c[3] = { 0.0, 0.0, 0.0 };
	number_type centerWeight = 0.0;

	for ( Mesh::Facet_iterator f = this->facets_begin(); f != this->facets_end(); ++f)
	{
		//Mesh::Facet_handle f = mesh->find_facet(m_facets[i]);
		Mesh::Point_3 fcenter;
		
		compute_facet_center(f, fcenter);
		number_type facetSurface = f->surface();
		c[0] += fcenter.x() * facetSurface;
		c[1] += fcenter.y() * facetSurface;
		c[2] += fcenter.z() * facetSurface;
		centerWeight += facetSurface;

	}

	c[0] /= centerWeight;
	c[1] /= centerWeight;
	c[2] /= centerWeight;
	return Mesh::Point_3(c[0], c[1], c[2]);

}

void Mesh::translate(const Vector_3& translateTo)
{
	Enriched_kernel::Aff_transformation_3 transformation(CGAL::TRANSLATION, translateTo);
	this->transform(transformation);
}

void Mesh::scale(const number_type& scaleBy)
{
	Enriched_kernel::Aff_transformation_3 transformation(CGAL::SCALING, scaleBy);
	this->transform(transformation);
}

void Mesh::transform(const Enriched_kernel::Aff_transformation_3 &transformation)
{
	for (Mesh::Vertex_iterator ivertex = this->vertices_begin(); ivertex != this->vertices_end(); ivertex++)
	{
		ivertex->point() = ivertex->point().transform(transformation);
	}
}

/*
void Mesh::estimateCurvature()
{
	std::cerr << "Estimate curvature tensor...";
	double start = clock();
	typedef CCurvature_estimator<typename Mesh,Enriched_kernel> Estimator;
	Estimator estimator(this);
	estimator.run(Estimator::ONE_RING);	
	double duration = (double)((clock()-start)/CLOCKS_PER_SEC);
	std::cerr << "Estimate curvature tensor...done " << duration << " seconds" << std::endl;
}
*/

Mesh::Vertex_handle Mesh::splitEdge(Mesh::Halfedge_handle h)
{
	Point_3 p1 = h->vertex()->point();
	Point_3 p2 = h->opposite()->vertex()->point();

	Point_3 center((p1.x() + p2.x())/2,
		(p1.y() + p2.y())/2,
		(p1.z() + p2.z())/2);

	//delete edge h
	Mesh::Halfedge_handle g = this->join_facet(h);

	//create a center vertex
	g = this->create_center_vertex(g);
	g->vertex()->point() = center;

	return g->vertex();
}

void Mesh::splitEdges(std::vector<Mesh::Halfedge_handle> &halfEdges)
{
	for (std::vector<Mesh::Halfedge_handle>::iterator it = halfEdges.begin(); 
		 it != halfEdges.end(); 
		 it++)
	{
		splitEdge(*it);
	}

#ifdef _DEBUG
	//check that all facets are of size 3
	for ( Mesh::Facet_iterator f = this->facets_begin(); f != this->facets_end(); ++f){
		//all facets must be of size 3
		CGAL_assertion( f->size() ==  3);
	}
#endif

}

Mesh::Halfedge_handle Mesh::flipEdge(Mesh::Halfedge_handle h)
{
	h = this->join_facet(h);
	return this->split_facet(h->prev(), h->next());
}

void Mesh::flipEdges(std::vector<Mesh::Halfedge_handle> &halfEdges)
{
	std::cout << "flipping " << halfEdges.size() << " edges"<<std::endl;
	for (std::vector<Mesh::Halfedge_handle>::iterator it = halfEdges.begin(); 
		 it != halfEdges.end(); 
		 it++)
	{
		flipEdge(*it);
	}

#ifdef _DEBUG
	//check that all facets are of size 3
	for ( Mesh::Facet_iterator f = this->facets_begin(); f != this->facets_end(); ++f){
		//all facets must be of size 3
		CGAL_assertion( f->size() ==  3);
	}
#endif

}

void Mesh::flipLongEdges()
{
	//naive (slow) implementation
	int flipCount = 0;

	Mesh::Halfedge_handle edgeToFlip;

	do
	{
		edgeToFlip = NULL;
		number_type longest = 0;

		for (Mesh::Edge_iterator h = this->edges_begin();
			h != this->edges_end();
			h++)
		{
			if (h->vertex()->degree() < 3
				||
				h->opposite()->vertex()->degree() < 3)
				continue;

			number_type edgeLenSquared = edgeLengthSquared(h);

			if (edgeLenSquared > longest)
			{
				Vector_3 altVec = h->next()->vertex()->point() - h->opposite()->next()->vertex()->point();
				number_type alternativeEdgeLenSquared = altVec*altVec;

				if (edgeLenSquared > alternativeEdgeLenSquared)
				{
					longest = edgeLenSquared;
					edgeToFlip = h;
				}
			}
		}

		if (edgeToFlip != NULL)
		{
			flipEdge(edgeToFlip);
			flipCount++;
		}

	}
	while(edgeToFlip != NULL);;

	std::cerr << "flipped "<<flipCount<<" edges"<<std::endl;
}

void Mesh::flipEdgesAroundSmallTriangles()
{
	//naive (slow) implementation
	int flipCount = 0;

	Mesh::Halfedge_handle edgeToFlip;

	do
	{
		edgeToFlip = NULL;
		number_type best = 0;

		for (Mesh::Edge_iterator h = this->edges_begin();
			h != this->edges_end();
			h++)
		{
			if (h->vertex()->degree() < 3
				||
				h->opposite()->vertex()->degree() < 3)
				continue;

			Point_3 a = h->vertex()->point();
			Point_3 b = h->next()->vertex()->point();
			Point_3 c = h->opposite()->vertex()->point();
			Point_3 d = h->opposite()->next()->vertex()->point();

			Triangle_3 existing1(a,b,c);
			Triangle_3 existing2(a,c,d);
			number_type area1 = existing1.squared_area();
			number_type area2 = existing2.squared_area();

			number_type ratio1 = qMin(area1, area2) / qMax(area1,area2);

			if (ratio1 > 0.1)
				continue;

			Triangle_3 alternative1(b,d,a);
			Triangle_3 alternative2(b,d,c);

			area1 = alternative1.squared_area();
			area2 = alternative2.squared_area();

			number_type ratio2 = qMin(area1, area2) / qMax(area1,area2);

			if (ratio2 > ratio1 && (ratio2 * ratio1) > best)
			{
				best = ratio2 * ratio1;
				edgeToFlip = h;
			}
		}

		if (edgeToFlip != NULL)
		{
			flipEdge(edgeToFlip);
			flipCount++;
		}

	}
	while(edgeToFlip != NULL);;

	std::cerr << "flipped "<<flipCount<<" edges"<<std::endl;
}
number_type maxAngleInTriangle(const Point_3 &a, const Point_3 &b, const Point_3 &c)
{
	number_type ab = sqrt((b-a).squared_length());
	number_type ac = sqrt((c-a).squared_length());
	number_type bc = sqrt((b-c).squared_length());

	number_type a1 = (b-a)*(c-a) / (ab*ac);
	number_type a2 = (c-b)*(a-b) / (bc*ab);
	number_type a3 = (a-c)*(b-c) / (ac*bc);

	number_type angle = qMin(a1, qMin(a2,a3));
	return angle;
}

void Mesh::flipEdgesAroundBigAngledTriangles()
{
	//naive (slow) implementation
	int flipCount = 0;

	Mesh::Halfedge_handle edgeToFlip;

	do
	{
		edgeToFlip = NULL;
		number_type best = 0;

		for (Mesh::Edge_iterator h = this->edges_begin();
			h != this->edges_end();
			h++)
		{
			if (h->vertex()->degree() < 3
				||
				h->opposite()->vertex()->degree() < 3)
				continue;

			Point_3 a = h->vertex()->point();
			Point_3 b = h->next()->vertex()->point();
			Point_3 c = h->opposite()->vertex()->point();
			Point_3 d = h->opposite()->next()->vertex()->point();

			number_type mAngle1 = maxAngleInTriangle(a,b,c);
			number_type mAngle2 = maxAngleInTriangle(a,c,d);

			//min, because we work with the cosine of the angle
			number_type maxAngle = qMin(mAngle1, mAngle2);

			mAngle1 = maxAngleInTriangle(a,b,d);
			mAngle2 = maxAngleInTriangle(c,d,b);

			if ((b-c)*(d-c) < 0
				||
				(b-a)*(d-a) < 0)
				continue;

			//min, because we work with the cosine of the angle
			number_type maxAlternativeAngle = qMin(mAngle1, mAngle2);

			if (maxAlternativeAngle > maxAngle)
			{
				edgeToFlip = h;
				break;
			}
		}

		if (edgeToFlip != NULL)
		{
			flipEdge(edgeToFlip);
			flipCount++;
		}
	}
	while(edgeToFlip != NULL);;

	std::cerr << "flipped "<<flipCount<<" edges"<<std::endl;
}

number_type Mesh::edgeLengthSquared(Mesh::Halfedge_handle halfedge)
{
	Vector_3 vec = halfedge->vertex()->point() - halfedge->prev()->vertex()->point();
	return vec*vec;
}

void Mesh::triangulateFacet(Mesh::Facet_handle facet)
{
	unsigned int facetSize = facet->size();
	if (facetSize < 4)
		return;

	Mesh::Halfedge_handle splitStart = NULL, splitEnd = NULL;

	Mesh::Halfedge_handle hStart = facet->halfedge();

	Mesh::Halfedge_handle h = hStart;

	float best = -1;		

	do
	{
		Mesh::Halfedge_handle g = h->next();
		
		do
		{
			if (
				g != h->next()
				&&
				h != g->next()
				)
			{
				Enriched_kernel::Vector_3 dVec = g->vertex()->point() - h->vertex()->point();
				float d = dVec*dVec;

				//avoid illegal triangulations
				bool illegalTriangulation = false;
				if (g == h->next()->next()
					&&
					h->next()->opposite()->facet() == g->opposite()->facet())
					illegalTriangulation = true;
				else
				if (h == g->next()->next()
					&&
					g->next()->opposite()->facet() == h->opposite()->facet())
					illegalTriangulation = true;
				else
				if (h->vertex() == g->vertex())
					illegalTriangulation = true;

				if (!illegalTriangulation && (best == -1 || best > d))
				{
					splitStart = h;
					splitEnd = g;
					best = d;
				}
			}
			g = g->next();
		}
		while (g != h);

		h = h->next();
	}
	while (h != hStart);

	if (best == -1)
	{
		//there is no way to triangulate the polygon, so add a center vertex instead

		//find average of neighbouring vertices
		float x=0,y=0,z=0;
		Mesh::Halfedge_handle g = hStart;
		do
		{
			Enriched_kernel::Point_3 p = g->vertex()->point();
			x += p.x();
			y += p.y();
			z += p.z();

			g = g->next();
		}while (g != hStart);

		Enriched_kernel::Point_3 center(x/facetSize,y/facetSize,z/facetSize);
		
		//re-create a center vertex at middle of the polygon
		g = this->create_center_vertex(hStart);
		g->vertex()->point() = center;
	}
	else
	{
		Mesh::Halfedge_handle splitter = this->split_facet(splitStart, splitEnd);
		Mesh::Halfedge_handle splitterOp = splitter->opposite();

		triangulateFacet(splitter->facet());
		triangulateFacet(splitterOp->facet());
	}
}

void Mesh::removeVertex(Mesh::Vertex_handle vertex)
{
	Mesh::Halfedge_handle h = vertex->halfedge();
    Mesh::Halfedge_handle g = this->erase_center_vertex(h);
	triangulateFacet(g->facet());
}

void Mesh::removeVertices(std::vector<Mesh::Vertex_handle> &vertices)
{
	std::cout << "removing " << vertices.size() << " vertices" << std::endl;
	for (unsigned int i=0; i<vertices.size(); i++)
	{
		removeVertex(vertices[i]);
	}

#ifdef _DEBUG
	//sanity checks
	//check that all facets are of size 3
	for ( Mesh::Facet_iterator f = this->facets_begin(); f != this->facets_end(); ++f){
		//all facets must be of size 3
		CGAL_assertion( f->size() ==  3);
	}

	for ( Mesh::Vertex_iterator v = this->vertices_begin(); v != this->vertices_end(); ++v){
		//all vertices must be of degree 3 or more
		CGAL_assertion( v->degree() >=  3);
	}

#endif
}

void Mesh::splitEdgesLongerThan(const number_type maxEdgeLength)
{

	number_type M = maxEdgeLength * maxEdgeLength;

	Mesh::Halfedge_handle best;
	do{
		//find the longest edge
		number_type bestM = M;
		best = NULL;

		for ( Mesh::Edge_iterator h = this->edges_begin(); h != this->edges_end(); ++h)
		{
			//meet facet-join preconditions
			if (h->vertex()->degree() < 3
				||
				h->opposite()->vertex()->degree() < 3)
				continue;

			number_type hVecLen = edgeLengthSquared(h);

			if (hVecLen > bestM)
			{
				bestM = hVecLen;
				best = h;
			}
		}

		//split the longest edge (if found) - by adding a vertex t its center
		if (best != NULL)
		{
			Enriched_kernel::Point_3 p1 = best->vertex()->point();
			Enriched_kernel::Point_3 p2 = best->opposite()->vertex()->point();

			Enriched_kernel::Point_3 center((p1.x() + p2.x())/2,
				(p1.y() + p2.y())/2,
				(p1.z() + p2.z())/2);

			//delete edge h
			Mesh::Halfedge_handle g = this->join_facet(best);

			//create a center vertex
			g = this->create_center_vertex(g);
			g->vertex()->point() = center;

		}

	} while (best != NULL);		//continue until no long edge is found


/*	number_type len2 = len*len;

	std::vector<Mesh::Halfedge_handle> edgesToSplit;
	do
	{
		edgesToSplit.clear();

		for (Mesh::Halfedge_iterator h = this->halfedges_begin();
			 h != this->halfedges_end();
			 h++)
		{
			//measure edge length
			Vector_3 vec(h->vertex()->point(), h->prev()->vertex()->point());
			int edgeLen = vec*vec;

			//add the edge into the list
			if (edgeLen > len2)
				edgesToSplit.push_back(h);
		}

		splitEdges(edgesToSplit);
	}
	while (edgesToSplit.size() > 0);*/
}

/*Point_3 Mesh::calculateFacetCenter(Mesh::Facet_handle facet)
{
	//find average of neighbouring vertices
	Vector_3 center(0,0,0);
	Mesh::Halfedge_handle h = facet->halfedge();
	unsigned int s = facet->size();
	for (int i=0; i<s; i++)
	{
		center = center + (h->vertex()->point() - CGAL::ORIGIN);
		h = h->next();
	}


*/

void Mesh::createTetrahedron(const number_type radius, const Point_3 center)
{
	number_type r = radius / 1.73205;

	Point_3 a( r, r, r );
	Point_3 b( -r, r, -r);
	Point_3 c( -r, -r, r);
	Point_3 d( r, -r, -r);
	this->make_tetrahedron(a,b,c,d);

	this->translate(center - CGAL::ORIGIN);
}

void Mesh::createCube(const number_type radius, const Point_3 center)
{
	createSphere(radius, 1, center);
}

void Mesh::createSphere(const number_type radius, const unsigned int subDivisions, const Point_3 center)
{
	createTetrahedron(radius);

	std::vector<Mesh::Facet_handle> facetsToSubDiv;
	std::vector<Mesh::Halfedge_handle> edgesToFlip;
	for (unsigned int level = 0; level < subDivisions; level++)
	{
		facetsToSubDiv.clear();
		edgesToFlip.clear();

		//must put all faces into a vector
		for (Mesh::Facet_iterator f = this->facets_begin();
			 f != this->facets_end();
			 f++)
			facetsToSubDiv.push_back(f);
		for (Mesh::Edge_iterator h = this->edges_begin();
			 h != this->edges_end();
			 h++)
			edgesToFlip.push_back(h);

		for (unsigned int i=0; i<facetsToSubDiv.size(); i++)
		{
			Mesh::Facet_handle f = facetsToSubDiv[i];

			Point_3 center;
			this->compute_facet_center(f,center); 
			Vector_3 rad(CGAL::ORIGIN, center);
			number_type radLen = sqrt(rad*rad);
			rad = radius * rad / radLen;

			Mesh::Halfedge_handle h = f->halfedge();
			Mesh::Halfedge_handle g = this->create_center_vertex(h);

			g->vertex()->point() = CGAL::ORIGIN + rad;
		}

		flipEdges(edgesToFlip);
	}

	this->translate(center - CGAL::ORIGIN);
}

void Mesh::computeRayIntersect()
{
	if (!m_rayIntersect.isInitialized())
		m_rayIntersect.Init(*this, 40);
}

bool Mesh::isIntersectsWithRay(const Ray_3 &ray, number_type* distance, FILE* debugFile)
{
	*distance = m_rayIntersect.Query(ray, NULL, NULL, debugFile);

	return *distance != FLT_MAX;
}

void Mesh::compute_volume() 
{
	if (!m_rayIntersect.isInitialized())
		computeRayIntersect();

	m_minVolume = FLT_MAX;
	m_maxVolume = -FLT_MAX;
	int counter = 0;
	for (Mesh::Vertex_iterator it = vertices_begin(); it != vertices_end(); it++)
	{
		compute_volume(it, 3, 20, true);
		/*compute_volume(it, m_renderingParams->m_volumeConeNumber,
			m_renderingParams->m_volumeConeSeperation,
			m_renderingParams->m_volumeRaysInCone,
			m_renderingParams->m_volumeUseGaussianWeights);*/

		if (it->volume() < m_minVolume) m_minVolume = it->volume();
		if (it->volume() > m_maxVolume) m_maxVolume = it->volume();

		//f << counter << ": " << it->volume() << std::endl;

		counter++;
	}

	//normalize
	float mod = 100;
	float logmod = logf(mod);
	for (Mesh::Vertex_iterator it = vertices_begin(); it != vertices_end(); it++)
	{
		it->volume() = (it->volume() - m_minVolume) / (m_maxVolume - m_minVolume);
	}

	m_minVolume = 0;
	m_maxVolume = 1;


/*
	f << "=================================" << std::endl;
	f << "Max " << m_maxVolume << ", Min " << m_minVolume << std::endl;

	f.close();
*/
}

void Mesh::compute_volume_range_on_facets(number_type& minVal, number_type& maxVal)
{
	minVal = FLT_MAX;
	maxVal = -FLT_MAX;

	Mesh::Facet_const_iterator it = facets_begin();
	Mesh::Facet_const_iterator it_end = facets_end();
	for (;it != it_end; it++) {
		if (it->volume()<minVal) minVal = it->volume();
		if (it->volume()>maxVal) maxVal = it->volume();
	}
}

void Mesh::average_volume()
{
	std::vector<number_type> avgVolume;
	avgVolume.reserve(size_of_vertices());

	for (Mesh::Vertex_iterator it = vertices_begin(); it != vertices_end(); it++)
	{
		Mesh::Halfedge_around_vertex_circulator c = it->vertex_begin();

		number_type avg = 0;
		number_type weights = 0.0;

		do {			
			number_type weight = c->length();
			weights += weight;
			avg += weight * c->opposite()->vertex()->volume();
		} while (++c != it->vertex_begin());

		avg  /= weights;

		avg = (avg + it->volume()) / 2;

		avgVolume.push_back(avg);
	}

	int index = 0;
	for (Mesh::Vertex_iterator it = vertices_begin(); it != vertices_end(); it++)
	{
		it->volume(avgVolume[index]);
		index++;
	}
}

void Mesh::fill_normalized_volume()
{
	const static float logModifier = 4.0;
	const static number_type mulBy = 1 / logf(logModifier+1);

	float minVolume = FLT_MAX;
	float maxVolume = 0.0;
	for (Mesh::Facet_iterator fit = facets_begin(); fit != facets_end(); fit++) {
		if (fit->volume() < minVolume) minVolume = fit->volume();
		if (fit->volume() > maxVolume) maxVolume = fit->volume();
	}

	float range = 1 / (maxVolume - minVolume);

	for (Mesh::Facet_iterator fit = facets_begin(); fit != facets_end(); fit++) {
		float nvolume = (fit->volume() - minVolume) * range;

		nvolume = logf(nvolume * logModifier + 1) * mulBy;
		fit->nvolume(nvolume);
	}
}

void Mesh::smooth_volume(const bool anisotropic, const float windowSize, const int iterations)
{
	const static float reduced_weight = 0.3; 

	Mesh::Facet_iterator fit = facets_begin();
	Mesh::Facet_iterator fit_end = facets_end();
	for (; fit != fit_end; fit++) {
		number_type initialValue = fit->volume();
		number_type initialNValue = fit->nvolume();

		for (int i=0;i<iterations;i++) {

			number_type smoothedValue = initialValue;
			number_type smoothedNValue = initialNValue;
			number_type weights = (initialValue==0.0 ? 0.0 : 1.0);
			
			Mesh::Halfedge_around_facet_circulator c = fit->facet_begin();
			do {
				if (c->opposite()->facet() != NULL) {
					number_type sneighborVolume = c->opposite()->facet()->volume();
					number_type sneighborNVolume = c->opposite()->facet()->nvolume();
					if ( !anisotropic || (sneighborNVolume - initialNValue) < windowSize) {
						smoothedValue += sneighborVolume * reduced_weight;
						smoothedNValue += sneighborNVolume * reduced_weight;
						weights += reduced_weight;
					}						
				}					
			} while (++c != fit->facet_begin());
			
			//fit->volume(safeDiv(smoothedValue, weights));
			fit->nvolume(safeDiv(smoothedNValue, weights));
			initialValue = fit->volume();
			initialNValue = fit->nvolume();
		}						
	}
}

Ray_3 Mesh::get_normal_opposite(const Point_3& p, const Vector_3& n)
{
	//direction opposite the normal
	Vector_3 direction = n * -1;	

	//construct segment from vertex pointing towards direction
	Ray_3 ray(
		p + direction * 1e-5,
		direction);

	return ray;
}

Ray_3 Mesh::get_normal_opposite(const Vertex_handle& v)
{
	//direction opposite the normal
	Vector_3 direction = v->normal() * -1;	

	//construct segment from vertex pointing towards direction
	Ray_3 ray(
		v->point() + direction * 1e-5,
		direction);

	return ray;
}

Aff_transformation_3 rotationMatrixAroundVertex(const Enriched_kernel::Vector_3& v, const number_type degrees)
{
	/*GLint mm;
	glGetIntegerv(GL_MATRIX_MODE, &mm);
	if (mm != GL_MODELVIEW);
		glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glRotatef(degrees, v.x(), v.y(), v.z());
	GLfloat mat[16];
	glGetFloatv(GL_MODELVIEW_MATRIX, mat);
	glPopMatrix();
	if (mm != GL_MODELVIEW);
		glMatrixMode(mm);
	

	Enriched_kernel::Aff_transformation_3 aff1(
		mat[0], mat[1], mat[2], mat[3],
		mat[4], mat[5], mat[6], mat[7],
		mat[8], mat[9], mat[10], mat[11]);*/

	float c = cos(degrees);
	float s = sin(degrees);
	float t = 1-c;
	Enriched_kernel::Aff_transformation_3 aff2(
		t*v.x()*v.x() + c, t*v.x()*v.y() + s*v.z(), t*v.x()*v.z() - s*v.y(), 0,
		t*v.x()*v.y() - s*v.z(), t*v.y()*v.y() + c, t*v.y()*v.z() + s*v.x(), 0,
		t*v.x()*v.z() + s*v.y(), t*v.y()*v.z() - s * v.x(), t*v.z()*v.z() + c, 0);

	/*fprintf(stdout, "aff1[%f,%f,%f,%f|%f,%f,%f,%f|%f,%f,%f,%f]\n",
		mat[0], mat[1], mat[2], mat[3],
		mat[4], mat[5], mat[6], mat[7],
		mat[8], mat[9], mat[10], mat[11]);
	fprintf(stdout, "aff2[%f,%f,%f,%f|%f,%f,%f,%f|%f,%f,%f,%f]\n",
		aff2.m(0,0), aff2.m(0,1), aff2.m(0,2), aff2.m(0,3),
		aff2.m(1,0), aff2.m(1,1), aff2.m(1,2), aff2.m(1,3),
		aff2.m(2,0), aff2.m(2,1), aff2.m(2,2), aff2.m(2,3));*/

	return aff2;
}

std::list<Ray_3> Mesh::get_cone_rays(
	const Point_3& p,
	const Vector_3& n, 
	const float degree,
	const int spread)
{
	std::list<Ray_3> list;

	Ray_3 ray = get_normal_opposite(p, n);
	Vector_3 rayv = ray.to_vector();
	rayv = rayv / sqrt(rayv.squared_length());	

	//now check a cone
	Plane_3 plane(ray.source(), ray.to_vector());
	Vector_3 base = plane.base1()/sqrt(plane.base1().squared_length());	
	Enriched_kernel::Aff_transformation_3 aff = rotationMatrixAroundVertex(base, degree);

	Enriched_kernel::Aff_transformation_3 aroundRay =
		rotationMatrixAroundVertex(rayv, 2*M_PI/spread);

	Vector_3 spinMe = rayv;
	spinMe = spinMe / sqrt(spinMe.squared_length());
	spinMe = spinMe.transform(aff);
	for (int i=0;i<spread; i++) {
		Ray_3 coneRay(
			p + spinMe * 1e-5,
			spinMe);

		list.push_back(coneRay);
		spinMe = spinMe.transform(aroundRay);	
	}

	return list;
}

std::list<Ray_3> Mesh::get_cone_rays(
	const Vertex_handle& v, 
	const float degree,
	const int spread)
{
	return get_cone_rays(v->point(), v->normal(), degree, spread);
}

Enriched_kernel::Segment_3 shortenRay(
	const Enriched_kernel::Segment_3& ray, 
	const float distance) 
{
	Enriched_kernel::Vector_3 v = ray.to_vector();
	v = v * 1/sqrt(v*v);
	Enriched_kernel::Segment_3 s(ray[0], ray[0] + v * distance);

	return s;
}

number_type Mesh::compute_volume(
	const Point_3& p,
	const Vector_3& n,
	int numCones,
	float coneSeperation,
	int raysInCone,
	bool gaussianWeights,
	std::list<std::pair<Ray_3, number_type> >* resultRays,
	number_type* debugMedian,
	number_type* debugRange,
	FILE* debugFile)
{
	if (debugFile) {fprintf(debugFile, "Beggining compute volume\n"); fflush(debugFile);}

	if (!m_rayIntersect.isInitialized())
		computeRayIntersect();
	//basically shoot rays opposite the normal and do something with the distances we receive

	number_type result = 0.0;

	Ray_3 ray = get_normal_opposite(p, n);

	number_type distanceCounter = 0.0;
	float intersectionCounter = 0.0;

	number_type distance = FLT_MAX;

	std::vector<number_type> values;
	number_type max_value = 0.0;
	std::vector<float> weights;
	values.reserve(numCones * raysInCone + 1);

	if (debugFile) { fprintf(debugFile, "Found normal opposite\n"); fflush(debugFile);}

	//first check straight opposite to normal
	if (isIntersectsWithRay(ray, &distance, debugFile)) {
		//intersectionCounter+= 1.0;
		//distanceCounter += distance;

		if (distance > max_value) max_value = distance;
		values.push_back(distance);
		weights.push_back(1.0);

		if (resultRays)
			resultRays->push_back(std::pair<Ray_3, number_type>(ray, distance));
	} else if (resultRays) {
		resultRays->push_back(std::pair<Ray_3, number_type>(ray, diagonalLength()));
	}

	if (debugFile) {fprintf(debugFile, "Going to compute cones\n"); fflush(debugFile);}

	const float gaussianVar = 120.0 * DEG2RAD;	
	float gaussianDiv2 = 1 / (2 * pow(gaussianVar,2));	

	for (int i=0; i<numCones; i++) {
		//now check cone
		float degree = coneSeperation * (i+1);
		std::list<Ray_3> list = get_cone_rays(p, n, degree, raysInCone);
		for (std::list<Ray_3>::iterator it = list.begin(); it != list.end(); it++) {
			distance = FLT_MAX;
			if (isIntersectsWithRay(*it, &distance)) {
				float weight;
				if (gaussianWeights)
					weight = /*gaussianDiv1 * */expf(-pow(degree,2) * gaussianDiv2);
				else
					weight = 1.0;

				//intersectionCounter += weight;
				//distanceCounter += weight * distance;				
				if (distance > max_value) max_value = distance;
				values.push_back(distance);
				weights.push_back(weight);

				if (resultRays)
					resultRays->push_back(std::pair<Ray_3, number_type>(*it,distance));
			}			
		}
	}

	//calculate the average	
	for (int i=0; i<values.size();i++) {
		distanceCounter += values[i] * weights[i];
		intersectionCounter += weights[i];
	}

	if (intersectionCounter) {
		result = distanceCounter / intersectionCounter;

		//fix really insane values
		std::nth_element(values.begin(), values.begin()+(values.size()/2), values.end());
		number_type median = values[values.size()/2];
		
		float std_dev = 0.0;
		for (int i=0; i<values.size();i++) {
			std_dev += pow(values[i]-result, 2);
		}
		std_dev = sqrt(std_dev/values.size());
		distanceCounter = intersectionCounter = 0.0;

		if (debugMedian) *debugMedian = median;
		if (debugRange) *debugRange = 0.75 * std_dev;

		for (int i=0; i<values.size(); i++) {
			if (fabs(values[i]-/*result*/median) <= 0.5 * std_dev) {
				distanceCounter += values[i] * weights[i];
				intersectionCounter += weights[i];				
			}
		}

		if (intersectionCounter)
			result = distanceCounter / intersectionCounter;
		else
			result = 0.0;
	} else {
		result = 0.0;
	}

	return result;
}

void Mesh::compute_volume(
	Vertex_handle& v,
	int numCones,
	float coneSeperation,
	int raysInCone, 
	bool gaussianWeights,
	std::list<std::pair<Ray_3, number_type> >* resultRays,
	number_type* debugMedian,
	number_type* debugRange)
{
	v->volume(compute_volume(v->point(),v->normal(), numCones, coneSeperation, raysInCone, gaussianWeights, resultRays, debugMedian, debugRange));
}

void Mesh::fill_holes()
{
	//find one hole:
	Mesh::Halfedge_handle holeEdge;
	do
	{
		holeEdge = NULL;
		Mesh::Halfedge_iterator h = this->halfedges_begin();
		while (h != this->halfedges_end() && holeEdge == NULL)
		{
			if (h->facet() == NULL && h->is_border())
				holeEdge = h;
			h++;
		}

		//fill the hole
		if (holeEdge != NULL)
		{
			holeEdge = this->fill_hole(holeEdge);
			std::cerr << "filling hole of size "<<holeEdge->facet()->size()<<std::endl;
			this->triangulateFacet(holeEdge->facet());
		}
	}
	while (holeEdge != NULL); //repeat until no holes found
	
}

// superimpose vertices
void Mesh::superimpose_vertices()
{
	::glBegin(GL_POINTS);
	for(Point_iterator pPoint = points_begin();
		pPoint !=	points_end();
		pPoint++)
		::glVertex3d(pPoint->x(),pPoint->y(),pPoint->z());
	::glEnd(); //	// end point assembly
}

// superimpose vertices
void Mesh::superimpose_spheres(double scale)
{	
	/*GLUquadricObj* pQuadric = gluNewQuadric();
	::glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

	for(Vertex_iterator pVertex = vertices_begin();
		pVertex !=	vertices_end();
		pVertex++)
	{
		if (m_renderingParams->m_renderModeVertices ==
			RenderingParamsManager::RENDER_VERTICES_IMPORTANCE_ONLY && 
			!pVertex->important())
			continue;

		if (!m_renderingParams->m_displayFiller && pVertex->index()==-1)
			continue;

		::glPushMatrix();
		double radius = average_edge_length_around(pVertex);
		::glTranslated(pVertex->point().x(),
			pVertex->point().y(),
			pVertex->point().z());
		setSphereColor(pVertex);	
		::gluSphere(pQuadric,scale*radius*2,10,10); 
		::glPopMatrix();
	}
	gluDeleteQuadric(pQuadric);*/
}

// superimpose edges
void Mesh::superimpose_edges(
	bool	skip_ordinary_edges,
	bool	skip_control_edges,
	bool voronoi_edge)
{
	/*if (m_renderingParams->m_renderModeEdges == RenderingParamsManager::RENDER_EDGES_NONE)
		::glBegin(GL_LINES);
	for(Edge_iterator h = edges_begin();
		h != edges_end();
		h++)
	{
		// ignore	this edges
		if(skip_ordinary_edges &&	!h->control_edge())
			continue;

		// ignore	control	edges
		if(skip_control_edges	&& h->control_edge())
			continue;

		if (m_renderingParams->m_renderModeEdges == RenderingParamsManager::RENDER_EDGES_ONLY_BOUNDARY &&
			!h->is_border_edge())
		{
			continue;
		}

		if (m_renderingParams->m_renderModeEdges == RenderingParamsManager::RENDER_EDGES_CLUSTER_SEPERATION &&
			((h->facet() != NULL && h->opposite()->facet() != NULL &&
			h->facet()->cluster() == h->opposite()->facet()->cluster()) || 
			(h->facet() == NULL || h->opposite()->facet() == NULL)
			))
		{
			continue;
		}

		//ignore filler edges if setting is so...
		if (!m_renderingParams->m_displayFiller &&
			(h->vertex()->index() == -1 ||
			h->opposite()->vertex()->index() == -1))
		{
			continue;
		}

		// assembly	and	draw line	segment			
		if (m_renderingParams->m_renderModeEdges != RenderingParamsManager::RENDER_EDGES_NONE) {					
			setEdgeColor(h);
			glBegin(GL_LINES);
		}
		const Point& p1 = h->prev()->vertex()->point();
		const Point& p2 = h->vertex()->point();
		::glVertex3d(p1[0],p1[1],p1[2]);
		::glVertex3d(p2[0],p2[1],p2[2]);

		if (m_renderingParams->m_renderModeEdges != RenderingParamsManager::RENDER_EDGES_NONE)
			glEnd();
	}

	if (m_renderingParams->m_renderModeEdges == RenderingParamsManager::RENDER_EDGES_NONE)
		::glEnd();*/
}

//draw facet
void Mesh::gl_draw_facet(Facet_handle pFacet,
				bool smooth_shading,
				bool use_normals)
{	
	/*
	// one normal	per	face
	if(use_normals &&	!smooth_shading)
	{
		const Facet::Normal_3& normal = pFacet->normal();
		::glNormal3d(normal[0],normal[1],normal[2]);
	}

	bool highlightFacet = true;
	bool fillerFacet = false;
	
	int vcount  = 0;
	Halfedge_around_facet_circulator pHalfedge = pFacet->facet_begin();
	if (pHalfedge != NULL)
	do {
		vcount++;
		if (m_renderingParams->m_renderModeFacets == RenderingParamsManager::RENDER_FACETS_HIGHLIGHT_PATCH &&
			  pHalfedge->vertex()->distance() == FLT_MAX)
		{
			highlightFacet = false;
		}

		if (pHalfedge->vertex()->index() == -1)
			fillerFacet = true;
	} while(++pHalfedge	!= pFacet->facet_begin());

	if (!m_renderingParams->m_displayFiller && fillerFacet)
		return;		

	bool useGray = false;
	if (m_renderingParams->m_renderModeFacets == RenderingParamsManager::RENDER_FACETS_DIFFERENCE_DISTANCE ||
		m_renderingParams->m_renderModeFacets == RenderingParamsManager::RENDER_FACETS_TRIANGLE_ERROR)
		useGray = true;

	if (m_renderingParams->m_renderModeFacets == RenderingParamsManager::RENDER_FACETS_HIGHLIGHT_PATCH) {
		if (highlightFacet) {
			glColor3f(0.7,0.7,0.5);
		} else {
			glColor3ubv(m_renderingParams->m_meshColor);			
		}
	}

	pHalfedge = pFacet->facet_begin();
	if (pHalfedge != NULL) do
	{
		// one normal	per	vertex
		if(use_normals &&	smooth_shading)
		{
			const Facet::Normal_3& normal	=	pHalfedge->vertex()->normal();
			::glNormal3d(normal[0],normal[1],normal[2]);
		}

		// polygon assembly	is performed per vertex
		const Point& point	=	pHalfedge->vertex()->point();
		
		setFacetVertexColor(pFacet, pHalfedge, fillerFacet, vcount, useGray, painter);

		::glVertex3d(point[0],point[1],point[2]);
	}
	while(++pHalfedge	!= pFacet->facet_begin());
	*/
}

// draw	using	OpenGL commands	(display lists)
void Mesh::gl_draw(
	bool	smooth_shading,
	bool	use_normals)
{
	/*
	Facet_iterator pFacet	=	facets_begin();
	//find correct painter
	int color[3];
	FacetPainter* painter = NULL;
	for (int i=0; i<m_facetPainters.size(); i++)
	{
		if (m_facetPainters[i]->queryColor(pFacet, pFacet->halfedge(), m_renderingParams->m_renderModeFacets, color) != -999)		
		{
			painter = m_facetPainters[i];
			break;
		}
	}

	// draw	polygons
	
	for(;pFacet	!= facets_end();pFacet++)
	{
		// begin polygon assembly
		::glBegin(GL_POLYGON);
		gl_draw_facet(pFacet,smooth_shading,use_normals, painter);
		::glEnd(); // end polygon assembly
	}
	glFlush();
	*/
}

void Mesh::set_index_vertices()
{
	int	index	=	0;
	for(Vertex_iterator	pVertex	=	vertices_begin();
		pVertex	!= vertices_end();
		pVertex++)
	{
		if (pVertex->index() >= 0)
			pVertex->tag(index++);
	}
}

void Mesh::write_patch(
	const char *pFilename,
	std::set<Halfedge_handle, HalfedgeCompare>& seamTree,
	int seamLoops,
	int saveMode /* = SAVEMODE_COMPLETE */,
	bool saveFillerVertices /* = false */,
	bool saveDebugInfo /* = false */)
{
	std::ofstream	stream(pFilename);

	stream << saveMode << std::endl;

	stream << m_radius << std::endl;

	switch(saveMode) {
	case SAVEMODE_COMPLETE:		
		stream << size_of_vertices() << ' ' << size_of_facets() << std::endl;
		break;
	case SAVEMODE_MINIMAL:
		write_minimal_patch(stream, seamTree, seamLoops, saveDebugInfo);
		stream.close();
		return;
		break;
	case SAVEMODE_NOCONNECTIVITY:
		stream << size_of_vertices() << ' ' << size_of_facets() << std::endl;
		break;
	}

	// output	vertices
	for(Vertex_iterator pVertex	=	vertices_begin();
		pVertex !=	vertices_end();	
		pVertex++)
	{
		if (saveFillerVertices || pVertex->index() >= 0) {
			const Point_3 p = pVertex->point();
			stream <<	'v'	<< ' ' <<	p.x()	<< ' ' <<
			p.y()	<< ' ' <<	
			pVertex->index();

			if (saveDebugInfo) {
				stream << ' ' << pVertex->distance();
			}

			stream << std::endl;
		}
	}

	// precompute	vertex indices
	this->set_index_vertices();	

	// output	facets
	for(Facet_iterator pFacet	=	facets_begin();
		pFacet !=	facets_end();	
		pFacet++)	
	{
		bool fillerFacet = false;
		QString s("f");
		Halfedge_around_facet_circulator pHalfedge = pFacet->facet_begin();
		do {
			s += " " + QString::number(pHalfedge->vertex()->tag());
			if (!saveFillerVertices && pHalfedge->vertex()->index() == -1) {
				fillerFacet = true;			
				break;
			}
		} while(++pHalfedge	!= pFacet->facet_begin());
		
		if (!fillerFacet) {
			stream <<	std::string(s.toAscii()) << std::endl;
		}	
	}	 

	stream.close();
}

void Mesh::write_minimal_patch(
	std::ofstream& stream,		
	halfedgeSet_t& seamTree,
	int seamLoops,
	bool saveDebugInfo)
{
	std::map<int, float> index_distanceMap;

	if (seamLoops == 1 && seamTree.size() == 0) {
		for (Halfedge_iterator pHalfedge = border_halfedges_begin();
			pHalfedge != halfedges_end();
			pHalfedge++)
		{
			seamTree.insert(pHalfedge);
		}
	}

	//save all unique indexes
	for(Vertex_iterator pVertex	=	vertices_begin();
		pVertex !=	vertices_end();	
		pVertex++)
	{
		if (pVertex->index() != -1)
			index_distanceMap.insert(std::pair<int, float>(pVertex->index(), pVertex->distance()));
	}

	std::set<int> indexesOnBorderSet;
	for (halfedgeSet_t::iterator it = seamTree.begin(); it != seamTree.end(); it++) {
		indexesOnBorderSet.insert((*it)->vertex()->index());
		indexesOnBorderSet.insert((*it)->opposite()->vertex()->index());		
	}	

	stream << index_distanceMap.size();
	if (seamLoops != 1)
		stream << ' ' << seamTree.size() << std::endl;
	else
		stream << " 0" << std::endl;

	for (std::map<int, float>::iterator it = index_distanceMap.begin();
		it!= index_distanceMap.end();
		it++)
	{
		stream /*<< "v "*/ << it->first;
		if (
			indexesOnBorderSet.find(it->first) != indexesOnBorderSet.end())
			stream << ' ' << it->second;
		stream << std::endl;
	}
	
	if (seamLoops != 1)
		for (halfedgeSet_t::iterator it = seamTree.begin(); it != seamTree.end(); it++) {
			stream /*<< "h "*/ << (*it)->vertex()->index() << ' ' << (*it)->opposite()->vertex()->index() << std::endl;
		}

	return;
}

bool Mesh::save_volume(const char* fileName, const bool saveForClustering)
{
	Vertex_iterator vIt = vertices_begin();
	
	QByteArray array;
	//QBuffer buf( array );
	//buf.open( QIODevice::WriteOnly );
	QTextStream s( &array );

	QString str;
	for (Vertex_iterator it = vertices_begin(); it != vertices_end(); it++) {
		if (saveForClustering) {
			Point_3 p = it->point();
			//normalize point
			Point_3 newp(
				(p.x() - xmin()) / (xmax() - xmin()),
				(p.y() - ymin()) / (ymax() - ymin()),
				(p.z() - zmin()) / (zmax() - zmin()));
			str.sprintf("%f %f %f %f\n", newp[0], newp[1], newp[2], it->volume());
		} else {
			str.sprintf("%f\n", it->volume());
		}		
		s << str;
	}
//	buf.close();
	s.flush();

	QFile f(QString::fromAscii(fileName));
	if (!f.open(QIODevice::WriteOnly)) 
		return false;

	f.writeBlock(array);
	f.close();

	return true;	
}

bool Mesh::load_volume(const char* fileName)
{
	if (!QFile::exists(fileName))
		return false;

	Vertex_iterator vIt = vertices_begin();
	QFile f(QString::fromAscii(fileName));
	if (f.open(QIODevice::ReadOnly)) {
		QByteArray qba = f.readAll();
		QTextIStream s(&qba);
		while (!s.atEnd()) {
			float volume = s.readLine().toFloat();
			if (vIt != vertices_end()) {
				if (volume==volume)
					vIt->volume(volume);
				else
					vIt->volume(0.0);
				vIt++;
			} else {
				break;
			}
		}
		f.close();
		return true;
	} else {
		return false;
	}
}

void Mesh::reverseNormals()
{
	Enriched_Mesh::Vertex_iterator vit = vertices_begin();
	Enriched_Mesh::Vertex_iterator vit_end = vertices_end();

	for (;vit != vit_end; vit++) {
		vit->normal() = vit->normal()*(-1);
	}

	Enriched_Mesh::Facet_iterator fit = facets_begin();
	Enriched_Mesh::Facet_iterator fit_end = facets_end();

	for (;fit != fit_end; fit++) {
		fit->normal() = fit->normal()*(-1);
	}
}

Point_3 Mesh::getFacetCenter(const Enriched_Mesh::Facet_const_handle& f)
{
	number_type x = 0.0;
	number_type y = 0.0;
	number_type z = 0.0;

	Enriched_Mesh::Halfedge_around_facet_const_circulator c = f->facet_begin();
	do {
		Point_3 p = c->vertex()->point();
		x += p.x();
		y += p.y();
		z += p.z();
	} while (++c != f->facet_begin());

	return Point_3(x/3, y/3, z/3);
}