#include "stdafx.h"

#include "AppManager.h"
#include "AppParams.h"

#include <QTextStream>
#include <QFileDialog>

 
void AppManager::OnAppParams()
{
	int normalizeSdf;
	switch(m_appParameters.sdf_normalize) {
		case None: normalizeSdf = 0; break;
		case MinMax: normalizeSdf = 1; break;
		case Log: normalizeSdf = 2; break;
	}
	m_appParamsDialog->ui.normalizeSDF->setCurrentItem(normalizeSdf);
	m_appParamsDialog->ui.numberOfCones->setValue(m_appParameters.sdf_numcones);
	m_appParamsDialog->ui.coneSeperation->setValue(m_appParameters.sdf_coneSeperation);
	m_appParamsDialog->ui.raysInCone->setValue(m_appParameters.sdf_raysInCone);
	m_appParamsDialog->ui.gaussianWeights->setChecked(m_appParameters.sdf_gaussianWeights);
	m_appParamsDialog->ui.sdf_smoothing->setChecked(m_appParameters.sdf_smoothing);
	m_appParamsDialog->ui.sdf_smoothingAnisotropic->setChecked(m_appParameters.sdf_smoothing_anisotropic);
	m_appParamsDialog->ui.sdf_smoothingIterations->setValue(m_appParameters.sdf_smoothing_iterations);

	m_appParamsDialog->ui.multithreaded->setChecked(m_appParameters.multithreaded);
	m_appParamsDialog->ui.normsRev->setChecked(m_appParameters.normalsReversed);

	m_appParamsDialog->show();

}

void AppManager::appParamsOk()
{
	appParamsApply();
	m_appParamsDialog->hide();
}

void AppManager::appParamsApply()
{
	switch(m_appParamsDialog->ui.normalizeSDF->currentItem()) {
	case 0: m_appParameters.sdf_normalize = None; break;
	case 1: m_appParameters.sdf_normalize = MinMax; break;	
	case 2: m_appParameters.sdf_normalize = Log; break;
	}
	m_appParameters.sdf_numcones = m_appParamsDialog->ui.numberOfCones->value();
	m_appParameters.sdf_coneSeperation = m_appParamsDialog->ui.coneSeperation->value();
	m_appParameters.sdf_raysInCone = m_appParamsDialog->ui.raysInCone->value();
	m_appParameters.sdf_gaussianWeights = m_appParamsDialog->ui.gaussianWeights->isChecked();
	m_appParameters.sdf_smoothing = m_appParamsDialog->ui.sdf_smoothing->isChecked();
	m_appParameters.sdf_smoothing_anisotropic = m_appParamsDialog->ui.sdf_smoothingAnisotropic->isChecked();
	m_appParameters.sdf_smoothing_iterations = m_appParamsDialog->ui.sdf_smoothingIterations->value();

	m_appParameters.multithreaded = m_appParamsDialog->ui.multithreaded->isChecked();
	m_appParameters.normalsReversed = m_appParamsDialog->ui.normsRev->isChecked();

	saveApplicationParameters();
}

void AppManager::saveApplicationParameters()
{
	ProgSettings ps;
	ps.beginGroup("AppParams");
	ps.writeEntry("sdf_normalize", m_appParameters.sdf_normalize);
	ps.writeEntry("sdf_numcones", m_appParameters.sdf_numcones);
	ps.writeEntry("sdf_coneSeperation", m_appParameters.sdf_coneSeperation);
	ps.writeEntry("sdf_raysInCone", m_appParameters.sdf_raysInCone);
	ps.writeEntry("sdf_gaussianWeights", m_appParameters.sdf_gaussianWeights);
	ps.writeEntry("sdf_smoothing", m_appParameters.sdf_smoothing);
	ps.writeEntry("sdf_smoothingAnisotropic", m_appParameters.sdf_smoothing_anisotropic);
	ps.writeEntry("sdf_smoothingIterations", m_appParameters.sdf_smoothing_iterations);

	ps.writeEntry("multithreaded", m_appParameters.multithreaded);
	ps.writeEntry("norms_rev", m_appParameters.normalsReversed);

	ps.endGroup();
}

void AppManager::loadApplicationParameters()
{
	ProgSettings ps;
	ps.beginGroup("AppParams");
	switch(ps.readNumEntry("sdf_normalize", 0)) {
	case 0: m_appParameters.sdf_normalize = None; break;
	case 1: m_appParameters.sdf_normalize = MinMax; break;	
	case 2: m_appParameters.sdf_normalize = Log; break;
	}
	m_appParameters.sdf_numcones = ps.readNumEntry("sdf_numcones", 2);
	m_appParameters.sdf_coneSeperation = ps.readNumEntry("sdf_coneSeperation", 20);
	m_appParameters.sdf_raysInCone = ps.readNumEntry("sdf_raysInCone", 4);
	m_appParameters.sdf_gaussianWeights = ps.readBoolEntry("sdf_gaussianWeights", true);
	m_appParameters.sdf_smoothing = ps.readBoolEntry("sdf_smoothing", true);
	m_appParameters.sdf_smoothing_anisotropic = ps.readBoolEntry("sdf_smoothingAnisotropic", true);
	m_appParameters.sdf_smoothing_iterations = ps.readNumEntry("sdf_smoothingIterations", 4);

	m_appParameters.multithreaded = ps.readBoolEntry("multithreaded", false);
	m_appParameters.normalsReversed = ps.readBoolEntry("norms_rev", false);

	ps.endGroup();
}


