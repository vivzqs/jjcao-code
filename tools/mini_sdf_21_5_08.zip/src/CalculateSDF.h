#ifndef __CALCULATE_SDF_H_
#define __CALCULATE_SDF_H_

#include "stdafx.h"

#include <qobject.h>
#include <qthread.h>

#include <QApplication.h>

class CalculateSDFThread : public QThread 
{
	Q_OBJECT;
private:
	QString m_name;

	Mesh* m_mesh;

	number_type* m_results;
	const number_type* m_origins;
	int m_size;

	int m_numCones;
	float m_coneSeperation;
	int m_raysInCone;
	bool m_gaussianWeights;
signals:
	/// number of origins completed since the last singal
	void advancedIn(int numOfOrigins);

public:
	/**
	 *	constructor which accepts the target vertices/facets
	 */
	CalculateSDFThread(
		Mesh* mesh,
		const number_type* origins,
		const int size,
		number_type* results,
		int numCones,
		float coneSeperation,
		int raysInCone,
		bool gaussianWeights,
		const QString& name = QString::null);

	/**
	 *	runs the thread
	 */
	virtual void run();

};

enum NormalizeTypes {
	None,
	MinMax,
	Log
};

class QProgressDialog;

class CalculateSDF : public QObject 
{
	Q_OBJECT
public:
	CalculateSDF() : m_progDlg(NULL) {}

private:

	Point_3 getFacetCenter(const Mesh::Facet_const_handle& f);
	number_type logit(const number_type& value, const int& range);

	QProgressDialog *m_progDlg;

public slots:
	void addToProgress(int delta);

protected:
	/**
	 *	create source points from which to shoot rays
	 *
	 * @param mesh pointer to mesh
	 * @param onVertices if true calculates on vertices, otherwise on facets
	 * @param origins pointer to already allocated buffer which will hold : [x,y,z],[nx,ny,nz]
	 */
	void preprocess(
		Mesh* mesh, 
		const bool onVertices,
		number_type* origins);

	/**
	 *	write results to mesh
	 *
	 * @param mesh pointer to mesh
	 * @param onVertices if true calculates on vertices, otherwise on facets
	 * @param results array in which results are stored (not normalized)
	 * @param normalize if true normalize from 0 to 1
	 */
	bool postprocess(
		Mesh* mesh,
		const bool onVertices, 
		number_type* results, 
		const NormalizeTypes normalize, 
		const bool smoothing);
	
public:
	/**
	 *	calculate shape diameter function
	 *
	 * @param mesh pointer to mesh
	 * @param onVertices if true calculate on vertices, otherwise on facets
	 * @param multiThreaded if true run multi-threaded
	 */
	bool go(
		Mesh* mesh, 
		const bool onVertices, 
		const bool multiThreaded,
		const int numCones = 3,
		const float coneSeperation = 20,
		const int raysInCone = 4,
		const bool gaussianWeights = true,
		const NormalizeTypes normalize = None,
		const bool smoothing = false,
		const bool smoothingAnisotropic = false,
		const int smoothingIterations = 1,
		const bool showDialog = true);
};

#endif