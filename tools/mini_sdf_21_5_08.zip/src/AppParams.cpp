#include "stdafx.h"
#include "AppParams.h"

#include <deque>
#include <QToolTip>

AppParams::AppParams(QWidget* parent, const char* name, Qt::WFlags flags):
QDialog(parent, name, false, flags)
{
	ui.setupUi(this);
	init();
}

AppParams::~AppParams()
{

}

void AppParams::init()
{
	ui.normalizeSDF->insertItem("None");
	ui.normalizeSDF->insertItem("Min-Max");
	ui.normalizeSDF->insertItem("Log");

}


void AppParams::on_applyBot_clicked()
{
	emit pressdApply();
}

void AppParams::on_buttonOk_clicked()
{
	emit pressdOk();
}