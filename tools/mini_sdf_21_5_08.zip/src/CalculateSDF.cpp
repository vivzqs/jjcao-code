#include "stdafx.h"
#include "CalculateSDF.h"

#include <qdatetime.h>
#include <QApplication>
#include <QProgressDialog>

const int SDF_THREADS_NUM = 4;

number_type CalculateSDF::logit(const number_type& value, const int& range)
{
	return logf(value * range + 1)/logf(range+1);
}

Point_3 CalculateSDF::getFacetCenter(const Mesh::Facet_const_handle& f)
{
	number_type x = 0.0;
	number_type y = 0.0;
	number_type z = 0.0;

	Mesh::Halfedge_around_facet_const_circulator c = f->facet_begin();
	do {
		Point_3 p = c->vertex()->point();
		x += p.x();
		y += p.y();
		z += p.z();
	} while (++c != f->facet_begin());

	return Point_3(x/3, y/3, z/3);
}

void CalculateSDF::preprocess(Mesh* mesh, const bool onVertices, number_type* origins)
{
	if (onVertices) {
		int ind = 0;
		Mesh::Vertex_const_iterator vit = mesh->vertices_begin();
		Mesh::Vertex_const_iterator vit_end = mesh->vertices_end();
		for (; vit != vit_end; vit++) {
			origins[ind*6  ] = vit->point().x();
			origins[ind*6+1] = vit->point().y();
			origins[ind*6+2] = vit->point().z();
			origins[ind*6+3] = vit->normal().x();
			origins[ind*6+4] = vit->normal().y();
			origins[ind*6+5] = vit->normal().z();
			ind++;
		}
	} else {
		int ind = 0;
		Mesh::Facet_const_iterator fit = mesh->facets_begin();
		Mesh::Facet_const_iterator fit_end = mesh->facets_end();
		for (; fit != fit_end; fit++) {
			Point_3 p = getFacetCenter(fit);
			origins[ind*6  ] = p.x();
			origins[ind*6+1] = p.y();
			origins[ind*6+2] = p.z();
			origins[ind*6+3] = fit->normal().x();
			origins[ind*6+4] = fit->normal().y();
			origins[ind*6+5] = fit->normal().z();
			ind++;
		}
	}
}

bool CalculateSDF::postprocess(
	Mesh* mesh, 
	const bool onVertices, 
	number_type* results, 
	const NormalizeTypes normalize,
	const bool smoothing)
{	
	int numPoints = (onVertices? mesh->size_of_vertices() : mesh->size_of_facets());

	//missing values get average of neighbors
	for (int i=0;i<numPoints;i++) 
	{
		if (results[i] == 0.0) 
		{
			number_type smoothedValue = 0.0;
			number_type smoothedWeights = 0.0;

			if (onVertices) 
			{
				Mesh::Vertex_handle v = mesh->find_vertex(i);
				Mesh::Halfedge_around_vertex_circulator c = v->vertex_begin();
				do {
					smoothedValue += results[c->opposite()->vertex()->index()];
					smoothedWeights += 1.0;
				} while (++c != v->vertex_begin());
			} 
			else 
			{
				Mesh::Facet_handle f = mesh->find_facet(i);
				Mesh::Halfedge_around_facet_circulator c = f->facet_begin();
				do {
					if (c->opposite()->facet() != NULL) {
						smoothedValue += results[c->opposite()->facet()->index()];
						smoothedWeights += 1.0;
					}
				} while (++c != f->facet_begin());
			}

			results[i] = safeDiv(smoothedValue, smoothedWeights);
		}
	}
	
	//////////////////////////////////////////////////////////////////////////
	
	number_type maxValue = -FLT_MAX;
	number_type minValue = FLT_MAX;
	for (int i=0;i<numPoints;i++) {
		if (results[i]<minValue) minValue = results[i];
		if (results[i]>maxValue) maxValue = results[i];
	}	
	if (minValue == maxValue)
		return false; // something is wrong. abort all.

	if (normalize != None) 
	{		
		number_type theDivider = 1 / (maxValue - minValue);
		for (int i=0;i<numPoints;i++) {
			results[i] = (results[i] - minValue) * theDivider;
			if (normalize == Log) 
				results[i] = logit(results[i], 5);
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// Place the values in the mesh
	//////////////////////////////////////////////////////////////////////////
	const static number_type reduced_weight = 0.2;

	const number_type window_size = 0.1;
	const int smoothing_iterations = 1;

	if (onVertices) {
		int ind = 0;
		Mesh::Vertex_iterator vit = mesh->vertices_begin();
		Mesh::Vertex_iterator vit_end = mesh->vertices_end();
		for (; vit != vit_end; vit++) {
			if (!smoothing)
				vit->volume(results[ind]);
			else {
				number_type smoothedValue = results[ind];
				number_type smoothedWeights = (results[ind]==0.0 ? 0.0 : 1.0);				
				Mesh::Halfedge_around_vertex_circulator c = vit->vertex_begin();
				do {
					smoothedValue += results[c->opposite()->vertex()->index()] * reduced_weight;
					smoothedWeights += reduced_weight;
				} while (++c != vit->vertex_begin());

				vit->volume(safeDiv(smoothedValue, smoothedWeights));
			}
			ind++;			
		}
	} else {
		int ind = 0;
		Mesh::Facet_iterator fit = mesh->facets_begin();
		Mesh::Facet_iterator fit_end = mesh->facets_end();
		for (; fit != fit_end; fit++) {
			if (!smoothing)
				fit->volume(results[ind]);
			else {
				number_type initialValue = results[ind];
				for (int i=0;i<smoothing_iterations;i++) {
					number_type smoothedValue = initialValue;
					number_type smoothedWeights = (initialValue==0.0 ? 0.0 : 1.0);
					Mesh::Halfedge_around_facet_circulator c = fit->facet_begin();
					do {
						if (c->opposite()->facet() != NULL) {
							number_type sneighbor = results[c->opposite()->facet()->index()];
							//if (fabs(sneighbor-results[ind])<window_size) {
								smoothedValue += results[c->opposite()->facet()->index()] * reduced_weight;
								smoothedWeights += reduced_weight;
							//}						
						}					
					} while (++c != fit->facet_begin());
					fit->volume(safeDiv(smoothedValue, smoothedWeights));
					initialValue = fit->volume();

				}				
			}
			ind++;
		}
	}
	return true;
}

bool CalculateSDF::go(
	Mesh* mesh,
	const bool onVertices,
	const bool multiThreaded,
	const int numCones,
	const float coneSeperation,
	const int raysInCone,
	const bool gaussianWeights,
	const NormalizeTypes normalize,
	const bool smoothing,
	const bool smoothingAnisotropic,
	const int smoothingIterations,
	const bool showDialog)
{
	QTime timer;

	timer.start();

	int originsSize = (onVertices?mesh->size_of_vertices():mesh->size_of_facets());
	number_type* origins = new number_type[originsSize * 6];
	preprocess(mesh, onVertices, origins);

	int numOfThreads = (multiThreaded? SDF_THREADS_NUM : 1);

	int timerPreprocess = timer.elapsed();


	if (showDialog)
		m_progDlg = new QProgressDialog("Calculating SDF", "cancel", 0, originsSize - 1, g_main);
	else
		m_progDlg = NULL;

	//////////////////////////////////////////////////////////////////////////
	// Prepare search structure on mesh
	//////////////////////////////////////////////////////////////////////////
	mesh->computeRayIntersect();

	int timerComputeSearchStructure = timer.elapsed();

	//////////////////////////////////////////////////////////////////////////
	// Initialize the threads
	//////////////////////////////////////////////////////////////////////////
	number_type* results = new number_type[originsSize];
	number_type* resultsPtr = results;

	number_type* dataPtr = origins;
	int dataSize = originsSize / numOfThreads;
	std::vector<CalculateSDFThread*> threads;
	for (int i=0; i<numOfThreads; i++) 
	{
		if (i == numOfThreads-1 && originsSize % dataSize != 0)
			dataSize += originsSize % dataSize;		

		CalculateSDFThread* cst = 
			new CalculateSDFThread(mesh, dataPtr, dataSize, resultsPtr, numCones, coneSeperation, raysInCone, gaussianWeights, QString::number(i));

		connect(cst, SIGNAL(advancedIn(int)), this, SLOT(addToProgress(int)));

		dataPtr += dataSize * 6;
		resultsPtr += dataSize;
		threads.push_back(cst);
	}

	// Run the threads and wait for them to finish
	if (multiThreaded) {
		for (int i=0; i<threads.size(); i++) {
			threads[i]->start();
		}

		for (int i=0; i<threads.size(); i++) {
			threads[i]->wait();
		}
	} else {
		threads[0]->run();
	}

	int timerAllThreadsFinished = timer.elapsed();

	//////////////////////////////////////////////////////////////////////////
	// Put the results back in the mesh
	//////////////////////////////////////////////////////////////////////////
	//only apply smoothing if on vertices
	if (!postprocess(mesh, onVertices, results, normalize, smoothing && onVertices))
		return false;

	//perform smoothing on the mesh itself
		
	if (!onVertices) {
		mesh->makeFacesNVolume(smoothing, smoothingAnisotropic, smoothingIterations);
	}
	

	int timerPostprocess = timer.elapsed();

	//////////////////////////////////////////////////////////////////////////
	// Clean up
	//////////////////////////////////////////////////////////////////////////
	for (int i=0; i<threads.size(); i++) {
		delete threads[i];
	}
	threads.clear();
	delete[] origins;
	delete[] results;
	m_progDlg = NULL;

	int timerTotal = timer.elapsed();

	if (showDialog) {
		qDebug("Calculated SDF total time %dms. preprocess %dms, compute %dms, threads %dms, postprocess %dms",
			timerTotal, timerPreprocess, timerComputeSearchStructure, timerAllThreadsFinished, timerPostprocess);

		QString s;
		QString workingon = (onVertices?"vertices" : "facets");
		QString mt = (multiThreaded?"multithreaded" : "not multithreaded");
		s.sprintf("Mesh size v=%d f=%d\nWorking on %s, Working %s\nTotal time %f seconds", mesh->size_of_vertices(), mesh->size_of_facets(), workingon.toAscii(), mt.toAscii(), (float)timerTotal / 1000);
		QMessageBox::information(g_main, "SDF calculation complete", s);
	}	
	return true;
}

void CalculateSDF::addToProgress(int delta)
{
	if (m_progDlg == NULL) return;
	m_progDlg->setValue(m_progDlg->value() + delta);
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

CalculateSDFThread::CalculateSDFThread(
	Mesh* mesh,
	const number_type* origins, 
	const int size, 
	number_type* results,
	int numCones,
	float coneSeperation,
	int raysInCone,
	bool gaussianWeights,
	const QString& name) :
m_mesh(mesh), m_origins(origins), m_size(size), m_results(results), m_numCones(numCones), 
m_coneSeperation(coneSeperation), m_raysInCone(raysInCone), m_gaussianWeights(gaussianWeights),
m_name(name)
{
	
}

void CalculateSDFThread::run()
{
	//setPriority(QThread::LowPriority);
	/*FILE* f;
	QString debugFileName = "c:/temp/threaddebug_" + m_name + ".txt";
	f = fopen(debugFileName.toAscii(), "wt");*/
	QTime timer;

	timer.start();

	/*fprintf(f, "Calculating SDF thread\n\n");	

	fprintf(f, "Address of origins %d", m_origins);
	fprintf(f, ", size of array %d\n", m_size);

	fflush(f);*/

	number_type degree = m_coneSeperation * DEG2RAD;
	int lastReported = 0;
	int i;
	for (i = 0; i < m_size; i++) 
	{
		Point_3 p(m_origins[i*6], m_origins[i*6+1], m_origins[i*6+2]);
		Vector_3 n(m_origins[i*6+3], m_origins[i*6+4], m_origins[i*6+5]);
		//fprintf(f, "%d ||| [%f,%f,%f] <%f,%f,%f> -->", i, p.x(), p.y(), p.z(), n.x(), n.y(), n.z());
		//fflush(f);
		m_results[i] = m_mesh->compute_volume(p, n, m_numCones, degree, m_raysInCone, m_gaussianWeights, NULL/*, f*/);
		//fprintf(f, " %f\n", m_results[i]);
		//fflush(f);

		if ((i % 20) == 0)
		{
			emit advancedIn(i - lastReported);
			qApp->processEvents();
			sleep(0);
			lastReported = i;
		}
	}	
	emit advancedIn(i - lastReported);

	int totalTime = timer.elapsed();
	//fprintf(f, "------------------------------------\n");
	//fprintf(f, "Total time %f seconds (%f msecs each point)\n", (float)totalTime/1000, (float)totalTime/m_size);

	//fclose(f);
}