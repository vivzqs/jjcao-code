// sdf.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#include <QApplication>

#include <QStatusBar>

#include "SdfViewer.h"


#include "MainWindow.h"

#include "AppManager.h"
#include "WorldManager.h"

#define MAX_LOADSTRING 100

class FacetPainter;

bool setupConnections(QApplication& application, AppManager* appManager, WorldManager* worldManager, MainWindow* smf);

QMainWindow *g_main = NULL;
MainWindow *g_sdfmain = NULL;
AppManager *g_appManager = NULL;

LONG WINAPI myExceptionFilter(EXCEPTION_POINTERS* ExceptionInfo)
{
	return EXCEPTION_EXECUTE_HANDLER;
}

void my_invalid_parameter(const wchar_t * expression, const wchar_t * function, const wchar_t * file, unsigned int line, uintptr_t pReserved)
{
	throw QString("invalid");
}

int main(int argc, char** argv)
{
//	SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOOPENFILEERRORBOX);
//	SetUnhandledExceptionFilter(myExceptionFilter);
//	_set_error_mode(_OUT_TO_STDERR);
//	_CrtSetReportMode(_CRT_ERROR, _CRTDBG_MODE_FILE);
//	_CrtSetReportMode(_CRT_ASSERT, _CRTDBG_MODE_FILE);
//	_CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_FILE);
//	_CrtSetReportFile(_CRT_ASSERT, _CRTDBG_FILE_STDERR);


	_set_invalid_parameter_handler(my_invalid_parameter);

	// Read command lines arguments.
	QApplication a(argc,argv);
	QCoreApplication *p = QCoreApplication::instance();
	
	MainWindow smf(NULL);
	g_main = &smf;
	g_sdfmain = &smf;

//	smf.ui.CorrespondenceToolbar->hide();

	// initialize log object
	ProgSettings ps;	
	QString logFile = ps.readEntry("log_file", "c:/temp/sdf_log.txt");
	int logLevel = ps.readNumEntry("log_level", 8);
	GlobalLog::init(&smf,logFile, logLevel);
	ps.writeEntry("log_file", logFile);
	ps.writeEntry("log_level", logLevel);

	SDFLOG10("===================== SDF Starting =========================");

	//load two main managers
	AppManager* appManager = new AppManager(&smf, "appManager");
	g_appManager = appManager;
	WorldManager* worldManager = new WorldManager(smf.ui.world, &smf, "worldManager");

	if (!setupConnections(a, appManager, worldManager, &smf)) {
		QMessageBox::warning(g_main, "Error on initialization", "Could not setup slot/signal connections");

		return -1;
	}
	//////////////////////////////////////////////////////////////////////////

	//initialize App Manager
	appManager->Init(worldManager);

	//////////////////////////////////////////////////////////////////////////
		

	smf.show();	

	// Set the viewer as the application main widget.
	//application.setMainWidget(smf);

	// Run main loop.
	return a.exec();
}

bool setupConnections(QApplication& application, AppManager* appManager, WorldManager* worldManager, MainWindow* smf)
{
	bool success = true;

//	success &= GlobalLog::getLog()->connect((const QObject*)smf->ui.showLogAction,	SIGNAL(activated()), SLOT(ShowLog()));

	success &= appManager->connect((const QObject*)smf->ui.fileOpenAction,	SIGNAL(activated()), SLOT(OnLoadObject()));
	success &= appManager->connect((const QObject*)smf->ui.clearModelsAction,	SIGNAL(activated()), SLOT(OnRemoveObjects()));
	success &= appManager->connect((const QObject*)smf->ui.removeSelectedModelAction,	SIGNAL(activated()), SLOT(OnRemoveSelectedObject()));
	success &= appManager->connect((const QObject*)smf->ui.appParametersAction, SIGNAL(activated()), SLOT(OnAppParams()));
	success &= appManager->connect((const QObject*)smf->ui.loadMeshFeaturesAction,	SIGNAL(activated()), SLOT(OnLoadObjectFeatures()));
	success &= appManager->connect((const QObject*)smf->ui.saveMeshFeaturesAction,	SIGNAL(activated()), SLOT(OnSaveObjectFeatures()));


	success &= appManager->connect((const QObject*)smf->ui.calculateSDFFacetsAction,	SIGNAL(activated()), SLOT(OnCalculateSDFFacets()));
	success &= appManager->connect((const QObject*)smf->ui.calculateSDFVerticesAction,	SIGNAL(activated()), SLOT(OnCalculateSDFVertices()));
	success &= QObject::connect(smf->ui.snapAction, SIGNAL(activated()), smf->ui.world, SLOT(saveManualSnap()));
	success &= appManager->connect((const QObject*)smf->ui.reverseNormalsAction,	SIGNAL(activated()), SLOT(OnReverseNormals()));

	success &= smf->statusBar()->connect(appManager, SIGNAL(message(const QString&)), SLOT(message(const QString&)));
	success &= smf->statusBar()->connect(appManager, SIGNAL(message(const QString&, int)), 	SLOT(message(const QString&, int)));

	success &= appManager->connect(worldManager, SIGNAL(ObjectSelected(const QString&)), SLOT(OnObjectSelected(const QString&)));
	success &= appManager->connect(worldManager, SIGNAL(FacetSelected(const QString&, const int)), SLOT(OnFacetSelected(const QString&, const int)));
	success &= appManager->connect(worldManager, SIGNAL(doRemoveObject(const QString&)), SLOT(removeObject(const QString&)));


	success &= worldManager->connect(appManager, SIGNAL(ObjectsChanged()), SLOT(invalidate()));
	success &= worldManager->connect(appManager, SIGNAL(ObjectChanged(const QString&, bool)), SLOT(OnChangeObject(const QString&, bool)));
	
	success &= worldManager->connect(appManager, 
		SIGNAL(ObjectAdded(AppObject*, TStubData*, DrawMethod)), 
		SLOT(OnAddObject(AppObject*, TStubData*, DrawMethod)));

	success &= worldManager->connect(appManager, SIGNAL(ObjectRemoved(const QString&)),	SLOT(OnRemoveObject(const QString&)));

	success &= worldManager->connect(smf, SIGNAL(functionKeyPressed(int, Qt::ButtonState)), SLOT(OnFunctionKeyPressed(int, Qt::ButtonState)));
	success &= appManager->connect(smf, SIGNAL(arrowKeyPressed(int, Qt::ButtonState)), SLOT(OnArrowKeyPressed(int, Qt::ButtonState)));

	success &= worldManager->connect((const QObject*)smf->ui.renderingParametersAction, SIGNAL(activated()), SLOT(OnEditRenderingParameters()));
	success &= worldManager->connect((const QObject*)smf->ui.glLightsAction, SIGNAL(activated()), SLOT(OnEditGLLights()));
	success &= worldManager->connect(smf, SIGNAL(selectionMode(int)), SLOT(OnSelectionMode(int)));


	success &= worldManager->connect(smf->ui.world, SIGNAL(mydrawNeeded()), SLOT(OnDraw()));
	success &= worldManager->connect(smf->ui.world, SIGNAL(drawWithNamesNeeded()), SLOT(OnSelectDraw()));
	success &= worldManager->connect(smf->ui.world, SIGNAL(selected(const unsigned int, Qt::KeyboardModifiers)), SLOT(OnObjectSelected(const unsigned int, Qt::KeyboardModifiers)));
	success &= worldManager->connect(smf->ui.world, SIGNAL(viewerInitialized()), SLOT(OnViewerInitialized()));
	success &= worldManager->connect(smf->ui.world, SIGNAL(windowResized(int,int)), SLOT(OnWorldSizeChanged(int,int)));


	success &= g_sdfmain->connect(worldManager, SIGNAL(SceneParametersChanged(int,float,float,float,float)), SLOT(ChangeSceneParameters(int,float,float,float,float)));

	success &= smf->statusBar()->connect(worldManager, SIGNAL(message(const QString&)), SLOT(message(const QString&)));
	success &= smf->statusBar()->connect(worldManager, SIGNAL(message(const QString&, int)), SLOT(message(const QString&, int)));

	success &= application.connect((const QObject*)smf->ui.fileExitAction, SIGNAL(activated()), SLOT(quit()));

	return success;
}