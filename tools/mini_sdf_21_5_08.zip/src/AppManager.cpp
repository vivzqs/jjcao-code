#include "stdafx.h"

#include <q3filedialog.h>
#include <QFileDialog>
#include <qfileinfo.h>
#include <qmessagebox.h>
#include <qinputdialog.h>
#include <qstringlist.h>
#include <qfile.h>
#include <qbuffer.h>
#include <q3textstream.h>
#include <qcombobox.h>
#include <q3listbox.h>
#include <qspinbox.h>
#include <qcheckbox.h>
#include <qlayout.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <q3hbox.h>
//Added by qt3to4:
#include <Q3HBoxLayout>


#include "AppManager.h"
#include "CalculateSDF.h"

#include "FeaturePainters.h"
#include "AppParams.h"

#include "mesh/Parser.h"

#include "WorldManager.h"

#include "ColorSchemeManager.h"
#include "MainWindow.h"

#include "FileBrowser.h"


class FileUtils 
{
public:
	static bool save(const QString& fileName, const int& fileType, const QString& description, const char* data, const unsigned int dataSize);
	static bool load(const QString& fileName, const int& fileType, QString& description, char* data, unsigned int& dataSize);
};

bool FileUtils::save(const QString& fileName, const int& fileType, const QString& description, const char* data, const unsigned int dataSize)
{
	QFile file(fileName);
	file.open(QIODevice::WriteOnly);
	QDataStream stream(&file);

	stream << (Q_UINT32)fileType;
	stream << description;

	stream << (Q_UINT32)dataSize;

	stream.writeRawBytes(data, dataSize);

	file.close();

	return true;
}

bool FileUtils::load(const QString& fileName, const int& fileType, QString& description, char* data, unsigned int& dataSize)
{
	QFile file(fileName);
	file.open(QIODevice::ReadOnly);
	QDataStream stream(&file);	

	Q_UINT32 fileTypeInFile;
	stream >> fileTypeInFile >> description;

	if (fileType != fileTypeInFile) return false;

	Q_UINT32 dataSizeInFile;
	stream >> dataSizeInFile;

	dataSize = dataSizeInFile;

	stream.readRawBytes(data, dataSize);

	file.close();
	return true;
}

void AppObject::unloadMesh()
{
	delete mesh;
	mesh = NULL;
}


AppManager::AppManager(MainWindow* parent, const char* name) : 
QObject(parent, name), 
m_worldManager(NULL)
{
	m_appParamsDialog = new AppParams((QWidget*)parent);
	connect(m_appParamsDialog, SIGNAL(pressdOk()), this, SLOT(appParamsOk()));
	connect(m_appParamsDialog, SIGNAL(pressdApply()), this, SLOT(appParamsApply()));


	loadApplicationParameters();

	if (parent->m_browse != NULL)
		connect(parent->m_browse, SIGNAL(openFile(QString)), this, SLOT(openFile(QString)));

}



void AppManager::openFile(QString filename) 
{ 
	removeAllObjects();
	loadObject(filename, 1.0); 
}

AppManager::~AppManager()
{
	saveApplicationParameters();

	//removeAllObjects();
}

void AppManager::Init(WorldManager* worldManager)
{
	m_worldManager = worldManager;
	
}

QString AppManager::createObjectId(const QString& fileName)
{
	int instancesFound = 0;
	QFileInfo fi(fileName);
	QString id = fi.fileName();

	for (appObjectsMap_t::iterator it = m_objects.begin();it!=m_objects.end();it++) 
	{		
		QFileInfo tempinfo(it.value()->fileName);
		if (tempinfo.fileName() == id)
			instancesFound++;
	}

	// for the first, without a number
	if (instancesFound > 0) 
	{
		int counter = 1;
		QString tempName = id + QString::number(instancesFound+counter);
		while (m_objects.find(tempName.ascii()) != m_objects.end()) {
			counter++;
			tempName = id + QString::number(instancesFound+counter);
		}
		id = tempName;
	}

	return id;
}

void AppManager::doMeshPrecalc(Mesh* mesh)
{
	assert (mesh != NULL);

	mesh->compute_normals();
	mesh->compute_bounding_box();		
	//mesh->estimateCurvature();
	mesh->compute_triangle_surfaces();	
	mesh->centerOfMass();

	//m_mesh->compute_volume();
	for (Mesh::Vertex_iterator it = mesh->vertices_begin();
		it != mesh->vertices_end(); 
		it++)
	{
		it->volume(FLT_MAX);
		it->centricity(FLT_MAX);
	}
}

void AppManager::selectObject(const QString& id)
{
	for (appObjectsMap_t::iterator it = m_objects.begin(); it != m_objects.end(); it++) 
	{		
		bool thisone = (it.key() == id);
		it.value()->selection->setSelected(thisone);		

	}

	m_selectedObject = id;
}


#include <CGAL/IO/Polyhedron_iostream.h>

typedef Enriched_polyhedron<Enriched_kernel,Enriched_items>::HalfedgeDS MyHDS;
typedef MyHDS::Vertex::Point MyPoint;


typedef CGAL::Simple_cartesian<double> OKernel;
typedef CGAL::Polyhedron_3<OKernel>     OPolyhedron;

bool AppManager::loadMesh(const QString& fileName, AppObject* ao, float err)
{
	QFileInfo fi(fileName);

	QString ext = fi.extension(FALSE);

	bool success = false;

	try 
	{


	/*	if (ext == "off")
		{
			std::ifstream stream(fileName.toAscii());
			if(!stream) 
			{
				printf("failed to open file in loadMesh.\n");
				return false;				
			}
			//stream >> *mesh;
			CGAL::scan_OFF(stream, *ao->mesh, true);		

			stream.close();	
		}
		else*/ if (ext == "simple" || ext == "ply2" || ext == "off") 
		{
			success = FileParser::read_OffPly2(fileName.toAscii(), ao->mesh, err);

		} 
		else if (ext == "obj") 
		{
			//success = loadObjFile(fileName, ao->mesh);
			//Wavefront_Parser_obj parser;
			//success = parser.read(fileName.toAscii(), ao->mesh);

			success = FileParser::read_Obj(fileName.toAscii(), ao->mesh, err);
		} 

		if (success)
		{
			// deal with quads properly
			for (Mesh::Facet_iterator it = ao->mesh->facets_begin(); it != ao->mesh->facets_end(); it++)				
				ao->mesh->triangulateFacet(it);
			int i=0;
			for (Mesh::Vertex_iterator vit = ao->mesh->vertices_begin(); vit != ao->mesh->vertices_end(); vit++) {
				vit->index(i);
				i++;
			}
			i=0;
			for (Mesh::Facet_iterator it = ao->mesh->facets_begin(); it != ao->mesh->facets_end(); it++)				
			{
				it->index(i);
				i++;
			}	
			success = (ao->mesh->size_of_facets()!=0);

			try
			{
				i = 0;
				for (Mesh::Facet_const_iterator fit = ao->mesh->facets_begin(); fit != ao->mesh->facets_end(); fit++) 
				{
					Mesh::Halfedge_const_handle c = fit->halfedge();
					Mesh::Vertex_const_handle v1 = c->vertex();
					++i;
				}
			}
			catch(...)
			{
				printf("cought exception in pass.\n");
				return false;
			}
			printf("faces=%d\n", i);
		}
		else
		{
			printf("FAILED!");
		}

	}
	catch (...)
	{
		printf("Cought exception in loadMesh.\n");
		return false;
	}


	if (success) {		
		doMeshPrecalc(ao->mesh);
	}

	return success;
}



/*
bool AppManager::loadObjFile(const QString& fileName, Mesh* mesh)
{
	QFile file(fileName);
	if (!file.open(QIODevice::ReadOnly))
		return false;
	QTextStream in(&file);
	
	CGAL::Polyhedron_incremental_builder_3<MyHDS> builder(mesh->get_hds());

	int vindex = 0, findex = 0, filtered = 0;
	QString line;
	do {
		line = in.readLine();
		if (line.length() == 0)
			continue;
		QStringList flds = line.split(' ', QString::SkipEmptyParts);
		if (line[0] == 'v')
		{
			Mesh::Vertex_handle v = builder.add_vertex(MyPoint(flds[1].toFloat(), flds[2].toFloat(), flds[3].toFloat()));
			v->index() = vindex++;
		}
		else if (line[0] == 'f')
		{
			size_t vertices[3] = { flds[1].toInt() - 1, flds[2].toInt() - 1, flds[3].toInt() - 1};
			
			if (!builder.test_facet(&(vertices[0]), &(vertices[3])))
			{
				++filtered;
				continue;
			}

			Mesh::Halfedge_handle he = builder.add_facet(&(vertices[0]), &(vertices[3]));
			if (he == NULL || he->facet() == NULL) 
				return false;
			he->facet()->index(findex++);
		}

	} while (!line.isNull()); 

	printf("filtered=%d ", filtered);

	return true;
}*/

void AppManager::copyObject(AppObject *from, TStubData* newPart, DrawMethod dm)
{
	AppObject* ao = new AppObject;
	ao->mesh = from->mesh;
	ao->selection = new MeshSelection;
	ao->description = from->description;
	ao->fileName = from->fileName;
	ao->id = createObjectId(ao->fileName);
	ao->hasSdfFacets = from->hasSdfFacets;
	
	ao->refCount = from->refCount;
	++(*ao->refCount);

	m_objects.insert(ao->id, ao);
	selectObject(ao->id);

	emit message("Copied <" + ao->description + ">");
	emit ObjectAdded(ao, newPart, dm);
}

QString makeSubFilename(const QFileInfo& fi, QString sub, bool create)
{
	QDir dir(fi.path());
	if ((!dir.exists(sub)) && create)
		dir.mkdir(sub);
	return fi.path() + "/" + sub + "/" + fi.fileName();
}



bool AppManager::loadObject(const QString& fileName, float err, TStubData* part, DrawMethod dm)
{
	//create app object
	AppObject* ao = new AppObject;
	ao->mesh = new Mesh;
	ao->selection = new MeshSelection;
	QFileInfo fi(fileName);
	ao->description = fi.fileName();
	ao->id = createObjectId(fileName);
	ao->fileName = fileName;


	//if marked object as normals reversed, do it now
	bool reverseNormals;
	ProgSettings ps;
	reverseNormals = m_appParameters.normalsReversed;
	ps.beginGroup("Reverse Normal Models");
	if (ps.readBoolEntry(ao->fileName))
		reverseNormals = !reverseNormals;
	ps.endGroup();


	//actually load the mesh
	bool success = loadMesh(fileName, ao, err);

	if (success) {
		//if marked object as normals reversed, do it now
		if (reverseNormals) {
			ao->mesh->inside_out();
			ao->mesh->reverseNormals();
		}
		
		// check if to load default volume file
		QFileInfo fi(fileName);
		QString sdfName = ao->fileName + ".sdf"; // plain file with sdf extension
		if (QFile::exists(sdfName)) {
			loadMeshFeatures(sdfName, ao);
		}
		else
		{
			sdfName = makeSubFilename(fi, "sdfs", false) + ".sdf"; // under sdfs dir
			if (QFile::exists(sdfName)) {
				loadMeshFeatures(sdfName, ao);
			}
		}

		//add to object map
		m_objects.insert(ao->id, ao);

		selectObject(ao->id);

		QString s;
		s.sprintf("Loaded mesh %s", ao->fileName.toAscii());
		SDFLOG8(s);

		emit message("Loaded <" + ao->description + ">");

		//send notifications
		emit ObjectAdded(ao, part, dm); //, ao->id, ao->description, ao->mesh, part, dm, ao->meshSurfaceGraph, ao->selection, tabact);


	} 
	else 
	{
		delete ao;
	}	

	return success;
}



bool AppManager::loadObject()
{
	//select file name
	ProgSettings ps;

	QStringList fileNames = Q3FileDialog::getOpenFileNames(
		"Meshes (*.ply2 *.simple *.obj *.off)",
		ps.readEntry("mesh_directory", QString::null),				
		NULL,
		"Load Mesh"
		"Choose a mesh file(s)" );

	bool allSuccess = true;

	QString thisdir;
	if (fileNames.size()) {
		for (QStringList::iterator it = fileNames.begin(); it != fileNames.end();it++) {
			QString fileName = *it;
			QFileInfo fi(fileName);
			thisdir = fi.dirPath(TRUE);
			if (!fi.exists()) {
				allSuccess = false;
			} else if (!loadObject(fileName, 1.0)) {
					QMessageBox::warning(g_main, "Error loading", "Could not load mesh");				
			}			
		}

		if (allSuccess ) {
			//save directory for next time
			ps.writeEntry("mesh_directory",thisdir);
		}
	}
	
	return allSuccess;	
}




class VolumeFaceColorizer : public FaceColorizer
{
public:
	VolumeFaceColorizer(WorldManager *wm) { m_cs = ColorSchemeManager::GetScheme(wm->getColorSchemeName()); }
	QColor getColor(Mesh::Facet_handle f) { return m_cs.gradient(f->nvolume()); }
	ColorScheme m_cs;
};





bool AppManager::saveObjWithFaceSDF(const QString& filename, AppObject* appObject)
{
	return saveObjWithFaceColor(filename, appObject, VolumeFaceColorizer(m_worldManager), false);
}

uint qHash(const QColor& v)
{
	return (uint)v.rgb();
}
 
bool AppManager::saveObjWithFaceColor(const QString& filename, AppObject* appObject, FaceColorizer& cizr, bool groups)
{
	QFile data(filename);
	if (!data.open(QFile::WriteOnly | QFile::Truncate)) 
		return false;
	data.setTextModeEnabled(true);

	QTextStream out(&data);
	out << "# SDF for facets.\n\n";
	out << "mtllib sdfDefault.mtl\n";
	Mesh *mesh = appObject->mesh;
	for (Mesh::Vertex_iterator ivertex = mesh->vertices_begin(); ivertex != mesh->vertices_end(); ivertex++)
	{
		Mesh::Vertex_handle v = ivertex;
		Mesh::Point p = v->point();
		out << "v " << p.x() << " " << p.y() << " " << p.z() << "\n";
		//printf("%d: %f,%f,%f\n", v->index(), p.x(), p.y(), p.z());
	}
	out << "\n";

	typedef QList<Mesh::Facet_handle> TFacetsList;
	typedef QHash<QColor, TFacetsList> TFacetsHash;
	TFacetsHash bins;

	for (Mesh::Facet_iterator fcit = mesh->facets_begin(); fcit != mesh->facets_end(); ++fcit)
	{
		Mesh::Facet_handle f = fcit;
		QColor c = cizr.getColor(f);
		bins[c].push_back(f);
	}

	for (TFacetsHash::const_iterator it = bins.constBegin(); it != bins.constEnd(); ++it)
	{
		QColor c = it.key();
		if (groups)
		{
			out << "g " << "group_" << c.red() << "_" << c.green() << "_" << c.blue() << "\n";
		}
		out << "\nusemtl " << "sdfcol_" << c.red() << "_" << c.green() << "_" << c.blue() << "\n";
		const TFacetsList &flst = it.value();
		for (TFacetsList::const_iterator fit = flst.constBegin(); fit != flst.constEnd(); ++fit)
		{
			Mesh::Facet_handle f = *fit;
			out << "f ";
			Mesh::Halfedge_around_facet_circulator	fvait = f->halfedge()->facet_begin();
			Mesh::Halfedge_around_facet_circulator	begin = fvait;
			CGAL_For_all(fvait, begin)	
			{
				//Mesh::Vertex_handle v = fvait;
				out << fvait->vertex()->index() + 1<< " ";
			}
			out << "\n";
		}
		
	}

	return true;
}



void AppManager::removeObject(QString id)
{
	appObjectsMap_t::iterator it = m_objects.find(id.ascii());

	if (it != m_objects.end()) {
		AppObject* ao = it.value();

		if (m_selectedObject == ao->id)
			selectObject(QString::null);			

		delete ao;

		m_objects.erase(it);
	}

	if (m_selectedObject == QString::null && m_objects.size()) {
		selectObject(m_objects.begin().value()->id);
	}

	emit ObjectRemoved(id);
}

void AppManager::removeAllObjects()
{
	//delete all objects from world
	for (appObjectsMap_t::iterator it = m_objects.begin(); it != m_objects.end(); it++)
	{
		AppObject* ao = it.value();

		QString id = ao->id;
		delete ao;

		emit ObjectRemoved(id);
	}

	m_objects.clear();

	selectObject(QString::null);

	emit ObjectsChanged();
}

void AppManager::OnLoadObject()
{
	loadObject();
}


void AppManager::OnRemoveSelectedObject()
{
	AppObject* ao = getSelectedObject();
	if (!ao) return;

	removeObject(ao->id);
}

void AppManager::OnRemoveObjects()
{
	if (QMessageBox::question(
		(QWidget*)parent(), 
		"Removing all models",
		"Are you sure you want to remove all models?",
		QMessageBox::Yes, QMessageBox::No) == QMessageBox::Yes)
	{
		removeAllObjects();
	}	
}

AppObject* AppManager::getSelectedObject()
{
	if (m_selectedObject == QString::null)
		return NULL;

//	AppObject* ao;
	appObjectsMap_t::iterator it = m_objects.find(m_selectedObject.ascii());
	if (it != m_objects.end()) {
		return it.value();
	} else {
		return NULL;
	}
}




void AppManager::OnLoadObjectFeatures()
{
	//temporary selected object
	AppObject* ao = getSelectedObject();
	if (!ao) return;

	QString filter = ao->fileName;
	int beginAt = filter.findRev("/");
	if (beginAt >= 0) {
		int length = filter.find(".", beginAt) - beginAt - 1;
		filter = filter.mid(beginAt+1, length);
		filter.append("*.*");
	} else {
		filter = "*.*";
	}

	QString dirOnly = ao->fileName;
	dirOnly = dirOnly.left(beginAt+1);

	QString fileName;
	if ((fileName = 
		Q3FileDialog::getOpenFileName(dirOnly + filter,
		"Feature Files (*.sdf *.fsdf)",
		(QWidget*)parent(),
		NULL,
		"Open SDF file")) != QString::null)
	{
		loadMeshFeatures(fileName, ao);
	}
}

void AppManager::OnDiffObjectFeatures()
{
	//temporary selected object
	AppObject* ao = getSelectedObject();
	if (!ao) return;

	QString filter = ao->fileName;
	int beginAt = filter.findRev("/");
	if (beginAt >= 0) {
		int length = filter.find(".", beginAt) - beginAt - 1;
		filter = filter.mid(beginAt+1, length);
		filter.append("*.*");
	} else {
		filter = "*.*";
	}

	QString dirOnly = ao->fileName;
	dirOnly = dirOnly.left(beginAt+1);

	QString fileName;
	if ((fileName = 
		Q3FileDialog::getOpenFileName(dirOnly + filter,
		"Feature Files (*.sdf *.fsdf)",
		(QWidget*)parent(),
		NULL,
		"Open SDF file")) != QString::null)
	{
		diffSDFFacets(fileName, ao);		
	}

	emit ObjectChanged(ao->id, false);
}


bool AppManager::loadMeshFeatures(const QString& featuresFileName, AppObject* appObject)
{
	assert(appObject != NULL);

	QFileInfo fi(featuresFileName);
	if (!fi.exists()) return false;

	QString ext = fi.suffix();
	bool success = false;
	if (ext == "vsdf") 
	{ // vertices SDF
		success = loadSDFVertices(featuresFileName, appObject);
	} 
	else if (ext == "sdf") 
	{ // on faces
		success = loadSDFFacets(featuresFileName, appObject);
		appObject->hasSdfFacets = true;
	} 


	if (success) {
		emit message("Loaded features for <" + appObject->description  + "> from <" + fi.fileName() + ">");

		emit ObjectChanged(appObject->id, false);
	}

	return success;	
}

bool AppManager::calculateShapeDiameterFunction(
	AppObject* appObject,
	const bool onVertices,
	const bool showDialog)
{
	CalculateSDF csdf;

	//calculate SDF
	bool success = csdf.go(
		appObject->mesh,
		onVertices,
		m_appParameters.multithreaded,
		m_appParameters.sdf_numcones,
		m_appParameters.sdf_coneSeperation,
		m_appParameters.sdf_raysInCone,
		m_appParameters.sdf_gaussianWeights, 
		m_appParameters.sdf_normalize,
		m_appParameters.sdf_smoothing,
		m_appParameters.sdf_smoothing_anisotropic,
		m_appParameters.sdf_smoothing_iterations,
		showDialog);

	if (!success)
		return false;

	//create histogram

	QString s;
	s.sprintf("Calculated SDF for <%s>", appObject->id.toAscii());
	SDFLOG8(s);

	emit message("Calculated SDF for <" + appObject->description + ">");

	emit ObjectChanged(appObject->id, false);

	emit ObjectsChanged();

	return true;
}

void AppManager::OnCalculateSDFVertices()
{
	AppObject* ao = getSelectedObject();
	if (!ao) return;

	if (!calculateShapeDiameterFunction(ao, true, true))
		printf("Failed calculating SDF");
}

void AppManager::OnCalculateSDFFacets()
{
	try
	{
		AppObject* ao = getSelectedObject();
		if (!ao) return;

		if (!calculateShapeDiameterFunction(ao, false, true))
			printf("Failed calculating SDF");
	}
	catch (...)
	{
		QMessageBox::critical(NULL, "SDF", "Exception");
	}
}

void AppManager::OnCalculateSDFFacetsForAll()
{
	for (appObjectsMap_t::iterator it = m_objects.begin(); it != m_objects.end(); it++) {
		AppObject* ao = it.value();
		if (ao) {
			if (!calculateShapeDiameterFunction(ao, false, false))
				printf("Failed calculating SDF");
		}
	}
}

bool AppManager::saveSDFVertices(const QString& featuresFileName, AppObject* appObject)
{
	unsigned int sdf_size = appObject->mesh->size_of_vertices();
	number_type* sdf = new number_type[sdf_size];
	Mesh::Vertex_const_iterator it = appObject->mesh->vertices_begin();
	Mesh::Vertex_const_iterator it_end = appObject->mesh->vertices_end();
	int i=0;
	for (;it != it_end; it++) {
		sdf[i] = it->volume();
		i++;
	}

	bool ret = FileUtils::save(
		featuresFileName,
		FEATURES_FILE_SDF_VERTICES,
		"SDF Vertices on " + appObject->fileName, 
		(char*)sdf,
		sizeof(number_type)*sdf_size);

	delete[] sdf;
	return ret;
}



bool AppManager::saveSDFFacets(const QString& featuresFileName, AppObject* appObject)
{
	unsigned int sdf_size = appObject->mesh->size_of_facets();
	number_type* sdf = new number_type[sdf_size];
	Mesh::Facet_const_iterator it = appObject->mesh->facets_begin();
	Mesh::Facet_const_iterator it_end = appObject->mesh->facets_end();
	int i=0;
	for (;it != it_end; it++) {
		sdf[i] = it->volume();
		i++;
	}

	bool ret = FileUtils::save(
		featuresFileName,
		FEATURES_FILE_SDF_FACETS,
		"SDF Facets on " + appObject->fileName, 
		(char*)sdf,
		sizeof(number_type)*sdf_size);

	delete[] sdf;
	return ret;
}

bool AppManager::saveSDFFacetsText(const QString& featuresFileName, AppObject* appObject)
{
	unsigned int sdf_size = appObject->mesh->size_of_facets();	
	Mesh::Facet_const_iterator it = appObject->mesh->facets_begin();
	Mesh::Facet_const_iterator it_end = appObject->mesh->facets_end();	

	QFile file(featuresFileName);
	if (file.open(QIODevice::WriteOnly)) {
		Q3TextStream ts(&file);
		for (;it != it_end; it++) {
			ts << it->volume() << '\n';	
		}
		file.close();
		return true;
	}
    	
	return false;
}

bool AppManager::saveSDFDiffFacetsText(const QString& featuresFileName, AppObject* appObject)
{
	unsigned int sdf_size = appObject->mesh->size_of_facets();	
	Mesh::Facet_const_iterator it = appObject->mesh->facets_begin();
	Mesh::Facet_const_iterator it_end = appObject->mesh->facets_end();	

	QFile file(featuresFileName);
	if (file.open(QIODevice::WriteOnly)) {
		Q3TextStream ts(&file);
		for (;it != it_end; it++) {
			number_type feature = it->volume();		
			number_type maxNeighborDiff = 0.0;
			Mesh::Halfedge_around_facet_const_circulator c = it->facet_begin();
			do {
				Mesh::Facet_const_handle neighbor = c->opposite()->facet();
				if (neighbor == NULL) continue;				
				number_type nvalue = neighbor->volume();				
				if (fabs(nvalue-feature)>maxNeighborDiff) maxNeighborDiff = fabs(nvalue-feature);
			} while (++c != it->facet_begin());
			
			//number_type diff = MIN(maxNeighborDiff / (feature + 1e-4),1);

			ts << maxNeighborDiff << '\n';
		}
		file.close();
		return true;
	}

	return false;
}

bool AppManager::loadSDFVertices(const QString& featuresFileName, AppObject* appObject)
{
	unsigned int sdf_size = appObject->mesh->size_of_vertices();
	number_type* sdf = new number_type[sdf_size];

	QString description;
	bool success = FileUtils::load(featuresFileName,
		FEATURES_FILE_SDF_VERTICES,description, (char*)sdf, sdf_size);

	if (!success) 
	{
		delete[] sdf;
		return false;
	}

	Mesh::Vertex_iterator it = appObject->mesh->vertices_begin();
	Mesh::Vertex_iterator it_end = appObject->mesh->vertices_end();
	int i=0;
	for (;it != it_end; it++) {
		if (sdf[i]==sdf[i])
			it->volume(sdf[i]);
		else
			it->volume(0.0);
		i++;
	}

	delete[] sdf;
	return true;
}

bool AppManager::diffSDFFacets(const QString& featuresFileName, AppObject* appObject)
{
	unsigned int sdf_size = appObject->mesh->size_of_facets();
	number_type* sdf = new number_type[sdf_size];

	QString description;
	bool success = FileUtils::load(featuresFileName,
		FEATURES_FILE_SDF_FACETS,description, (char*)sdf, sdf_size);

	if (!success) 
	{
		delete[] sdf;
		return false;
	}

	Mesh::Facet_iterator it = appObject->mesh->facets_begin();
	Mesh::Facet_iterator it_end = appObject->mesh->facets_end();
	int i=0;
	for (;it != it_end; it++) {
		it->volume() = fabs(sdf[i] - it->volume());
		i++;
	}

	appObject->mesh->fill_normalized_volume();

	delete[] sdf;
	return true;
}

bool AppManager::loadSDFFacets(const QString& featuresFileName, AppObject* appObject)
{
	unsigned int sdf_size = appObject->mesh->size_of_facets();
	number_type* sdf = new number_type[sdf_size];

	QString description;
	bool success = FileUtils::load(featuresFileName, FEATURES_FILE_SDF_FACETS,description, (char*)sdf, sdf_size);

	if (!success) 
	{
		delete[] sdf;
		return false;
	}

	int i=0;
	for (Mesh::Facet_iterator it = appObject->mesh->facets_begin(); it != appObject->mesh->facets_end(); ++it) 
	{
		if (sdf[i]==sdf[i])
			it->volume(sdf[i]);
		else
			it->volume(0.0);
		i++;
	}

//	appObject->mesh->fill_normalized_volume();

	appObject->mesh->makeFacesNVolume(m_appParameters.sdf_smoothing, 
		m_appParameters.sdf_smoothing_anisotropic, m_appParameters.sdf_smoothing_iterations);


	delete[] sdf;
	return true;
}

void AppManager::OnSaveObjectFeatures()
{
	AppObject* ao = getSelectedObject();
	if (!ao) return;

	QStringList featureTypes;
	featureTypes.append("SDF Vertices");
	featureTypes.append("SDF Facets");
	featureTypes.append("SDF Facets (Text)");
	featureTypes.append("SDF Differences (Text)");

	featureTypes.append("OBJ with SDF Facets");
	featureTypes.append("Snapshot");

	bool ok;
	QString answer = QInputDialog::getItem(
		"Save Mesh Features", 
		"Select feature to save", 
		featureTypes, 5, FALSE, &ok,
		(QWidget*)parent(), "featureFileTypeSelect");

	if (ok) {
		int featureType = featureTypes.findIndex(answer);

		char* exts[] = { ".vsdf", ".sdf", ".sdf.txt", ".sdf_diff.txt", ".sdf.obj", ".png" };
		QString ext = exts[featureType];

		QString filter = ao->fileName;
		int beginAt = filter.findRev("/");
		if (beginAt >= 0) {
			int length = filter.find(".", beginAt) - beginAt - 1;
			filter = filter.mid(beginAt+1, length);
			filter.append(ext);
		} else {
			filter = "*." + ext;
		}

		QString dirOnly = ao->fileName;
		dirOnly = dirOnly.left(beginAt+1);

		QString fileName;
		if ((fileName = Q3FileDialog::getSaveFileName(dirOnly + filter, "Feature Files (*." + ext + ")", (QWidget*)parent(), NULL, "Save SDF file")) != QString::null)
		{
			switch(featureType)
			{
			case 0:	saveSDFVertices(fileName, ao);break;
			case 1:	saveSDFFacets(fileName, ao);break;
			case 2:	saveSDFFacetsText(fileName, ao);break;
			case 3:	saveSDFDiffFacetsText(fileName, ao);break;
			case 4: saveObjWithFaceSDF(fileName, ao); break;
			case 5: saveSnapshot(fileName); break;
			}			
		}
	}
}

void AppManager::saveSnapshot(const QString &fileName)
{
	g_sdfmain->ui.world->setSnapshotFormat("PNG");
	g_sdfmain->ui.world->saveSnapshot(fileName, true);
}

void AppManager::reverseObjectNormals(AppObject* appObject)
{
	if (!appObject || !appObject->mesh) return;

	appObject->mesh->reverseNormals();
	appObject->mesh->inside_out();

	//remember that I reversed normals for this object
	ProgSettings ps;
	ps.beginGroup("Reverse Normal Models");
	bool alreadyReversed = ps.readBoolEntry(appObject->fileName);	
	ps.writeEntry(appObject->fileName, !alreadyReversed);
	ps.endGroup();

	emit ObjectChanged(appObject->id, true);
}

void AppManager::OnReverseNormals()
{
	reverseObjectNormals(getSelectedObject());
}

void AppManager::OnSelectedObjectInfo()
{
	AppObject* ao = getSelectedObject();
	if (!ao) return;

	QString info;

	QString generalInfo;
	generalInfo.sprintf("Object %s. #vertices = %d #facets = %d\nSelected facet #%d", 
		ao->fileName.toAscii(), 
		ao->mesh->size_of_vertices(), 
		ao->mesh->size_of_facets(),
		ao->selection->selectedFacet());
	info.append(generalInfo);


	QMessageBox::information((QWidget*)parent(), ao->id + " info", info);
}




void AppManager::OnObjectSelected(const QString& id)
{
	selectObject(id);
}

void AppManager::OnArrowKeyPressed(int key, Qt::ButtonState s)
{
	if (key != Qt::Key_Up)
		return;

}


void AppManager::OnFacetSelected(const QString& id, const int facetIndex)
{
	selectObject(id);

}



QStringList AppManager::getObjectNames(int& selectedIndex)
{
	QStringList list;

	selectedIndex = -1;

	appObjectsMap_t::iterator it = m_objects.begin();
	appObjectsMap_t::iterator it_end = m_objects.end();
	int i=0;
	for (;it != it_end; it++) {
		AppObject* ao = it.value();
		if (ao->selection->isSelected()) 
			selectedIndex = i;
		list.append(ao->id);
		i++;
	}

	return list;
}

AppObject* AppManager::getObject(const QString& id)
{
	appObjectsMap_t::iterator it = m_objects.find(id.ascii());
	if (it == m_objects.end())
		return NULL;
	else
		return it.value();
}






